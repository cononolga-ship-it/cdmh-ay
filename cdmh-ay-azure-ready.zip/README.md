# CDMH AY

Single-owner, read-only MCP server and scheduled collector for the isolated YouTube channels `conon_d` and `kadr19`.

Version 0.6 removes Microsoft OAuth, Microsoft Graph, and every direct OneDrive/SharePoint dependency from the Azure runtime. Existing OneDrive data, including `YouTube OLD`, is never read, changed, copied, or deleted by this application.

## Runtime architecture

- Azure Container App Web: Google owner consent, ChatGPT-to-MCP OAuth, Streamable HTTP MCP, live YouTube reads.
- Azure Container Apps Job: one-shot collection for both channels, guarded by a distributed lease.
- YouTube Data API, YouTube Analytics API, and YouTube Reporting API: read-only source APIs.
- Cosmos DB Free Tier: encrypted channel-scoped Google refresh-token state, collector lease, and the compressed runtime archive required by the historical MCP tools.
- One user-assigned Managed Identity: Cosmos data-plane access without account keys or connection strings.

Web has no scheduler. The Job owns the UTC cron. One immutable GHCR image is used by both workloads.

## MCP tools

| Tool | Purpose |
|---|---|
| `channel_overview` | Channel identity and recent analytics |
| `list_videos` | Uploaded videos with pagination |
| `video_metrics` | Aggregate video metrics |
| `video_daily_metrics` | Daily video metrics |
| `traffic_sources` | Traffic-source metrics |
| `video_reach` | Reporting API impressions and CTR |
| `metric_history` | Historical observations by metric date and collection time |
| `metric_revisions` | Values that changed between collections |
| `snapshot_diff` | Differences between exact collection snapshots |

Every tool accepts an optional `channel`. Omit it for `conon_d`; use `kadr19` for KADR19. All tools are read-only.

## Google OAuth

Authorize each collector identity through:

```text
https://<web-host>/oauth/google/collector/conon_d/start
https://<web-host>/oauth/google/collector/kadr19/start
```

The callback verifies the expected Google owner, confirms the actual YouTube channel, checks Analytics and Reporting access, and stores a channel-scoped refresh token encrypted with AES-256-GCM. `GOOGLE_REFRESH_TOKEN` remains only a bootstrap fallback for the default channel.

Scopes:

```text
https://www.googleapis.com/auth/youtube.readonly
https://www.googleapis.com/auth/yt-analytics.readonly
```

## Cosmos runtime state

Database `cdmh-ay`, container `runtime-state`, partition key `/partitionKey`, fixed partition value `runtime`.

Active document families:

- `google-collector-refresh-token:<channel-id>`: encrypted Google refresh token per channel.
- `collector-execution-lease`: expiring distributed Job lease.
- `archive:<channel-key>:...`: compressed, chunked collector snapshots, indexes, and Reporting payloads isolated by channel.

Legacy Microsoft OAuth documents may remain in the container but are never read, written, leased, migrated, or deleted by version 0.6.

The archive backend uses gzip chunks so logical files do not depend on the Cosmos per-item size limit. Immutable snapshots are never overwritten. Mutable indexes use ETag-guarded replace operations. The existing Free Tier account remains provisioned at 400 RU/s in one region.

## Entry points

```text
Web:       node dist/src/index.js
Collector: node dist/src/cli/collect.js
```

## Environment variables

| Variable | Web | Job | Secret |
|---|:---:|:---:|:---:|
| `NODE_ENV` | yes | yes | no |
| `PORT` | yes | — | no |
| `PUBLIC_BASE_URL` | yes | — | no |
| `GOOGLE_CLIENT_ID` | yes | yes | no |
| `GOOGLE_CLIENT_SECRET` | yes | yes | yes |
| `GOOGLE_REFRESH_TOKEN` | yes | yes | yes |
| `YOUTUBE_CHANNEL_ID` | yes | yes | no |
| `YOUTUBE_CHANNELS_JSON` | yes | yes | no |
| `DEFAULT_CHANNEL_KEY` | yes | yes | no |
| `OWNER_GOOGLE_EMAIL` | yes | — | private |
| `YT_REACH_JOB_ID` | yes | yes | no |
| `AZURE_COSMOS_ENDPOINT` | yes | yes | no |
| `AZURE_COSMOS_DATABASE_NAME` | yes | yes | no |
| `AZURE_COSMOS_CONTAINER_NAME` | yes | yes | no |
| `AZURE_CLIENT_ID` | yes | yes | no |
| `RUNTIME_STATE_ENCRYPTION_KEY` | yes | yes | yes |
| `MCP_TOKEN_SIGNING_SECRET` | yes | — | yes |
| `MCP_ACCESS_TOKEN_TTL_SECONDS` | yes | — | no |
| `MCP_REFRESH_TOKEN_TTL_SECONDS` | yes | — | no |
| `COLLECTION_LOOKBACK_DAYS` | yes | yes | no |
| `COLLECTOR_CONCURRENCY` | yes | yes | no |

No `MICROSOFT_*`, Graph, OneDrive, or SharePoint settings are accepted.

## Verification

```bash
npm ci
npm run check
npm test
npm audit
```

Deploy an immutable image to Web and Collector, keep the Job manual until `/health`, both Google channel identities, MCP calls, and one manual collection all succeed, then restore cron `0 4 * * *`.
