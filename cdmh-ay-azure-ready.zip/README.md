# CDMH AY

Read-only YouTube analytics collector for the isolated channels `conon_d` and `kadr19`.

Version 0.7.0 keeps Cosmos as the runtime archive and adds an autonomous, secondary export to a dedicated personal OneDrive account. ChatGPT and its SharePoint connector are not in the collection or export path.

## Runtime architecture

```text
Azure Collector -> YouTube -> Cosmos -> OneDrive
```

- Azure Container App Web: Google collector consent, the one-time OneDrive OAuth callback, health, and the existing read-only MCP endpoint.
- Azure Container Apps Job: one-shot YouTube collection for both channels plus a non-blocking OneDrive export post-step.
- Cosmos DB Free Tier: encrypted Google tokens, encrypted OneDrive refresh token, consent state, distributed collector lease, immutable snapshots, Reach payloads, history indexes, and the pending export queue.
- Microsoft Graph: delegated `Files.ReadWrite` access to one dedicated personal Microsoft account. No Graph SDK is used.

Web has no scheduler. The Job owns the UTC cron. One immutable GHCR image is used by both workloads.

## OneDrive export

Every successfully stored Cosmos snapshot is first registered in a per-channel export queue, then exported to:

```text
CDMH AY/YouTube/<channel>/YYYY-MM-DD/<snapshot_id>/
  snapshot.json
  reach/<report_id>.csv
  reach/<report_id>.metadata.json
  manifest.json
```

`manifest.json` is written last and contains the channel, `snapshot_id`, `observed_at`, byte size, content type, and SHA-256 hash for every data file. The exporter reads every file back from OneDrive and verifies size and hash before marking the task complete.

The target path is deterministic. A repeated export validates and reuses the same snapshot folder; it never creates a second folder or filename for the same `snapshot_id`.

OneDrive is secondary. A Graph or authorization failure leaves the task in Cosmos with status `pending`, increments its attempt count, and records only a safe error code. The Collector still exits successfully when the YouTube snapshot is already safely stored in Cosmos. Later successful runs retry pending tasks without recollecting YouTube data.

## OneDrive authorization

The app registration supports personal Microsoft accounts and uses the delegated authorization-code flow with PKCE. Requested scopes:

```text
offline_access Files.ReadWrite
```

The client secret stays in Azure Container Apps secrets. The rotating refresh token is encrypted with AES-256-GCM and stored in Cosmos as `onedrive-export-refresh-token-v1`. Access tokens are memory-only and are never logged.

Create a one-time consent URL inside the Web container:

```bash
npm run onedrive:consent
```

The callback is `https://<web-host>/oauth/onedrive/callback`.

## Cosmos runtime state

Database `cdmh-ay`, container `runtime-state`, partition key `/partitionKey`, fixed partition value `runtime`.

Active document families:

- `google-collector-refresh-token:<channel-id>`: encrypted Google refresh token per channel.
- `collector-execution-lease`: expiring distributed Job lease.
- `archive:<channel-key>:...`: compressed snapshots, indexes, and Reach payloads isolated by channel.
- `onedrive-export-refresh-token-v1`: encrypted refresh token and authorized account identity.
- `onedrive-export-consent:*`: short-lived, one-use PKCE consent state.
- `onedrive-export-queue:<channel>`: only snapshots awaiting export.
- `onedrive-export-status:<channel>:<snapshot_id>`: pending/completed state, attempt count, safe last-error code, and target path.

Legacy Microsoft OAuth documents are not migrated or deleted.

## Google OAuth

Authorize each collector identity through:

```text
https://<web-host>/oauth/google/collector/conon_d/start
https://<web-host>/oauth/google/collector/kadr19/start
```

The callback verifies the expected Google owner and actual YouTube channel, then stores a channel-scoped refresh token encrypted with AES-256-GCM.

## Entry points

```text
Web:              node dist/src/index.js
Collector:        node dist/src/cli/collect.js
OneDrive consent: node dist/src/cli/onedrive-consent.js
```

## Environment variables

| Variable | Web | Job | Secret |
|---|:---:|:---:|:---:|
| `PUBLIC_BASE_URL` | yes | — | no |
| `GOOGLE_CLIENT_ID` | yes | yes | no |
| `GOOGLE_CLIENT_SECRET` | yes | yes | yes |
| `GOOGLE_REFRESH_TOKEN` | yes | yes | yes |
| `YOUTUBE_CHANNEL_ID` / `YOUTUBE_CHANNELS_JSON` | yes | yes | no |
| `OWNER_GOOGLE_EMAIL` | yes | — | private |
| `AZURE_COSMOS_*` / `AZURE_CLIENT_ID` | yes | yes | no |
| `RUNTIME_STATE_ENCRYPTION_KEY` | yes | yes | yes |
| `ONEDRIVE_EXPORT_ENABLED` | yes | yes | no |
| `MICROSOFT_CLIENT_ID` | yes | yes | no |
| `MICROSOFT_CLIENT_SECRET` | yes | yes | yes |
| `MICROSOFT_TENANT_ID` | yes | yes | no |
| `ONEDRIVE_ROOT_PATH` | yes | yes | no |

## Verification

```bash
npm ci
npm run check
npm test
npm audit --omit=dev
```

Keep the Job manual until both channels export successfully, their OneDrive files verify, the idempotent retry is confirmed, and the simulated OneDrive failure leaves the Job successful.
