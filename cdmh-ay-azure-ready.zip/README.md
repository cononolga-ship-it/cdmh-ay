# CDMH AY

Однопользовательский read-only MCP-сервер на TypeScript/Node.js для нескольких изолированных YouTube-каналов. Один Web App отвечает за OAuth, Streamable HTTP MCP и чтение данных; один Azure Container Apps Job последовательно собирает каждый канал. Conon & D хранится в `/0_0COD/01_0 CDMH AY/YouTube`, KADR19 — в `/0_0COD/02_0 KADR AY/YouTube`.

Проект подготовлен для Azure, но **не развёрнут**. Расписание collector намеренно не выбрано: `collectorCronUtc` должен быть подтверждён владельцем перед deployment и задаётся в UTC.

## Архитектура

```mermaid
flowchart TD
  C[ChatGPT] -->|OAuth 2.1 + PKCE| W[Container App Web]
  W -->|read-only APIs| Y[YouTube]
  W -->|archive reader| O[Personal OneDrive]
  J[Scheduled Container Apps Job] -->|read-only APIs| Y
  J -->|immutable archive writer| O
  W -->|Managed Identity| X[Cosmos runtime state]
  J -->|Managed Identity| X
```

- Azure Container Apps Consumption environment, `appLogsConfiguration.destination: none`.
- Web Container App: external HTTPS ingress, `minReplicas: 0`, `maxReplicas: 1`.
- Scheduled Container Apps Job: `0.25` vCPU, `0.5Gi`, `parallelism: 1`, `replicaCompletionCount: 1`.
- Один public immutable GHCR image используется обоими процессами.
- Cosmos DB for NoSQL: один регион, Free Tier при создании account, provisioned `400 RU/s`, без Serverless и с отключённой key-based authentication.
- Одна user-assigned Managed Identity назначена Web и Job.
- OneDrive personal delegated OAuth: `offline_access Files.ReadWrite`. Для существующей папки вне App Folder требуется доступ к файлам пользователя; код обращается только к заданной папке.
- Нет Render, Persistent Disk, Azure Storage, ACR, Log Analytics, Application Insights, VNet, NAT или Private Endpoint.

## Entry points

```text
Web:       node dist/src/index.js
Collector: node dist/src/cli/collect.js
```

Web не содержит scheduler и никогда не запускает collector. Расписание принадлежит исключительно Azure Container Apps Job.

## MCP tools

| Tool | Назначение |
|---|---|
| `channel_overview` | Канал и Analytics за последние завершённые дни |
| `list_videos` | Видео канала с пагинацией |
| `video_metrics` | Сводные метрики видео за период |
| `video_daily_metrics` | Дневные метрики |
| `traffic_sources` | Источники трафика |
| `video_reach` | Impressions, CTR, covered period и дневные строки |
| `metric_history` | Все наблюдения метрики с `metric_date` и `observed_at` |
| `metric_revisions` | Изменения значения одной даты между сборами |
| `snapshot_diff` | `added`, `removed`, `changed`, для чисел — `delta` |

Все MCP tools принимают необязательный `channel`: отсутствие значения сохраняет прежнее поведение Conon & D, `kadr19` выбирает KADR19. Tools помечены `readOnlyHint: true`, `destructiveHint: false`. OAuth ChatGPT → MCP поддерживает Authorization Code, PKCE S256, Dynamic Client Registration, короткоживущий access token, refresh token и проверку issuer/resource/audience.

## YouTube

Для первичной авторизации collector владелец канала `kadrgruppa@gmail.com` открывает
`https://<web-host>/oauth/google/collector/<channel>/start` в обычном браузере (`conon_d` или `kadr19`). Старый `/oauth/google/collector/start` остаётся алиасом Conon & D. OAuth client CDMH AY
запрашивает `openid`, `email`, `youtube.readonly`, `yt-analytics.readonly` и offline access.
Callback принимает только этот email, сверяет ID канала через `channels.list(mine=true)`,
проверяет Analytics и Reporting и сохраняет refresh token в Cosmos в отдельном
отдельном AES-256-GCM документе на Channel ID. Web App и Collector Job читают channel-scoped зашифрованный state;
значение старого `GOOGLE_REFRESH_TOKEN` в Azure остаётся только начальным fallback.
После сохранения токен не отображается пользователю и не передаётся через чат.

Используются официальные YouTube Data API v3, YouTube Analytics API и YouTube Reporting API со scopes:

```text
https://www.googleapis.com/auth/youtube.readonly
https://www.googleapis.com/auth/yt-analytics.readonly
```

Reach report type: `channel_reach_basic_a1`. Поля: `video_thumbnail_impressions` и `video_thumbnail_impressions_ctr`. CTR нескольких дней рассчитывается как:

```text
sum(impressions_day * ctr_day) / sum(impressions_day)
```

Если `YT_REACH_JOB_ID` задан, используется он. Иначе код проходит все страницы существующих jobs, переиспользует первый `channel_reach_basic_a1` и создаёт job только если подходящего действительно нет. Параллельные вызовы `initialize()` объединяются.

## OneDrive archive

Каждый канал имеет собственный Graph client и базовую папку: `/0_0COD/01_0 CDMH AY/YouTube` для Conon & D и `/0_0COD/02_0 KADR AY/YouTube` для KADR19. Базовые папки должны существовать; код не создаёт их и не переключается на App Folder:

```text
snapshots/YYYY/MM/DD/<observed_at>--<snapshot_id>.json
reach-reports/YYYY/MM/<report_id>.csv
reach-reports/YYYY/MM/<report_id>.metadata.json
index/latest.json
index/videos.json
```

Snapshots, raw Reach CSV и Reach metadata immutable: они никогда не перезаписываются и не удаляются. Raw CSV сохраняется byte-for-byte. Изменяемы только два index-файла.

Каждый collector run заново собирает последние `COLLECTION_LOOKBACK_DAYS` завершённых дней (default `30`) и создаёт новый snapshot с единым `observed_at`. Поэтому последовательность поздних пересчётов вроде `83 → 91 → 88` остаётся в трёх наблюдениях для одного `metric_date`.

Перед сериализацией archive удаляются ключи, похожие на token, secret, authorization, password, cookie, private key или API key. Refresh/access tokens не передаются в OneDrive, MCP responses или logs.

## Cosmos runtime state

Database `cdmh-ay`, container `runtime-state`, partition key `/partitionKey`; оба документа используют значение `runtime`:

1. `microsoft-refresh-token` — общий OneDrive AES-256-GCM envelope, `updated_at`, временная rotation lease.
2. `google-collector-refresh-token:<channel_id>` — отдельный зашифрованный Google OAuth state каждого канала.
3. `collector-execution-lease` — owner, acquisition и expiry timestamps.

SDK создаётся только через:

```text
ManagedIdentityCredential({ clientId: AZURE_CLIENT_ID })
```

и `CosmosClient({ endpoint, aadCredentials })`. Account keys и connection strings код и environment не принимают. Bicep устанавливает `disableLocalAuth: true`.

Custom Cosmos data-plane role назначается общей Managed Identity на scope конкретного container и разрешает только account metadata read и item `read/create/replace`. Query, delete, stored procedures и control-plane действия не выдаются.

## Microsoft refresh-token rotation

Делегированные scopes `offline_access Files.ReadWrite`; для personal account `MICROSOFT_TENANT_ID=consumers`. После deployment владелец открывает `https://<web-host>/oauth/microsoft/start` в обычном браузере. Уже зарегистрированный Google callback проверяет email владельца, затем Microsoft consent использует PKCE и одноразовый state в Cosmos. Microsoft callback проверяет доступ ко всем настроенным корням каналов, включая `/0_0COD/01_0 CDMH AY/YouTube` и `/0_0COD/02_0 KADR AY/YouTube`, и только затем сохраняет новый refresh token в прежнем зашифрованном документе Cosmos. OAuth state истекает через 10 минут, повторное использование отклоняется. Ссылка для старта должна открываться непосредственно в браузере владельца: браузерные cookies связывают оба callback с начатым входом.

1. Процесс читает фиксированный token document и `_etag`.
2. Если документа нет, bootstrap refresh token шифруется в памяти и создаётся через `create`. При `409` проигравший процесс перечитывает документ победителя.
3. Процесс пытается записать короткую expiring lease через `replace` + `If-Match`.
4. При занятой lease выполняется bounded exponential backoff с jitter; expired lease можно забрать.
5. Только владелец lease вызывает Microsoft token endpoint.
6. Новый refresh token шифруется AES-256-GCM с новым 96-bit IV и AAD.
7. Rotation и снятие lease коммитятся одним conditional `replace` с актуальным ETag.
8. Access token попадает в memory cache только после успешного Cosmos commit.
9. При `412` состояние перечитывается и refresh повторяется ограниченное число раз. После crash lease истекает.

`MICROSOFT_REFRESH_TOKEN` нужен только для прежнего bootstrap; интерактивный consent может создать документ без него. После подтверждения наличия документа его следует удалить из secrets обеих workloads. Plaintext refresh token никогда не сохраняется.

## Collector lease

Перед любыми YouTube/OneDrive запросами CLI пытается получить `collector-execution-lease` через create или conditional replace истёкшего документа. Активная lease означает безопасный skip с успешным завершением Job. Lease живёт 65 минут, то есть немного дольше 60-минутного Job timeout; в `finally` lease переводится в expired state. После crash она автоматически становится доступна следующему запуску.

## Environment variables

| Переменная | Web | Job | Secret |
|---|:---:|:---:|:---:|
| `NODE_ENV` | ✓ | ✓ | нет |
| `PORT` | ✓ | — | нет |
| `PUBLIC_BASE_URL` | ✓ | — | нет |
| `GOOGLE_CLIENT_ID` | ✓ | ✓ | нет |
| `GOOGLE_CLIENT_SECRET` | ✓ | ✓ | да |
| `GOOGLE_REFRESH_TOKEN` | ✓ | ✓ | да |
| `YOUTUBE_CHANNEL_ID` | ✓ | ✓ | нет |
| `YOUTUBE_CHANNELS_JSON` | ✓ | ✓ | нет |
| `DEFAULT_CHANNEL_KEY` | ✓ | ✓ | нет |
| `OWNER_GOOGLE_EMAIL` | ✓ | — | приватное |
| `YT_REACH_JOB_ID` | ✓ | ✓ | нет |
| `MICROSOFT_CLIENT_ID` | ✓ | ✓ | нет |
| `MICROSOFT_CLIENT_SECRET` | ✓ | ✓ | да |
| `MICROSOFT_REFRESH_TOKEN` | bootstrap | bootstrap | да |
| `MICROSOFT_TENANT_ID` | ✓ | ✓ | нет |
| `MICROSOFT_TOKEN_ENCRYPTION_KEY` | ✓ | ✓ | да |
| `AZURE_COSMOS_ENDPOINT` | ✓ | ✓ | нет |
| `AZURE_COSMOS_DATABASE_NAME` | ✓ | ✓ | нет |
| `AZURE_COSMOS_CONTAINER_NAME` | ✓ | ✓ | нет |
| `AZURE_CLIENT_ID` | ✓ | ✓ | нет |
| `MCP_TOKEN_SIGNING_SECRET` | ✓ | — | да |
| `MCP_ACCESS_TOKEN_TTL_SECONDS` | ✓ | — | нет |
| `MCP_REFRESH_TOKEN_TTL_SECONDS` | ✓ | — | нет |
| `COLLECTION_LOOKBACK_DAYS` | ✓ | ✓ | нет |
| `COLLECTOR_CONCURRENCY` | ✓ | ✓ | нет |

Cron не является env variable; это обязательный deployment parameter `collectorCronUtc`.

## Infrastructure as Code

`infra/main.bicep` имеет `targetScope = 'resourceGroup'`: Resource Group создаётся отдельной subscription-level командой, после явного подтверждения, а шаблон разворачивается incremental deployment внутри неё. Это отделяет billing/location boundary от ресурсов приложения и упрощает `what-if`.

Secret parameters помечены `@secure()`. `infra/main.bicepparam.example` не содержит secret values: он читает их из environment процесса deployment через `readEnvironmentVariable()`.

Шаблон создаёт:

- user-assigned Managed Identity;
- Container Apps managed environment без log destination;
- Web Container App;
- scheduled Container Apps Job;
- Cosmos DB Free Tier account;
- SQL database и provisioned 400 RU/s container;
- custom Cosmos SQL role definition и assignment.

## Local verification

```bash
npm ci
npm run check
npm test
npm run build
npm audit
```

`npm run start` запускает Web. `npm run collect` запускает one-shot collector с distributed lease.

## Deployment plan (не выполнен)

1. Подтвердить Azure region, имена и UTC cron.
2. Создать/выбрать бесплатный GitHub account и GHCR namespace; он нужен перед сборкой/push image. Опубликовать package публично либо отдельно добавить registry credentials (текущий Bicep рассчитан на public GHCR).
3. Выполнить локальные tests/build/audit и Docker build; присвоить immutable version tag, не `latest`.
4. Войти в Azure CLI; проверить subscription, Free Tier eligibility и доступность региона.
5. Создать Resource Group только после явного подтверждения.
6. Выполнить `az deployment group what-if` с `.bicepparam`; проверить отсутствие неожиданных/платных ресурсов.
7. После отдельного подтверждения выполнить deployment.
8. Зарегистрировать Google/Microsoft redirect URIs из output `webBaseUrl`, пройти login/consent/2FA.
9. Проверить health, OAuth metadata, MCP connect и вручную запустить один collector execution.
10. Проверить два Cosmos documents и OneDrive App Folder; убедиться, что plaintext token отсутствует.
11. Удалить bootstrap `MICROSOFT_REFRESH_TOKEN` из Web/Job secrets после успешной rotation/bootstrap проверки.
12. Включить подтверждённое расписание и наблюдать первые executions через Job status/metrics, без Log Analytics.

Ни один шаг deployment из этого списка текущей подготовкой не выполнялся.
