import assert from "node:assert/strict";
import test from "node:test";
import { SnapshotStore, serializeArchiveValue } from "../src/archive/snapshot-store.js";
import type { ArchiveBackend } from "../src/archive/snapshot-store.js";

class MemoryBackend implements ArchiveBackend {
  readonly files = new Map<string, string | Uint8Array>();

  async readText(path: string): Promise<string | null> {
    const value = this.files.get(path);
    if (value === undefined) return null;
    return typeof value === "string" ? value : new TextDecoder().decode(value);
  }

  async putImmutableFile(
    path: string,
    content: string | Uint8Array,
    _contentType: string,
    onExisting: "error" | "skip" = "error",
  ): Promise<{ created: boolean }> {
    if (this.files.has(path)) {
      if (onExisting === "skip") return { created: false };
      throw new Error("immutable conflict");
    }
    this.files.set(path, content);
    return { created: true };
  }

  async upsertFile(path: string, content: string | Uint8Array): Promise<void> {
    this.files.set(path, content);
  }

  async listFiles(path: string) {
    return [...this.files.keys()]
      .filter((file) => file === path || file.startsWith(`${path}/`))
      .map((file) => ({ path: file, id: file, name: file.split("/").at(-1)! }));
  }
}

test("uses date-partitioned immutable snapshot names and refuses overwrite", async () => {
  const backend = new MemoryBackend();
  const store = new SnapshotStore(backend);
  const snapshot = {
    schema_version: 1 as const,
    snapshot_id: "00000000-0000-4000-8000-000000000001",
    observed_at: "2026-09-15T12:34:56.789Z",
    channel_id: "UCAAAAAAAAAAAAAAAAAAAAAA",
    collection_window: { start_date: "2026-08-16", end_date: "2026-09-14" },
    records: [],
  };
  const path = await store.saveSnapshot(snapshot);
  assert.equal(
    path,
    "snapshots/2026/09/15/2026-09-15T12-34-56-789Z--00000000-0000-4000-8000-000000000001.json",
  );
  await assert.rejects(store.saveSnapshot(snapshot), /immutable conflict/);
});

test("handles an archive that has no snapshots or index yet", async () => {
  const store = new SnapshotStore(new MemoryBackend());
  assert.deepEqual(await store.listSnapshots(), []);
  assert.equal(await store.readLatest(), null);
});

test("removes secret-bearing keys before archive serialization", () => {
  const serialized = serializeArchiveValue({
    observed_at: "2026-09-15T00:00:00.000Z",
    metrics: { views: 91 },
    access_token: "must-not-appear",
    nested: {
      client_secret: "must-not-appear",
      refreshToken: "must-not-appear",
      safe: "kept",
    },
  });
  assert.equal(serialized.includes("must-not-appear"), false);
  assert.deepEqual(JSON.parse(serialized), {
    observed_at: "2026-09-15T00:00:00.000Z",
    metrics: { views: 91 },
    nested: { safe: "kept" },
  });
});

test("stores a new raw Reach CSV without changing its bytes and never overwrites it", async () => {
  const backend = new MemoryBackend();
  const store = new SnapshotStore(backend);
  const raw = new Uint8Array([0xef, 0xbb, 0xbf, 0x61, 0x2c, 0x62, 0x0d, 0x0a]);
  const metadata = {
    report_id: "report-1",
    job_id: "job-1",
    create_time: "2026-09-15T03:00:00Z",
    start_time: "2026-09-14T00:00:00Z",
    end_time: "2026-09-15T00:00:00Z",
    covered_period: { start_date: "2026-09-14", end_date: "2026-09-14" },
  };
  const first = await store.saveRawReachReport(metadata, raw, "2026-09-15T04:00:00Z");
  const second = await store.saveRawReachReport(metadata, new Uint8Array([1, 2, 3]), "2026-09-16T04:00:00Z");
  assert.equal(first.created, true);
  assert.equal(second.created, false);
  assert.deepEqual(backend.files.get(first.csvPath), raw);
});
