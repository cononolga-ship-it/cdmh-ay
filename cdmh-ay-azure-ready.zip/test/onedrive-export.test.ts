import assert from "node:assert/strict";
import test from "node:test";
import type { CollectionResult } from "../src/archive/collector.js";
import { SnapshotStore, type ArchiveBackend } from "../src/archive/snapshot-store.js";
import { OneDriveExportQueue, type OneDriveExportTask } from "../src/onedrive/export-queue.js";
import { OneDriveSnapshotExporter } from "../src/onedrive/exporter.js";
import { OneDriveGraphClient, type OneDriveItem } from "../src/onedrive/graph-client.js";
import { runOneDriveExportPostStep } from "../src/onedrive/post-step.js";
import { OneDriveTokenStore } from "../src/onedrive/token-store.js";
import { MemoryRuntimeStateStore } from "./runtime-state-memory.js";

class MemoryArchive implements ArchiveBackend {
  readonly files = new Map<string, string | Uint8Array>();

  async readText(path: string): Promise<string | null> {
    const value = this.files.get(path);
    if (value === undefined) return null;
    return typeof value === "string" ? value : new TextDecoder().decode(value);
  }

  async putImmutableFile(path: string, content: string | Uint8Array): Promise<{ created: boolean }> {
    if (this.files.has(path)) return { created: false };
    this.files.set(path, content);
    return { created: true };
  }

  async upsertFile(path: string, content: string | Uint8Array): Promise<void> {
    this.files.set(path, content);
  }

  async listFiles(path: string) {
    return [...this.files.keys()]
      .filter((value) => value === path || value.startsWith(`${path}/`))
      .map((value) => ({ path: value, id: value, name: value.split("/").at(-1)! }));
  }
}

class MemoryGraph extends OneDriveGraphClient {
  readonly files = new Map<string, Uint8Array>();
  writes = 0;

  constructor() {
    super({ getAccessToken: async () => "test" });
  }

  override async ensureFolderPath(path: string): Promise<OneDriveItem> {
    return { id: path, name: path.split("/").at(-1)!, folder: {} };
  }

  override async putFile(path: string, content: string | Uint8Array): Promise<OneDriveItem> {
    this.writes += 1;
    const bytes = typeof content === "string" ? new TextEncoder().encode(content) : content;
    this.files.set(path, bytes);
    return { id: path, name: path.split("/").at(-1)!, size: bytes.byteLength, file: {} };
  }

  override async readFile(path: string): Promise<Uint8Array | null> {
    return this.files.get(path) ?? null;
  }

  override async listFolder(path: string): Promise<OneDriveItem[]> {
    const prefix = `${path}/`;
    return [...this.files.entries()]
      .filter(([name]) => name.startsWith(prefix) && !name.slice(prefix.length).includes("/"))
      .map(([name, value]) => ({ id: name, name: name.slice(prefix.length), size: value.byteLength, file: {} }));
  }
}

async function fixture() {
  const backend = new MemoryArchive();
  const store = new SnapshotStore(backend);
  const observedAt = "2026-10-03T04:00:00.000Z";
  const report = {
    report_id: "reach-report-1",
    job_id: "job-1",
    create_time: "2026-10-03T03:00:00Z",
    start_time: "2026-10-02T00:00:00Z",
    end_time: "2026-10-03T00:00:00Z",
    covered_period: { start_date: "2026-10-02", end_date: "2026-10-02" },
  };
  const savedReport = await store.saveRawReachReport(
    report,
    new TextEncoder().encode("date,video_id\n2026-10-02,abcdefghijk\n"),
    observedAt,
  );
  const snapshot = store.createSnapshot({
    observed_at: observedAt,
    channel_id: "UCAAAAAAAAAAAAAAAAAAAAAA",
    collection_window: { start_date: "2026-10-02", end_date: "2026-10-02" },
    records: [],
  });
  const snapshotPath = await store.saveSnapshot(snapshot);
  const task: OneDriveExportTask = {
    channel_key: "conon_d",
    snapshot_id: snapshot.snapshot_id,
    observed_at: observedAt,
    snapshot_path: snapshotPath,
    reach_reports: [{
      report_id: report.report_id,
      csv_path: savedReport.csvPath,
      metadata_path: savedReport.metadataPath,
    }],
  };
  return { store, task };
}

test("exports a verified snapshot bundle and reuses the same snapshot folder idempotently", async () => {
  const { store, task } = await fixture();
  const graph = new MemoryGraph();
  const exporter = new OneDriveSnapshotExporter(graph, "CDMH AY/YouTube");

  const first = await exporter.export(task, store);
  const writesAfterFirst = graph.writes;
  const second = await exporter.export(task, store);

  assert.equal(first.alreadyExported, false);
  assert.equal(first.files, 4);
  assert.equal(second.alreadyExported, true);
  assert.equal(graph.writes, writesAfterFirst);
  assert.equal(
    [...graph.files.keys()].filter((path) => path.endsWith("/manifest.json")).length,
    1,
  );
  const manifest = JSON.parse(Buffer.from(graph.files.get(`${first.targetPath}/manifest.json`)!).toString("utf8"));
  assert.equal(manifest.snapshot_id, task.snapshot_id);
  assert.deepEqual(manifest.files.map((value: { relative_path: string }) => value.relative_path), [
    "snapshot.json",
    "reach/reach-report-1.csv",
    "reach/reach-report-1.metadata.json",
  ]);
});

test("keeps collection successful and the export pending when OneDrive is unavailable", async () => {
  const { store, task } = await fixture();
  const state = new MemoryRuntimeStateStore();
  const queue = new OneDriveExportQueue(state);
  const collection: CollectionResult = {
    observedAt: task.observed_at,
    period: { startDate: "2026-10-02", endDate: "2026-10-02" },
    videos: 1,
    records: 1,
    rawReportsCreated: 1,
    snapshotId: task.snapshot_id,
    snapshotPath: task.snapshot_path,
    reachReports: task.reach_reports,
  };
  const unavailable = {
    export: async () => { throw new Error("simulated unavailable"); },
  } as unknown as OneDriveSnapshotExporter;

  const result = await runOneDriveExportPostStep("conon_d", collection, store, { queue, exporter: unavailable });

  assert.equal(result.status, "pending");
  assert.equal((await queue.listPending("conon_d")).length, 1);
  assert.equal((await queue.readStatus("conon_d", task.snapshot_id))?.last_error_code, "onedrive_export_failed");

  const recovered = await runOneDriveExportPostStep("conon_d", collection, store, {
    queue,
    exporter: new OneDriveSnapshotExporter(new MemoryGraph(), "CDMH AY/YouTube"),
  });
  assert.equal(recovered.status, "completed");
  assert.equal((await queue.listPending("conon_d")).length, 0);
});

test("stores the OneDrive refresh token encrypted in runtime state", async () => {
  const state = new MemoryRuntimeStateStore();
  const store = new OneDriveTokenStore(state, new Uint8Array(32).fill(9));
  await store.saveAuthorizedToken("sensitive-refresh-token", {
    id: "account-1",
    display_name: "Archive Account",
    user_principal_name: "archive@example.test",
  });

  assert.equal(JSON.stringify([...state.documents.values()]).includes("sensitive-refresh-token"), false);
  assert.equal((await store.readRequired()).refreshToken, "sensitive-refresh-token");
});
