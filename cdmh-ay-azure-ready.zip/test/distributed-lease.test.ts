import assert from "node:assert/strict";
import test from "node:test";
import { CollectorDistributedLease } from "../src/azure/distributed-lease.js";
import { MemoryRuntimeStateStore } from "./runtime-state-memory.js";

test("collector lease acquisition rejects an overlapping execution", async () => {
  const state = new MemoryRuntimeStateStore();
  const first = new CollectorDistributedLease(state, "first", 60_000, () => 1_000);
  const second = new CollectorDistributedLease(state, "second", 60_000, () => 1_001);
  assert.ok(await first.acquire());
  assert.equal(await second.acquire(), null);
});

test("collector lease conflict permits only one concurrent creator", async () => {
  const state = new MemoryRuntimeStateStore();
  let arrivals = 0;
  let release!: () => void;
  const barrier = new Promise<void>((resolve) => { release = resolve; });
  state.createBarrier = async () => {
    arrivals += 1;
    if (arrivals === 2) release();
    await barrier;
  };
  const leases = await Promise.all([
    new CollectorDistributedLease(state, "first", 60_000, () => 1_000).acquire(),
    new CollectorDistributedLease(state, "second", 60_000, () => 1_000).acquire(),
  ]);
  assert.equal(leases.filter(Boolean).length, 1);
});

test("expired collector lease can be acquired by a later execution", async () => {
  const state = new MemoryRuntimeStateStore();
  assert.ok(await new CollectorDistributedLease(state, "first", 100, () => 1_000).acquire());
  const replacement = await new CollectorDistributedLease(state, "second", 100, () => 1_101).acquire();
  assert.equal(replacement?.document.owner_id, "second");
});

test("overlapping collector operation is not executed", async () => {
  const state = new MemoryRuntimeStateStore();
  const first = new CollectorDistributedLease(state, "first", 60_000, () => 1_000);
  const second = new CollectorDistributedLease(state, "second", 60_000, () => 1_001);
  const held = await first.acquire();
  assert.ok(held);
  let called = false;
  const result = await second.runExclusive(async () => { called = true; });
  assert.deepEqual(result, { executed: false });
  assert.equal(called, false);
});
