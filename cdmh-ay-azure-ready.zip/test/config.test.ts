import assert from "node:assert/strict";
import test from "node:test";
import { loadConfig } from "../src/config.js";

const baseEnv: NodeJS.ProcessEnv = {
  NODE_ENV: "test",
  PUBLIC_BASE_URL: "https://mcp.example.test",
  YOUTUBE_CHANNEL_ID: "UCAAAAAAAAAAAAAAAAAAAAAA",
  OWNER_GOOGLE_EMAIL: "owner@example.test",
  GOOGLE_CLIENT_ID: "fake-client-id",
  GOOGLE_CLIENT_SECRET: "fake-client-secret",
  GOOGLE_REFRESH_TOKEN: "fake-refresh-token",
  MICROSOFT_CLIENT_ID: "fake-microsoft-client-id",
  MICROSOFT_CLIENT_SECRET: "fake-microsoft-client-secret",
  MICROSOFT_TENANT_ID: "consumers",
  MICROSOFT_TOKEN_ENCRYPTION_KEY: Buffer.alloc(32, 7).toString("base64"),
  AZURE_COSMOS_ENDPOINT: "https://cosmos.example.test",
  AZURE_COSMOS_DATABASE_NAME: "cdmh-ay",
  AZURE_COSMOS_CONTAINER_NAME: "runtime-state",
  AZURE_CLIENT_ID: "00000000-0000-4000-8000-000000000001",
  MCP_TOKEN_SIGNING_SECRET: "fake-signing-secret-that-is-at-least-32-chars",
};

test("allows startup without a Microsoft bootstrap token when Cosmos state exists", () => {
  const config = loadConfig(baseEnv);
  assert.equal(config.microsoftBootstrapRefreshToken, undefined);
  assert.equal(config.azureCosmosContainerName, "runtime-state");
});

test("requires the explicit user-assigned Managed Identity client ID", () => {
  const { AZURE_CLIENT_ID: _removed, ...withoutIdentity } = baseEnv;
  assert.throws(
    () => loadConfig(withoutIdentity),
    /AZURE_CLIENT_ID/,
  );
});

test("accepts the same Managed Identity Cosmos configuration in production", () => {
  assert.equal(loadConfig({ ...baseEnv, NODE_ENV: "production" }).nodeEnv, "production");
});
