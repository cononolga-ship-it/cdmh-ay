import assert from "node:assert/strict";
import test from "node:test";
import { loadConfig } from "../src/config.js";

const baseEnv: NodeJS.ProcessEnv = {
  NODE_ENV: "test",
  PUBLIC_BASE_URL: "https://mcp.example.test",
  YOUTUBE_CHANNEL_ID: "UCAAAAAAAAAAAAAAAAAAAAAA",
  OWNER_GOOGLE_EMAIL: "owner@example.test",
  GOOGLE_CLIENT_ID: "fake-client-id",
  GOOGLE_CLIENT_SECRET: "fake-client-secret",
  GOOGLE_REFRESH_TOKEN: "fake-refresh-token",
  RUNTIME_STATE_ENCRYPTION_KEY: Buffer.alloc(32, 7).toString("base64"),
  AZURE_COSMOS_ENDPOINT: "https://cosmos.example.test",
  AZURE_COSMOS_DATABASE_NAME: "cdmh-ay",
  AZURE_COSMOS_CONTAINER_NAME: "runtime-state",
  AZURE_CLIENT_ID: "00000000-0000-4000-8000-000000000001",
  MCP_TOKEN_SIGNING_SECRET: "fake-signing-secret-that-is-at-least-32-chars",
};

test("loads Cosmos runtime state without Microsoft configuration", () => {
  const config = loadConfig(baseEnv);
  assert.equal(config.azureCosmosContainerName, "runtime-state");
  assert.equal(config.runtimeStateEncryptionKey.byteLength, 32);
});

test("requires the explicit user-assigned Managed Identity client ID", () => {
  const { AZURE_CLIENT_ID: _removed, ...withoutIdentity } = baseEnv;
  assert.throws(
    () => loadConfig(withoutIdentity),
    /AZURE_CLIENT_ID/,
  );
});

test("accepts the same Managed Identity Cosmos configuration in production", () => {
  assert.equal(loadConfig({ ...baseEnv, NODE_ENV: "production" }).nodeEnv, "production");
});

test("loads two isolated channel definitions while preserving Conon as default", () => {
  const config = loadConfig({
    ...baseEnv,
    YOUTUBE_CHANNELS_JSON: JSON.stringify([
      {
        key: "conon_d",
        name: "Conon & D Media House",
        youtubeChannelId: "UCAAAAAAAAAAAAAAAAAAAAAA",
      },
      {
        key: "kadr19",
        name: "KADR19",
        youtubeChannelId: "UCQ2_fcbA4Y60tCYqULn7YRg",
        ownerGoogleEmail: "KADRGRUPPA@gmail.com",
      },
    ]),
  });
  assert.equal(config.defaultChannelKey, "conon_d");
  assert.equal(config.ownerGoogleEmail, "owner@example.test");
  assert.equal(config.channels[0]?.ownerGoogleEmail, undefined);
  assert.equal(config.channels[1]?.ownerGoogleEmail, "kadrgruppa@gmail.com");
  assert.deepEqual(config.channels.map(({ key }) => key), ["conon_d", "kadr19"]);
});

test("rejects an invalid channel-specific Google owner", () => {
  assert.throws(() => loadConfig({
    ...baseEnv,
    YOUTUBE_CHANNELS_JSON: JSON.stringify([{
      key: "kadr19", name: "KADR19", youtubeChannelId: "UCQ2_fcbA4Y60tCYqULn7YRg",
      ownerGoogleEmail: "not-an-email",
    }]),
    DEFAULT_CHANNEL_KEY: "kadr19",
  }), /YOUTUBE_CHANNELS_JSON/);
});

test("rejects duplicate channel IDs", () => {
  const duplicate = [
    { key: "conon_d", name: "Conon", youtubeChannelId: "UCAAAAAAAAAAAAAAAAAAAAAA" },
    { key: "kadr19", name: "KADR19", youtubeChannelId: "UCAAAAAAAAAAAAAAAAAAAAAA" },
  ];
  assert.throws(
    () => loadConfig({ ...baseEnv, YOUTUBE_CHANNELS_JSON: JSON.stringify(duplicate) }),
    /YOUTUBE_CHANNELS_JSON/,
  );
});
