import assert from "node:assert/strict";
import test from "node:test";
import express from "express";
import { loadConfig } from "../src/config.js";
import { createGoogleCollectorConsentRouter } from "../src/google/consent-routes.js";
import { MemoryRuntimeStateStore } from "./runtime-state-memory.js";
import type { CosmosGoogleTokenStore } from "../src/google/cosmos-token-store.js";
import type { AppRuntime } from "../src/runtime.js";

test("channel consent lasts 30 minutes and callback exposes only a fixed failure step", async () => {
  const config = loadConfig({
    NODE_ENV: "test",
    PUBLIC_BASE_URL: "https://mcp.example.test",
    OWNER_GOOGLE_EMAIL: "owner@example.test",
    YOUTUBE_CHANNEL_ID: "UCQ2_fcbA4Y60tCYqULn7YRg",
    DEFAULT_CHANNEL_KEY: "kadr19",
    GOOGLE_CLIENT_ID: "test-client",
    GOOGLE_CLIENT_SECRET: "test-secret",
    GOOGLE_REFRESH_TOKEN: "test-refresh-token",
    MICROSOFT_CLIENT_ID: "test-microsoft-client",
    MICROSOFT_CLIENT_SECRET: "test-microsoft-secret",
    MICROSOFT_TENANT_ID: "consumers",
    MICROSOFT_TOKEN_ENCRYPTION_KEY: Buffer.alloc(32, 7).toString("base64"),
    AZURE_COSMOS_ENDPOINT: "https://cosmos.example.test",
    AZURE_COSMOS_DATABASE_NAME: "cdmh-ay",
    AZURE_COSMOS_CONTAINER_NAME: "runtime-state",
    AZURE_CLIENT_ID: "00000000-0000-4000-8000-000000000001",
    MCP_TOKEN_SIGNING_SECRET: "fake-signing-secret-that-is-at-least-32-chars",
    YOUTUBE_CHANNELS_JSON: JSON.stringify([
      { key: "kadr19", name: "KADR19", youtubeChannelId: "UCQ2_fcbA4Y60tCYqULn7YRg", archiveRoot: "0_0COD/02_0 KADR AY/YouTube", ownerGoogleEmail: "kadrgruppa@gmail.com" },
    ]),
  });
  const state = new MemoryRuntimeStateStore();
  const app = express();
  app.use(createGoogleCollectorConsentRouter(config, state, {} as CosmosGoogleTokenStore, {} as AppRuntime));
  const server = app.listen(0, "127.0.0.1");
  try {
    await new Promise<void>((resolve) => server.once("listening", resolve));
    const address = server.address();
    assert.ok(address && typeof address !== "string");
    const base = `http://127.0.0.1:${address.port}`;
    const started = await fetch(`${base}/oauth/google/collector/kadr19/start`, { redirect: "manual" });
    assert.equal(started.status, 302);
    assert.match(started.headers.get("set-cookie") ?? "", /Max-Age=1800/);
    assert.equal(new URL(started.headers.get("location")!).searchParams.get("login_hint"), "kadrgruppa@gmail.com");
    const documents = [...state.documents.values()];
    assert.equal(documents.length, 1);
    assert.ok(documents[0]);
    assert.equal((documents[0].document as unknown as { channel_key: string }).channel_key, "kadr19");
    const fakeState = "A".repeat(43);
    const failed = await fetch(`${base}/oauth/google/callback?state=gi.${fakeState}&code=sensitive-code`);
    assert.equal(failed.status, 400);
    const body = await failed.text();
    assert.match(body, /step: state_cookie/);
    assert.doesNotMatch(body, /sensitive-code|AAAAAAA/);
    assert.equal(failed.headers.get("cache-control"), "no-store");
  } finally {
    server.close();
  }
});
