import test from "node:test";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { MCP_SCOPE, TokenService } from "../src/auth/tokens.js";
import { testConfig as config } from "./helpers.js";

test("issues verifiable MCP access and refresh tokens", async () => {
  const service = new TokenService(config);
  const clientId = await service.registerClient({
    clientName: "test",
    redirectUris: ["https://chatgpt.com/connector_platform_oauth_redirect"],
  });
  const client = await service.verifyClient(clientId);
  assert.deepEqual(client.redirectUris, ["https://chatgpt.com/connector_platform_oauth_redirect"]);

  const clientIdHash = service.hashClientId(clientId);
  const pair = await service.issueTokenPair(clientIdHash);
  assert.equal(pair.scope, MCP_SCOPE);
  assert.equal((await service.verifyAccessToken(pair.access_token)).sub, config.ownerGoogleEmail);
  assert.deepEqual(await service.verifyRefreshToken(pair.refresh_token), {
    clientIdHash,
    scope: MCP_SCOPE,
  });
});

test("checks an S256 PKCE verifier", () => {
  const service = new TokenService(config);
  const verifier = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-._~";
  const challenge = createHash("sha256").update(verifier).digest("base64url");
  assert.equal(service.verifyPkce(verifier, challenge), true);
  assert.equal(service.verifyPkce(`${verifier}x`, challenge), false);
});
