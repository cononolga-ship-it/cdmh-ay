import assert from "node:assert/strict";
import test from "node:test";
import { CosmosMicrosoftTokenStore, MICROSOFT_TOKEN_DOCUMENT_ID } from "../src/microsoft/cosmos-token-store.js";
import { MicrosoftTokenProvider } from "../src/microsoft/onedrive-auth.js";
import { MicrosoftTokenCipher } from "../src/microsoft/token-crypto.js";
import { testConfig } from "./helpers.js";
import { MemoryRuntimeStateStore } from "./runtime-state-memory.js";

const key = new Uint8Array(32).fill(19);

test("AES-256-GCM encrypts/decrypts and Cosmos state has no plaintext token", async () => {
  const cipher = new MicrosoftTokenCipher(key);
  const envelope = cipher.encrypt("refresh-token-plaintext-marker");
  assert.equal(cipher.decrypt(envelope), "refresh-token-plaintext-marker");
  assert.equal(JSON.stringify(envelope).includes("refresh-token-plaintext-marker"), false);

  const state = new MemoryRuntimeStateStore();
  const tokens = new CosmosMicrosoftTokenStore(state, cipher, "bootstrap-plaintext-marker");
  const lease = await tokens.acquireRotationLease();
  await tokens.commitRotation(lease, "rotated-plaintext-marker");
  assert.equal(JSON.stringify([...state.documents.values()]).includes("plaintext-marker"), false);
});

test("bootstrap 409 race keeps the single winning encrypted document", async () => {
  const state = new MemoryRuntimeStateStore();
  let arrivals = 0;
  let release!: () => void;
  const barrier = new Promise<void>((resolve) => { release = resolve; });
  state.createBarrier = async () => {
    arrivals += 1;
    if (arrivals === 2) release();
    await barrier;
  };
  const first = new CosmosMicrosoftTokenStore(state, new MicrosoftTokenCipher(key), "bootstrap-a", {
    ownerId: "a", sleep: async () => undefined, maxAttempts: 2,
  });
  const second = new CosmosMicrosoftTokenStore(state, new MicrosoftTokenCipher(key), "bootstrap-b", {
    ownerId: "b", sleep: async () => undefined, maxAttempts: 2,
  });
  const results = await Promise.allSettled([first.acquireRotationLease(), second.acquireRotationLease()]);
  assert.equal(state.documents.size, 1);
  assert.equal(results.filter((result) => result.status === "fulfilled").length, 1);
  assert.ok(state.documents.has(MICROSOFT_TOKEN_DOCUMENT_ID));
});

test("two processes serialize Microsoft refresh rotation", async () => {
  const state = new MemoryRuntimeStateStore();
  let active = 0;
  let maxActive = 0;
  let calls = 0;
  const fakeFetch: typeof fetch = async () => {
    calls += 1;
    const call = calls;
    active += 1;
    maxActive = Math.max(maxActive, active);
    await new Promise((resolve) => setTimeout(resolve, 5));
    active -= 1;
    return Response.json({ access_token: `access-${call}`, refresh_token: `refresh-${call}`, expires_in: 3600 });
  };
  const options = { sleep: () => new Promise<void>((resolve) => setTimeout(resolve, 1)), maxAttempts: 100 };
  const one = new MicrosoftTokenProvider(testConfig,
    new CosmosMicrosoftTokenStore(state, new MicrosoftTokenCipher(key), "bootstrap", { ...options, ownerId: "one" }), fakeFetch);
  const two = new MicrosoftTokenProvider(testConfig,
    new CosmosMicrosoftTokenStore(state, new MicrosoftTokenCipher(key), "bootstrap", { ...options, ownerId: "two" }), fakeFetch);
  const results = await Promise.all([one.getAccessToken(), two.getAccessToken()]);
  assert.equal(maxActive, 1);
  assert.equal(calls, 2);
  assert.deepEqual(results.sort(), ["access-1", "access-2"]);
});

test("Microsoft rotation lease conflicts while active and can be taken after expiry", async () => {
  const state = new MemoryRuntimeStateStore();
  const first = new CosmosMicrosoftTokenStore(state, new MicrosoftTokenCipher(key), "bootstrap", {
    ownerId: "first", now: () => 1_000, leaseMs: 100, maxAttempts: 1, sleep: async () => undefined,
  });
  assert.ok(await first.acquireRotationLease());

  const blocked = new CosmosMicrosoftTokenStore(state, new MicrosoftTokenCipher(key), undefined, {
    ownerId: "blocked", now: () => 1_050, maxAttempts: 1, sleep: async () => undefined,
  });
  await assert.rejects(blocked.acquireRotationLease(), /temporarily busy/i);

  const afterExpiry = new CosmosMicrosoftTokenStore(state, new MicrosoftTokenCipher(key), undefined, {
    ownerId: "after-expiry", now: () => 1_101, maxAttempts: 1, sleep: async () => undefined,
  });
  assert.equal((await afterExpiry.acquireRotationLease()).ownerId, "after-expiry");
});

test("HTTP 412 during durable commit causes reread and bounded retry", async () => {
  const state = new MemoryRuntimeStateStore();
  state.conflictReplaceCall = 2;
  let calls = 0;
  const provider = new MicrosoftTokenProvider(
    testConfig,
    new CosmosMicrosoftTokenStore(state, new MicrosoftTokenCipher(key), "bootstrap", {
      ownerId: "process", sleep: async () => undefined, random: () => 0, maxAttempts: 10,
    }),
    async () => {
      calls += 1;
      return Response.json({ access_token: `access-${calls}`, refresh_token: `refresh-${calls}`, expires_in: 3600 });
    },
  );
  assert.equal(await provider.getAccessToken(), "access-2");
  assert.equal(calls, 2);
});

test("wrong AES key fails without leaking token", () => {
  const encrypted = new MicrosoftTokenCipher(new Uint8Array(32).fill(1)).encrypt("never-leak-this-token");
  assert.throws(() => new MicrosoftTokenCipher(new Uint8Array(32).fill(2)).decrypt(encrypted), (error: Error) => {
    assert.equal(error.message.includes("never-leak-this-token"), false);
    return true;
  });
});

test("interactive consent initializes an encrypted Cosmos token without bootstrap", async () => {
  const state = new MemoryRuntimeStateStore();
  const tokens = new CosmosMicrosoftTokenStore(state, new MicrosoftTokenCipher(key));
  await tokens.saveAuthorizedToken("consent-refresh-marker");
  assert.equal(JSON.stringify([...state.documents.values()]).includes("consent-refresh-marker"), false);
  const lease = await tokens.acquireRotationLease();
  assert.equal(lease.refreshToken, "consent-refresh-marker");
  await tokens.commitRotation(lease, "rotated-refresh-marker");
  await tokens.saveAuthorizedToken("new-consent-marker");
  assert.equal((await tokens.acquireRotationLease()).refreshToken, "new-consent-marker");
});
