import test from "node:test";
import assert from "node:assert/strict";
import { addUtcDays, validateDateRange } from "../src/utils/dates.js";

test("validates an inclusive date range", () => {
  assert.deepEqual(validateDateRange("2026-01-01", "2026-01-31"), {
    startDate: "2026-01-01",
    endDate: "2026-01-31",
  });
});

test("rejects impossible and reversed dates", () => {
  assert.throws(() => validateDateRange("2026-02-30", "2026-03-01"));
  assert.throws(() => validateDateRange("2026-03-02", "2026-03-01"));
});

test("adds UTC days across month boundaries", () => {
  assert.equal(addUtcDays("2026-02-28", 1), "2026-03-01");
});
