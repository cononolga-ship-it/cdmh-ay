import assert from "node:assert/strict";
import test from "node:test";
import { metricHistory, metricRevisions, snapshotDiff } from "../src/archive/revisions.js";
import type { ArchiveSnapshot } from "../src/archive/types.js";

const videoId = "abcdefghijk";
const channelId = "UCAAAAAAAAAAAAAAAAAAAAAA";

function snapshot(observedAt: string, views: number, likes = 1): ArchiveSnapshot {
  return {
    schema_version: 1,
    snapshot_id: observedAt,
    observed_at: observedAt,
    channel_id: channelId,
    collection_window: { start_date: "2026-09-01", end_date: "2026-09-15" },
    records: [{
      observed_at: observedAt,
      metric_date: "2026-09-15",
      video_id: videoId,
      channel_id: channelId,
      source: "youtube_analytics",
      metrics: { views, likes },
    }],
  };
}

test("returns every observed value for a metric date", () => {
  const snapshots = [
    snapshot("2026-09-16T01:00:00.000Z", 83),
    snapshot("2026-09-17T01:00:00.000Z", 91),
    snapshot("2026-09-18T01:00:00.000Z", 88),
  ];
  assert.deepEqual(
    metricHistory(snapshots, videoId, "views", "2026-09-15", "2026-09-15")
      .map((row) => row.value),
    [83, 91, 88],
  );
});

test("detects revisions of the same metric_date", () => {
  const revisions = metricRevisions([
    snapshot("2026-09-16T01:00:00.000Z", 83),
    snapshot("2026-09-17T01:00:00.000Z", 91),
    snapshot("2026-09-18T01:00:00.000Z", 88),
  ], videoId, "2026-09-15", "2026-09-15");
  assert.equal(revisions.length, 1);
  assert.deepEqual(revisions[0]!.changed_metrics, ["views"]);
  assert.deepEqual(revisions[0]!.observations.map((item) => item.metrics.views), [83, 91, 88]);
});

test("diffs two snapshots and includes numeric deltas", () => {
  const diff = snapshotDiff(
    snapshot("2026-09-16T01:00:00.000Z", 83, 4),
    snapshot("2026-09-17T01:00:00.000Z", 91, 5),
    videoId,
  );
  assert.equal(diff.length, 1);
  assert.deepEqual(diff[0], {
    source: "youtube_analytics",
    metric_date: "2026-09-15",
    status: "changed",
    changes: [
      { metric: "likes", before: 4, after: 5, delta: 1 },
      { metric: "views", before: 83, after: 91, delta: 8 },
    ],
  });
});

test("snapshot diff reports added and removed states", () => {
  const before = snapshot("2026-09-16T01:00:00.000Z", 83);
  const after = snapshot("2026-09-17T01:00:00.000Z", 91);
  after.records[0]!.metric_date = "2026-09-16";
  const diff = snapshotDiff(before, after, videoId);
  assert.deepEqual(diff.map((item) => item.status), ["removed", "added"]);
});
