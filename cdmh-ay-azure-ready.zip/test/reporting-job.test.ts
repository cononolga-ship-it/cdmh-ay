import assert from "node:assert/strict";
import test from "node:test";
import type { GoogleApis, GoogleAuth } from "../src/google/client.js";
import { YoutubeReportingService } from "../src/google/youtube-reporting.js";
import { testConfig } from "./helpers.js";

function fakeAuth(): GoogleAuth {
  return { getAccessToken: async () => ({ token: "unused" }) } as unknown as GoogleAuth;
}

test("does not list or create a Reach job when YT_REACH_JOB_ID is configured", async () => {
  let lists = 0;
  let creates = 0;
  const api = {
    jobs: {
      list: async () => { lists += 1; return { data: { jobs: [] } }; },
      create: async () => { creates += 1; return { data: { id: "created" } }; },
    },
  } as unknown as GoogleApis["reporting"];
  const service = new YoutubeReportingService(testConfig.channels[0]!.youtubeChannelId, "Conon", fakeAuth(), api, "configured");
  await service.initialize();
  assert.equal(service.getResolvedJobId(), "configured");
  assert.equal(lists, 0);
  assert.equal(creates, 0);
});

test("reuses an existing channel_reach_basic_a1 job without creating a duplicate", async () => {
  let creates = 0;
  const api = {
    jobs: {
      list: async () => ({
        data: { jobs: [{ id: "existing", reportTypeId: "channel_reach_basic_a1" }] },
      }),
      create: async () => { creates += 1; return { data: { id: "created" } }; },
    },
  } as unknown as GoogleApis["reporting"];
  const service = new YoutubeReportingService(testConfig.channels[0]!.youtubeChannelId, "Conon", fakeAuth(), api);
  await service.initialize();
  assert.equal(service.getResolvedJobId(), "existing");
  assert.equal(creates, 0);
});

test("creates one Reach job only after all pages prove none exists", async () => {
  let lists = 0;
  let creates = 0;
  const api = {
    jobs: {
      list: async () => {
        lists += 1;
        return lists === 1
          ? { data: { jobs: [{ id: "other", reportTypeId: "channel_basic_a3" }], nextPageToken: "next" } }
          : { data: { jobs: [] } };
      },
      create: async () => { creates += 1; return { data: { id: "created" } }; },
    },
  } as unknown as GoogleApis["reporting"];
  const service = new YoutubeReportingService(testConfig.channels[0]!.youtubeChannelId, "Conon", fakeAuth(), api);
  await Promise.all([service.initialize(), service.initialize()]);
  assert.equal(lists, 2);
  assert.equal(creates, 1);
  assert.equal(service.getResolvedJobId(), "created");
});
