import test from "node:test";
import assert from "node:assert/strict";
import { aggregateReachRows } from "../src/google/youtube-reporting.js";

test("weights CTR by thumbnail impressions", () => {
  const value = aggregateReachRows([
    { date: "2026-09-01", thumbnailImpressions: 100, thumbnailImpressionsCtr: 0.04 },
    { date: "2026-09-02", thumbnailImpressions: 300, thumbnailImpressionsCtr: 0.08 },
  ]);
  assert.equal(value.thumbnailImpressions, 400);
  assert.equal(value.thumbnailImpressionsCtr, 0.07);
});

test("returns null CTR when there are no impressions", () => {
  assert.deepEqual(aggregateReachRows([]), {
    thumbnailImpressions: 0,
    thumbnailImpressionsCtr: null,
  });
});
