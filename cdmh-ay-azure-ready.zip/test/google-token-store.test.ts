import assert from "node:assert/strict";
import test from "node:test";
import { CosmosGoogleTokenStore, GOOGLE_TOKEN_DOCUMENT_ID } from "../src/google/cosmos-token-store.js";
import { MicrosoftTokenCipher } from "../src/microsoft/token-crypto.js";
import { MemoryRuntimeStateStore } from "./runtime-state-memory.js";

const key = new Uint8Array(32).fill(37);
const channel = "UCabcdefghijklmnopqrstuv";

test("Google consent state is encrypted and shared by Web and Collector", async () => {
  const state = new MemoryRuntimeStateStore();
  const web = new CosmosGoogleTokenStore(state, key);
  const job = new CosmosGoogleTokenStore(state, key);
  assert.equal(await job.read(channel), null);
  await web.save("google-refresh-marker", channel);
  assert.equal(await job.read(channel), "google-refresh-marker");
  assert.ok(state.documents.has(GOOGLE_TOKEN_DOCUMENT_ID));
  assert.equal(JSON.stringify([...state.documents.values()]).includes("google-refresh-marker"), false);
  await assert.rejects(job.read("UCdifferentabcdefghijklmn"), /another channel/);
  const microsoftCipher = new MicrosoftTokenCipher(key);
  const googleCiphertext = (state.documents.get(GOOGLE_TOKEN_DOCUMENT_ID)!.document as any).encrypted_refresh_token;
  assert.throws(() => microsoftCipher.decrypt(googleCiphertext));
});
