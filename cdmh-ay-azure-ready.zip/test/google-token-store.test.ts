import assert from "node:assert/strict";
import test from "node:test";
import {
  CosmosGoogleTokenStore,
  GOOGLE_TOKEN_DOCUMENT_ID,
  googleTokenDocumentId,
} from "../src/google/cosmos-token-store.js";
import { MicrosoftTokenCipher } from "../src/microsoft/token-crypto.js";
import { MemoryRuntimeStateStore } from "./runtime-state-memory.js";

const key = new Uint8Array(32).fill(37);
const channel = "UCabcdefghijklmnopqrstuv";

test("Google consent state is encrypted and shared by Web and Collector", async () => {
  const state = new MemoryRuntimeStateStore();
  const web = new CosmosGoogleTokenStore(state, key);
  const job = new CosmosGoogleTokenStore(state, key);
  assert.equal(await job.read(channel), null);
  await web.save("google-refresh-marker", channel);
  assert.equal(await job.read(channel), "google-refresh-marker");
  assert.ok(state.documents.has(googleTokenDocumentId(channel)));
  assert.equal(JSON.stringify([...state.documents.values()]).includes("google-refresh-marker"), false);
  assert.equal(await job.read("UCdifferentabcdefghijklmn"), null);
  const microsoftCipher = new MicrosoftTokenCipher(key);
  const googleCiphertext = (state.documents.get(googleTokenDocumentId(channel))!.document as any).encrypted_refresh_token;
  assert.throws(() => microsoftCipher.decrypt(googleCiphertext));
});

test("Google refresh tokens are isolated by channel ID", async () => {
  const state = new MemoryRuntimeStateStore();
  const store = new CosmosGoogleTokenStore(state, key);
  const other = "UCzyxwvutsrqponmlkjihgfe";
  await store.save("conon-marker", channel);
  await store.save("kadr-marker", other);
  assert.equal(await store.read(channel), "conon-marker");
  assert.equal(await store.read(other), "kadr-marker");
  assert.notEqual(googleTokenDocumentId(channel), googleTokenDocumentId(other));
  assert.equal(JSON.stringify([...state.documents.values()]).includes("marker"), false);
});

test("legacy single-channel token migrates only to its authorized channel", async () => {
  const state = new MemoryRuntimeStateStore();
  const cipher = new MicrosoftTokenCipher(key, "google-refresh-token");
  await state.create({
    id: GOOGLE_TOKEN_DOCUMENT_ID,
    partitionKey: "runtime",
    schema_version: 1,
    encrypted_refresh_token: cipher.encrypt("legacy-marker"),
    updated_at: new Date().toISOString(),
    authorized_channel_id: channel,
  });
  const store = new CosmosGoogleTokenStore(state, key);
  assert.equal(await store.read(channel), "legacy-marker");
  assert.ok(state.documents.has(googleTokenDocumentId(channel)));
  assert.equal(await store.read("UCzyxwvutsrqponmlkjihgfe"), null);
});
