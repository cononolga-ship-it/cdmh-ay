import assert from "node:assert/strict";
import test from "node:test";
import { ARCHIVE_FOLDER_PATH, GraphClient } from "../src/microsoft/graph-client.js";

const archiveUrl = "https://graph.microsoft.com/v1.0/me/drive/root:/0_0COD/01_0%20CDMH%20AY/YouTube";
const tokenProvider = { async getAccessToken() { return "test-token"; } };

test("reads the archive relative to the existing OneDrive folder", async () => {
  const requests: string[] = [];
  const graph = new GraphClient(tokenProvider, async (input) => {
    const url = String(input);
    requests.push(url);
    if (url === archiveUrl) {
      return Response.json({ id: "archive-id", name: "01_0 CDMH AY", folder: {} });
    }
    if (url.endsWith("/me/drive/items/archive-id:/index/latest.json:/content")) {
      return new Response("archive data");
    }
    throw new Error(`Unexpected Graph request: ${url}`);
  });

  assert.equal(ARCHIVE_FOLDER_PATH, "0_0COD/01_0 CDMH AY/YouTube");
  assert.equal(await graph.readText("index/latest.json"), "archive data");
  assert.deepEqual(requests, [archiveUrl, "https://graph.microsoft.com/v1.0/me/drive/items/archive-id:/index/latest.json:/content"]);
});

test("refuses to create archive files when the requested base folder does not exist", async () => {
  const requests: Array<{ url: string; method: string }> = [];
  const graph = new GraphClient(tokenProvider, async (input, init) => {
    requests.push({ url: String(input), method: init?.method ?? "GET" });
    return new Response(null, { status: 404 });
  });

  await assert.rejects(graph.upsertFile("index/videos.json", "{}", "application/json"), {
    code: "archive_folder_missing",
  });
  assert.deepEqual(requests, [{ url: archiveUrl, method: "GET" }]);
});

test("creates archive subfolders and writes only beneath the existing folder", async () => {
  const requests: Array<{ url: string; method: string }> = [];
  const graph = new GraphClient(tokenProvider, async (input, init) => {
    const url = String(input);
    const method = init?.method ?? "GET";
    requests.push({ url, method });
    if (url === archiveUrl) return Response.json({ id: "archive-id", name: "01_0 CDMH AY", folder: {} });
    if (url.endsWith("/me/drive/items/archive-id:/index") && method === "GET") {
      return new Response(null, { status: 404 });
    }
    if (url.endsWith("/me/drive/items/archive-id/children") && method === "POST") {
      assert.deepEqual(JSON.parse(String(init?.body)), {
        name: "index", folder: {}, "@microsoft.graph.conflictBehavior": "fail",
      });
      return Response.json({ id: "index-id", name: "index", folder: {} });
    }
    if (url.endsWith("/me/drive/items/index-id:/latest.json:/content") && method === "PUT") {
      return Response.json({ id: "file-id" });
    }
    throw new Error(`Unexpected Graph request: ${method} ${url}`);
  });

  await graph.upsertFile("index/latest.json", "{}", "application/json");
  assert.deepEqual(requests.map(({ url, method }) => `${method} ${url}`), [
    `GET ${archiveUrl}`,
    "GET https://graph.microsoft.com/v1.0/me/drive/items/archive-id:/index",
    "POST https://graph.microsoft.com/v1.0/me/drive/items/archive-id/children",
    "PUT https://graph.microsoft.com/v1.0/me/drive/items/index-id:/latest.json:/content",
  ]);
});

test("keeps two channel archives under distinct configured OneDrive roots", async () => {
  const requests: string[] = [];
  const fetcher = async (input: string | URL | Request) => {
    const url = String(input);
    requests.push(url);
    if (url.endsWith("/0_0COD/01_0%20CDMH%20AY/YouTube")) return Response.json({ id: "conon", name: "YouTube", folder: {} });
    if (url.endsWith("/0_0COD/02_0%20KADR%20AY/YouTube")) return Response.json({ id: "kadr", name: "YouTube", folder: {} });
    if (url.includes("/items/conon:/index/latest.json:/content")) return new Response("conon");
    if (url.includes("/items/kadr:/index/latest.json:/content")) return new Response("kadr");
    throw new Error(`Unexpected Graph request: ${url}`);
  };
  const conon = new GraphClient(tokenProvider, fetcher as typeof fetch, "0_0COD/01_0 CDMH AY/YouTube");
  const kadr = new GraphClient(tokenProvider, fetcher as typeof fetch, "0_0COD/02_0 KADR AY/YouTube");
  assert.equal(await conon.readText("index/latest.json"), "conon");
  assert.equal(await kadr.readText("index/latest.json"), "kadr");
  assert.ok(requests.some((url) => url.includes("01_0%20CDMH%20AY")));
  assert.ok(requests.some((url) => url.includes("02_0%20KADR%20AY")));
});

test("moves a known archive folder into an existing YouTube folder without copying files", async () => {
  const requests: string[] = [];
  const fetcher = async (input: string | URL | Request, init?: RequestInit) => {
    const url = String(input);
    const method = init?.method ?? "GET";
    requests.push(`${method} ${url}`);
    if (url.endsWith("/me/drive/root:/root")) return Response.json({ id: "root", name: "root", folder: {} });
    if (url.endsWith("/items/root:/snapshots")) return Response.json({ id: "snapshots", name: "snapshots", folder: {} });
    if (url.endsWith("/items/root:/YouTube")) return Response.json({ id: "youtube", name: "YouTube", folder: {} });
    if (url.endsWith("/items/youtube:/snapshots")) return new Response(null, { status: 404 });
    if (url.includes("/items/snapshots/children")) return Response.json({ value: [
      { id: "file", name: "snapshot.json", file: {} },
    ] });
    if (url.endsWith("/items/snapshots") && method === "PATCH") {
      assert.equal(init?.body, JSON.stringify({ parentReference: { id: "youtube" } }));
      return Response.json({ id: "snapshots", name: "snapshots", folder: {} });
    }
    throw new Error(`Unexpected Graph request: ${method} ${url}`);
  };
  const graph = new GraphClient(tokenProvider, fetcher as typeof fetch, "root");
  assert.deepEqual(await graph.moveFolderInto("snapshots", "YouTube"), { moved: true, files: 1 });
  assert.ok(requests.some((request) => request.startsWith("PATCH ")));
});
