import assert from "node:assert/strict";
import test from "node:test";
import { CosmosArchiveBackend } from "../src/archive/cosmos-backend.js";
import {
  RuntimeStateConflictError,
  type RuntimeDocument,
  type RuntimeStateStore,
  type VersionedDocument,
} from "../src/azure/runtime-state.js";

class MemoryRuntimeState implements RuntimeStateStore {
  readonly documents = new Map<string, VersionedDocument<RuntimeDocument>>();
  private version = 0;

  async read<T extends RuntimeDocument>(id: string): Promise<VersionedDocument<T> | null> {
    return (this.documents.get(id) as VersionedDocument<T> | undefined) ?? null;
  }

  async create<T extends RuntimeDocument>(document: T): Promise<VersionedDocument<T>> {
    if (this.documents.has(document.id)) throw new RuntimeStateConflictError(409);
    return this.save(document);
  }

  async replace<T extends RuntimeDocument>(document: T, etag: string): Promise<VersionedDocument<T>> {
    if (this.documents.get(document.id)?.etag !== etag) throw new RuntimeStateConflictError(412);
    return this.save(document);
  }

  private save<T extends RuntimeDocument>(document: T): VersionedDocument<T> {
    const value = { document: structuredClone(document), etag: String(++this.version) };
    this.documents.set(document.id, value);
    return value;
  }
}

test("stores compressed archive items and isolates channel manifests", async () => {
  const state = new MemoryRuntimeState();
  const conon = new CosmosArchiveBackend(state, "conon_d");
  const kadr = new CosmosArchiveBackend(state, "kadr19");
  await conon.upsertFile("index/latest.json", "{\"channel\":\"conon\"}", "application/json");
  await kadr.upsertFile("index/latest.json", "{\"channel\":\"kadr\"}", "application/json");

  assert.equal(await conon.readText("index/latest.json"), "{\"channel\":\"conon\"}");
  assert.equal(await kadr.readText("index/latest.json"), "{\"channel\":\"kadr\"}");
  assert.deepEqual((await conon.listFiles("index")).map((file) => file.path), ["index/latest.json"]);
  assert.deepEqual((await kadr.listFiles("index")).map((file) => file.path), ["index/latest.json"]);
});

test("keeps immutable archive items immutable", async () => {
  const backend = new CosmosArchiveBackend(new MemoryRuntimeState(), "conon_d");
  assert.deepEqual(
    await backend.putImmutableFile("snapshots/a.json", "first", "application/json"),
    { created: true },
  );
  await assert.rejects(
    backend.putImmutableFile("snapshots/a.json", "second", "application/json"),
    /already exists/,
  );
  assert.equal(await backend.readText("snapshots/a.json"), "first");
});

test("round-trips data larger than one Cosmos archive chunk", async () => {
  const backend = new CosmosArchiveBackend(new MemoryRuntimeState(), "conon_d");
  const content = Array.from({ length: 80_000 }, (_, index) => `${index}:${Math.random()}`).join("\n");
  await backend.upsertFile("reach-reports/large.csv", content, "text/csv");
  assert.equal(await backend.readText("reach-reports/large.csv"), content);
});
