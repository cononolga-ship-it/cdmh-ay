import type { AppConfig } from "../src/config.js";

export const testConfig: AppConfig = {
  nodeEnv: "test",
  port: 3000,
  publicBaseUrl: "https://mcp.example.test",
  mcpResourceUrl: "https://mcp.example.test/mcp",
  googleRedirectUri: "https://mcp.example.test/oauth/google/callback",
  channels: [{
    key: "conon_d",
    name: "Conon & D Media House",
    youtubeChannelId: "UCAAAAAAAAAAAAAAAAAAAAAA",
  }],
  defaultChannelKey: "conon_d",
  ownerGoogleEmail: "owner@example.test",
  googleClientId: "test-client",
  googleClientSecret: "test-secret",
  googleBootstrapRefreshToken: "test-refresh-token",
  runtimeStateEncryptionKey: new Uint8Array(32).fill(7),
  azureCosmosEndpoint: "https://cosmos.example.test",
  azureCosmosDatabaseName: "cdmh-ay",
  azureCosmosContainerName: "runtime-state",
  azureClientId: "00000000-0000-4000-8000-000000000001",
  signingSecret: new TextEncoder().encode("0123456789abcdefghijklmnopqrstuvwxyz"),
  accessTokenTtlSeconds: 900,
  refreshTokenTtlSeconds: 15_552_000,
  collectionLookbackDays: 30,
  collectorConcurrency: 4,
};
