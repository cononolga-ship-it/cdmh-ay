import {
  RuntimeStateConflictError,
  type RuntimeDocument,
  type RuntimeStateStore,
  type VersionedDocument,
} from "../src/azure/runtime-state.js";

export class MemoryRuntimeStateStore implements RuntimeStateStore {
  readonly documents = new Map<string, { document: RuntimeDocument; version: number }>();
  replaceCalls = 0;
  createBarrier?: () => Promise<void>;
  conflictReplaceCall?: number;

  async read<T extends RuntimeDocument>(id: string): Promise<VersionedDocument<T> | null> {
    const value = this.documents.get(id);
    return value ? cloneVersion(value) as VersionedDocument<T> : null;
  }

  async create<T extends RuntimeDocument>(document: T): Promise<VersionedDocument<T>> {
    await this.createBarrier?.();
    if (this.documents.has(document.id)) throw new RuntimeStateConflictError(409);
    const value = { document: structuredClone(document), version: 1 };
    this.documents.set(document.id, value);
    return cloneVersion(value) as VersionedDocument<T>;
  }

  async replace<T extends RuntimeDocument>(document: T, etag: string): Promise<VersionedDocument<T>> {
    this.replaceCalls += 1;
    const current = this.documents.get(document.id);
    if (this.replaceCalls === this.conflictReplaceCall || !current || etag !== String(current.version)) {
      throw new RuntimeStateConflictError(412);
    }
    const value = { document: structuredClone(document), version: current.version + 1 };
    this.documents.set(document.id, value);
    return cloneVersion(value) as VersionedDocument<T>;
  }
}

function cloneVersion(value: { document: RuntimeDocument; version: number }): VersionedDocument<RuntimeDocument> {
  return { document: structuredClone(value.document), etag: String(value.version) };
}
