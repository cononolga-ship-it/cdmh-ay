import assert from "node:assert/strict";
import test from "node:test";
import { ArchiveHistoryService } from "../src/archive/history-service.js";
import { SnapshotStore, type ArchiveBackend } from "../src/archive/snapshot-store.js";
import type { ArchiveSnapshot } from "../src/archive/types.js";

class MemoryBackend implements ArchiveBackend {
  readonly files = new Map<string, string | Uint8Array>();
  async readText(path: string) {
    const value = this.files.get(path);
    if (value === undefined) return null;
    return typeof value === "string" ? value : new TextDecoder().decode(value);
  }
  async putImmutableFile(path: string, content: string | Uint8Array) {
    this.files.set(path, content);
    return { created: true };
  }
  async upsertFile(path: string, content: string | Uint8Array) { this.files.set(path, content); }
  async listFiles(path: string) {
    return [...this.files.keys()].filter((item) => item.startsWith(`${path}/`))
      .map((item) => ({ path: item, id: item, name: item.split("/").at(-1)! }));
  }
}

function snapshot(channelId: string, videoId: string, views: number): ArchiveSnapshot {
  const observedAt = "2026-09-21T12:00:00.000Z";
  return {
    schema_version: 1,
    snapshot_id: `${channelId}-${videoId}`,
    observed_at: observedAt,
    channel_id: channelId,
    collection_window: { start_date: "2026-09-20", end_date: "2026-09-20" },
    records: [{
      observed_at: observedAt,
      metric_date: "2026-09-20",
      video_id: videoId,
      channel_id: channelId,
      source: "youtube_analytics",
      metrics: { views },
    }],
  };
}

test("historical services never cross channel archive boundaries", async () => {
  const cononStore = new SnapshotStore(new MemoryBackend());
  const kadrStore = new SnapshotStore(new MemoryBackend());
  await cononStore.saveSnapshot(snapshot("UCAAAAAAAAAAAAAAAAAAAAAA", "aaaaaaaaaaa", 11));
  await kadrStore.saveSnapshot(snapshot("UCQ2_fcbA4Y60tCYqULn7YRg", "bbbbbbbbbbb", 29));
  const conon = new ArchiveHistoryService(cononStore);
  const kadr = new ArchiveHistoryService(kadrStore);
  assert.deepEqual(
    (await conon.metricHistory("aaaaaaaaaaa", "views", "2026-09-20", "2026-09-20")).observations.map((row) => row.value),
    [11],
  );
  assert.deepEqual(
    (await kadr.metricHistory("bbbbbbbbbbb", "views", "2026-09-20", "2026-09-20")).observations.map((row) => row.value),
    [29],
  );
  assert.deepEqual((await conon.metricHistory("bbbbbbbbbbb", "views", "2026-09-20", "2026-09-20")).observations, []);
  assert.deepEqual((await kadr.metricHistory("aaaaaaaaaaa", "views", "2026-09-20", "2026-09-20")).observations, []);
});
