import { createCipheriv, createDecipheriv, randomBytes } from "node:crypto";
import { PublicError } from "../errors.js";

const ALGORITHM = "aes-256-gcm";

export type EncryptedTokenEnvelope = {
  version: 1;
  algorithm: "AES-256-GCM";
  iv: string;
  auth_tag: string;
  ciphertext: string;
};

export class TokenCipher {
  private readonly key: Buffer;
  private readonly aad: Buffer;

  constructor(encryptionKey: Uint8Array, context: string) {
    if (encryptionKey.byteLength !== 32) {
      throw new PublicError("runtime_state_key_invalid", "Runtime state encryption is misconfigured.", 500);
    }
    this.key = Buffer.from(encryptionKey);
    this.aad = Buffer.from(`cdmh-ay:${context}:v1`, "utf8");
  }

  encrypt(value: string): EncryptedTokenEnvelope {
    if (!value) throw stateError();
    const iv = randomBytes(12);
    const cipher = createCipheriv(ALGORITHM, this.key, iv);
    cipher.setAAD(this.aad);
    const plaintext = Buffer.from(value, "utf8");
    try {
      const ciphertext = Buffer.concat([cipher.update(plaintext), cipher.final()]);
      return {
        version: 1,
        algorithm: "AES-256-GCM",
        iv: iv.toString("base64"),
        auth_tag: cipher.getAuthTag().toString("base64"),
        ciphertext: ciphertext.toString("base64"),
      };
    } finally {
      plaintext.fill(0);
    }
  }

  decrypt(envelope: EncryptedTokenEnvelope): string {
    try {
      validateEnvelope(envelope);
      const decipher = createDecipheriv(ALGORITHM, this.key, Buffer.from(envelope.iv, "base64"));
      decipher.setAAD(this.aad);
      decipher.setAuthTag(Buffer.from(envelope.auth_tag, "base64"));
      const plaintext = Buffer.concat([
        decipher.update(Buffer.from(envelope.ciphertext, "base64")),
        decipher.final(),
      ]);
      try {
        const value = plaintext.toString("utf8");
        if (!value) throw new Error("empty state");
        return value;
      } finally {
        plaintext.fill(0);
      }
    } catch {
      throw stateError();
    }
  }
}

function validateEnvelope(value: EncryptedTokenEnvelope): void {
  if (
    value?.version !== 1 || value.algorithm !== "AES-256-GCM" ||
    Buffer.from(value.iv, "base64").byteLength !== 12 ||
    Buffer.from(value.auth_tag, "base64").byteLength !== 16 ||
    !value.ciphertext
  ) throw new Error("invalid envelope");
}

function stateError(): PublicError {
  return new PublicError("runtime_state_unavailable", "Encrypted runtime state is unavailable.", 503);
}
