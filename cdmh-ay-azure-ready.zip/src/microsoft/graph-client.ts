import { PublicError } from "../errors.js";
import type { MicrosoftTokenProvider } from "./onedrive-auth.js";

const GRAPH_ORIGIN = "https://graph.microsoft.com";
const GRAPH_BASE = `${GRAPH_ORIGIN}/v1.0`;
export const ARCHIVE_FOLDER_PATH = "0_0COD/01_0 CDMH AY/YouTube";

export type DriveItem = {
  id: string;
  name: string;
  folder?: { childCount?: number };
  file?: Record<string, unknown>;
};

export type StoredFile = {
  path: string;
  id: string;
  name: string;
};

export class GraphClient {
  private archiveRoot: Promise<DriveItem> | undefined;
  private readonly folderCache = new Map<string, DriveItem>();

  constructor(
    private readonly tokens: Pick<MicrosoftTokenProvider, "getAccessToken">,
    private readonly fetchImpl: typeof fetch = fetch,
    private readonly archiveFolderPath = ARCHIVE_FOLDER_PATH,
  ) {}

  async getArchiveRoot(): Promise<DriveItem> {
    if (!this.archiveRoot) {
      this.archiveRoot = this.requestJson<DriveItem>(
        `/me/drive/root:/${encodeGraphPath(this.archiveFolderPath)}`,
        true,
      ).then((item) => {
        if (!item?.folder) {
          throw new PublicError("archive_folder_missing", "The configured OneDrive archive folder is unavailable.", 502);
        }
        return item;
      });
    }
    return await this.archiveRoot;
  }

  async readText(path: string): Promise<string | null> {
    const root = await this.getArchiveRoot();
    const response = await this.request(
      `/me/drive/items/${encodeURIComponent(root.id)}:/${encodeGraphPath(path)}:/content`,
      { expectedNotFound: true },
    );
    if (!response) return null;
    return response.text();
  }

  async putImmutableFile(
    path: string,
    content: string | Uint8Array,
    contentType: string,
    onExisting: "error" | "skip" = "error",
  ): Promise<{ created: boolean }> {
    const { parentPath, name } = splitFilePath(path);
    const parent = await this.ensureFolderPath(parentPath);
    const existing = await this.getChild(parent.id, name);
    if (existing) {
      if (onExisting === "skip") return { created: false };
      throw new PublicError("archive_conflict", "An immutable archive file already exists.", 409);
    }
    const query = new URLSearchParams({ "@microsoft.graph.conflictBehavior": "fail" });
    const response = await this.request(
      `/me/drive/items/${encodeURIComponent(parent.id)}:/${encodeURIComponent(name)}:/content?${query}`,
      {
        method: "PUT",
        headers: { "content-type": contentType, "if-none-match": "*" },
        body: asBody(content),
        expectedConflict: onExisting === "skip",
      },
    );
    if (!response) return { created: false };
    return { created: true };
  }

  async upsertFile(path: string, content: string | Uint8Array, contentType: string): Promise<void> {
    const { parentPath, name } = splitFilePath(path);
    const parent = await this.ensureFolderPath(parentPath);
    await this.request(
      `/me/drive/items/${encodeURIComponent(parent.id)}:/${encodeURIComponent(name)}:/content`,
      { method: "PUT", headers: { "content-type": contentType }, body: asBody(content) },
    );
  }

  async listFiles(path: string): Promise<StoredFile[]> {
    const root = await this.getArchiveRoot();
    const start = path ? await this.getItemByPath(root.id, path) : root;
    if (!start) return [];
    if (!start.folder) return [{ path, id: start.id, name: start.name }];

    const files: StoredFile[] = [];
    const walk = async (folder: DriveItem, prefix: string): Promise<void> => {
      for (const child of await this.listChildren(folder.id)) {
        const childPath = prefix ? `${prefix}/${child.name}` : child.name;
        if (child.folder) await walk(child, childPath);
        else files.push({ path: childPath, id: child.id, name: child.name });
      }
    };
    await walk(start, path);
    return files;
  }

  async moveFolderInto(
    sourcePath: string,
    targetFolderPath: string,
  ): Promise<{ moved: boolean; files: number }> {
    const root = await this.getArchiveRoot();
    const source = await this.getItemByPath(root.id, sourcePath);
    if (!source) return { moved: false, files: 0 };
    if (!source.folder) {
      throw new PublicError("archive_migration_source_invalid", "An archive migration source is not a folder.", 409);
    }
    const target = await this.getItemByPath(root.id, targetFolderPath);
    if (!target?.folder) {
      throw new PublicError("archive_migration_target_missing", "The archive migration target folder is unavailable.", 409);
    }
    if (await this.getChild(target.id, source.name)) {
      throw new PublicError("archive_migration_conflict", "The archive migration target already exists.", 409);
    }
    const files = (await this.listFiles(sourcePath)).length;
    await this.request(`/me/drive/items/${encodeURIComponent(source.id)}`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ parentReference: { id: target.id } }),
    });
    return { moved: true, files };
  }

  private async ensureFolderPath(path: string): Promise<DriveItem> {
    const root = await this.getArchiveRoot();
    if (!path) return root;
    let parent = root;
    let currentPath = "";
    for (const segment of path.split("/")) {
      validateName(segment);
      currentPath = currentPath ? `${currentPath}/${segment}` : segment;
      const cached = this.folderCache.get(currentPath);
      if (cached) {
        parent = cached;
        continue;
      }
      let child = await this.getChild(parent.id, segment);
      if (child && !child.folder) {
        throw new PublicError("archive_path_conflict", "An archive path is occupied by a file.", 409);
      }
      if (!child) {
        const response = await this.request(
          `/me/drive/items/${encodeURIComponent(parent.id)}/children`,
          {
            method: "POST",
            headers: { "content-type": "application/json" },
            body: JSON.stringify({
              name: segment,
              folder: {},
              "@microsoft.graph.conflictBehavior": "fail",
            }),
            expectedConflict: true,
          },
        );
        child = response
          ? await response.json() as DriveItem
          : await this.getChild(parent.id, segment);
      }
      if (!child?.folder) {
        throw new PublicError("archive_folder_failed", "The OneDrive archive folder is unavailable.", 502);
      }
      this.folderCache.set(currentPath, child);
      parent = child;
    }
    return parent;
  }

  private async getItemByPath(rootId: string, path: string): Promise<DriveItem | null> {
    return this.requestJson<DriveItem>(
      `/me/drive/items/${encodeURIComponent(rootId)}:/${encodeGraphPath(path)}`,
      true,
    );
  }

  private async getChild(parentId: string, name: string): Promise<DriveItem | null> {
    validateName(name);
    return this.requestJson<DriveItem>(
      `/me/drive/items/${encodeURIComponent(parentId)}:/${encodeURIComponent(name)}`,
      true,
    );
  }

  private async listChildren(parentId: string): Promise<DriveItem[]> {
    const children: DriveItem[] = [];
    let url: string | undefined = `${GRAPH_BASE}/me/drive/items/${encodeURIComponent(parentId)}/children?$select=id,name,file,folder&$top=200`;
    while (url) {
      const response: { value?: DriveItem[]; "@odata.nextLink"?: string } =
        await this.requestJsonAbsolute(url);
      children.push(...(response.value ?? []));
      url = response["@odata.nextLink"];
    }
    return children;
  }

  private async requestJson<T>(path: string, expectedNotFound = false): Promise<T | null> {
    const response = await this.request(path, { expectedNotFound });
    return response ? await response.json() as T : null;
  }

  private async requestJsonAbsolute<T>(url: string): Promise<T> {
    const parsed = new URL(url);
    if (parsed.origin !== GRAPH_ORIGIN) {
      throw new PublicError("graph_invalid_url", "Microsoft Graph returned an invalid continuation URL.", 502);
    }
    const response = await this.request(url, {});
    if (!response) throw new PublicError("graph_error", "The OneDrive archive is unavailable.", 502);
    return response.json() as Promise<T>;
  }

  private async request(
    pathOrUrl: string,
    options: RequestInit & { expectedNotFound?: boolean; expectedConflict?: boolean },
  ): Promise<Response | null> {
    const url = pathOrUrl.startsWith("https://") ? pathOrUrl : `${GRAPH_BASE}${pathOrUrl}`;
    const parsed = new URL(url);
    if (parsed.origin !== GRAPH_ORIGIN) {
      throw new PublicError("graph_invalid_url", "Microsoft Graph returned an invalid URL.", 502);
    }
    const accessToken = await this.tokens.getAccessToken();
    const response = await this.fetchImpl(url, {
      ...options,
      headers: { authorization: `Bearer ${accessToken}`, ...options.headers },
      signal: options.signal ?? AbortSignal.timeout(60_000),
    });
    if (options.expectedNotFound && response.status === 404) return null;
    if (options.expectedConflict && (response.status === 409 || response.status === 412)) return null;
    if (!response.ok) {
      throw new PublicError("graph_error", "The OneDrive archive is unavailable.", 502);
    }
    return response;
  }
}

function splitFilePath(path: string): { parentPath: string; name: string } {
  const segments = path.split("/");
  const name = segments.pop();
  if (!name) throw new PublicError("invalid_archive_path", "The archive path is invalid.");
  segments.forEach(validateName);
  validateName(name);
  return { parentPath: segments.join("/"), name };
}

function validateName(value: string): void {
  if (!value || value === "." || value === ".." || /[\\:*?"<>|#%]/.test(value)) {
    throw new PublicError("invalid_archive_path", "The archive path is invalid.");
  }
}

function encodeGraphPath(path: string): string {
  return path.split("/").map((segment) => {
    validateName(segment);
    return encodeURIComponent(segment);
  }).join("/");
}

function asBody(content: string | Uint8Array): BodyInit {
  if (typeof content === "string") return content;
  const copy = new Uint8Array(new ArrayBuffer(content.byteLength));
  copy.set(content);
  return copy.buffer;
}
