import { createHash, randomBytes, timingSafeEqual } from "node:crypto";
import express from "express";
import { google } from "googleapis";
import { SignJWT, jwtVerify } from "jose";
import type { RuntimeDocument, RuntimeStateStore } from "../azure/runtime-state.js";
import { RuntimeStateConflictError, RUNTIME_PARTITION_KEY } from "../azure/runtime-state.js";
import type { AppConfig } from "../config.js";
import { PublicError } from "../errors.js";
import { ARCHIVE_FOLDER_PATH } from "./graph-client.js";
import type { CosmosMicrosoftTokenStore } from "./cosmos-token-store.js";
import { buildMicrosoftAuthorizationUrl, exchangeMicrosoftAuthorizationCode } from "./onedrive-auth.js";

const MAX_AGE_MS = 10 * 60_000;
const cookieOptions = { httpOnly: true, secure: true, sameSite: "lax" as const, path: "/oauth", maxAge: MAX_AGE_MS };
type ConsentState = RuntimeDocument & { verifier: string; expires_at: string; used: boolean; ttl: number };

function hash(value: string): string { return createHash("sha256").update(value).digest("base64url"); }
function equal(a: string | undefined, b: string): boolean {
  if (!a || a.length !== b.length) return false;
  return timingSafeEqual(Buffer.from(a), Buffer.from(b));
}
function field(value: unknown): string {
  if (typeof value !== "string" || !/^[A-Za-z0-9_-]{32,256}$/.test(value)) {
    throw new PublicError("invalid_request", "Invalid Microsoft authorization response.");
  }
  return value;
}
function cookies(header: string | undefined, name: string): string | undefined {
  return header?.split(";").map((item) => item.trim()).find((item) => item.startsWith(`${name}=`))?.slice(name.length + 1);
}

export function createMicrosoftConsentRouter(
  config: AppConfig,
  stateStore: RuntimeStateStore,
  tokenStore: CosmosMicrosoftTokenStore,
  fetchImpl: typeof fetch = fetch,
) {
  const router = express.Router();
  router.use((_req, res, next) => {
    res.set({ "Cache-Control": "no-store", "Referrer-Policy": "no-referrer", "X-Robots-Tag": "noindex" });
    next();
  });

  // Only the verified Google owner may start a consent grant.
  router.get("/oauth/microsoft/start", async (_req, res) => {
    try {
      const nonce = randomBytes(32).toString("base64url");
      const state = await new SignJWT({ nonce })
        .setProtectedHeader({ alg: "HS256" }).setAudience("microsoft-consent-owner")
        .setIssuedAt().setExpirationTime("10m").sign(config.signingSecret);
      res.cookie("ms_owner", nonce, cookieOptions);
      const auth = new google.auth.OAuth2(config.googleClientId, config.googleClientSecret, config.googleRedirectUri);
      res.redirect(302, auth.generateAuthUrl({ scope: ["openid", "email"], access_type: "online",
        prompt: "select_account", state: `ms.${state}` }));
    } catch { res.status(503).send("Microsoft authorization is temporarily unavailable."); }
  });

  router.get("/oauth/google/callback", async (req, res, next) => {
    if (typeof req.query.state !== "string" || !req.query.state.startsWith("ms.")) return next();
    try {
      const state = req.query.state.slice(3);
      if (typeof state !== "string" || state.length > 4096) throw new PublicError("invalid_state", "Invalid authorization state.");
      const verified = await jwtVerify(state, config.signingSecret, { audience: "microsoft-consent-owner" });
      if (typeof verified.payload.nonce !== "string" || !equal(cookies(req.headers.cookie, "ms_owner"), verified.payload.nonce)) {
        throw new PublicError("invalid_state", "Invalid authorization state.");
      }
      res.clearCookie("ms_owner", cookieOptions);
      const code = typeof req.query.code === "string" ? req.query.code : "";
      if (!code || code.length > 4096) throw new PublicError("invalid_request", "Authorization was not completed.");
      const auth = new google.auth.OAuth2(config.googleClientId, config.googleClientSecret, config.googleRedirectUri);
      const result = await auth.getToken(code);
      if (!result.tokens.id_token) throw new PublicError("access_denied", "Owner identity could not be verified.", 403);
      const identity = (await auth.verifyIdToken({ idToken: result.tokens.id_token, audience: config.googleClientId })).getPayload();
      if (!identity?.email_verified || identity.email?.toLowerCase() !== config.ownerGoogleEmail) {
        throw new PublicError("access_denied", "Only the project owner can authorize OneDrive.", 403);
      }

      const microsoftState = randomBytes(32).toString("base64url");
      const verifier = randomBytes(48).toString("base64url");
      const document: ConsentState = { id: `microsoft-consent-${hash(microsoftState)}`,
        partitionKey: RUNTIME_PARTITION_KEY, verifier, expires_at: new Date(Date.now() + MAX_AGE_MS).toISOString(),
        used: false, ttl: 3600 };
      await stateStore.create(document);
      res.cookie("ms_grant", hash(microsoftState), cookieOptions);
      res.redirect(302, buildMicrosoftAuthorizationUrl(config, microsoftState, hash(verifier)));
    } catch { res.status(403).send("Microsoft authorization could not be started. Retry from /oauth/microsoft/start."); }
  });

  router.get("/oauth/microsoft/callback", async (req, res) => {
    try {
      const state = field(req.query.state);
      if (!equal(cookies(req.headers.cookie, "ms_grant"), hash(state))) {
        throw new PublicError("invalid_state", "Invalid authorization state.");
      }
      res.clearCookie("ms_grant", cookieOptions);
      const id = `microsoft-consent-${hash(state)}`;
      const current = await stateStore.read<ConsentState>(id);
      if (!current || current.document.used || Date.parse(current.document.expires_at) < Date.now()) {
        throw new PublicError("invalid_state", "Authorization state expired or was already used.");
      }
      try {
        await stateStore.replace({ ...current.document, used: true }, current.etag);
      } catch (error) {
        if (error instanceof RuntimeStateConflictError) throw new PublicError("invalid_state", "Authorization state was already used.");
        throw error;
      }
      const code = req.query.code;
      if (typeof code !== "string" || !code || code.length > 8192) {
        throw new PublicError("invalid_request", "Invalid Microsoft authorization response.");
      }
      const grant = await exchangeMicrosoftAuthorizationCode(config, code, current.document.verifier);
      const folder = await fetchImpl(`https://graph.microsoft.com/v1.0/me/drive/root:/${ARCHIVE_FOLDER_PATH.split("/").map(encodeURIComponent).join("/")}`, {
        headers: { authorization: `Bearer ${grant.accessToken}` }, signal: AbortSignal.timeout(30_000),
      });
      if (!folder.ok || !(await folder.json() as { folder?: unknown }).folder) {
        throw new PublicError("archive_folder_missing", "This Microsoft account cannot access the archive folder.", 403);
      }
      await tokenStore.saveAuthorizedToken(grant.refreshToken);
      res.status(200).type("text/plain").send("OneDrive authorization saved. You can close this page.");
    } catch {
      res.status(400).type("text/plain").send("OneDrive authorization was not saved. Retry from /oauth/microsoft/start.");
    }
  });
  return router;
}
