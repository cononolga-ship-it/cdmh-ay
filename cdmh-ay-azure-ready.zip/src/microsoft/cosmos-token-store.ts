import { randomUUID } from "node:crypto";
import {
  RUNTIME_PARTITION_KEY,
  RuntimeStateConflictError,
  type RuntimeDocument,
  type RuntimeStateStore,
  type VersionedDocument,
} from "../azure/runtime-state.js";
import { PublicError } from "../errors.js";
import { MicrosoftTokenCipher, type EncryptedTokenEnvelope } from "./token-crypto.js";

export const MICROSOFT_TOKEN_DOCUMENT_ID = "microsoft-refresh-token";
const DEFAULT_LEASE_MS = 30_000;
const DEFAULT_ATTEMPTS = 40;

type Lease = { owner_id: string; expires_at: string };
export type MicrosoftTokenDocument = RuntimeDocument & {
  schema_version: 1;
  encrypted_refresh_token: EncryptedTokenEnvelope;
  updated_at: string;
  rotation_lease?: Lease;
};

export type RotationLease = {
  ownerId: string;
  refreshToken: string;
  version: VersionedDocument<MicrosoftTokenDocument>;
};

type CoordinationOptions = {
  ownerId?: string;
  now?: () => number;
  sleep?: (milliseconds: number) => Promise<void>;
  random?: () => number;
  leaseMs?: number;
  maxAttempts?: number;
};

export class CosmosMicrosoftTokenStore {
  private readonly ownerId: string;
  private readonly now: () => number;
  private readonly sleep: (milliseconds: number) => Promise<void>;
  private readonly random: () => number;
  private readonly leaseMs: number;
  private readonly maxAttempts: number;

  constructor(
    private readonly store: RuntimeStateStore,
    private readonly cipher: MicrosoftTokenCipher,
    private readonly bootstrapRefreshToken?: string,
    options: CoordinationOptions = {},
  ) {
    this.ownerId = options.ownerId ?? randomUUID();
    this.now = options.now ?? Date.now;
    this.sleep = options.sleep ?? ((ms) => new Promise((resolve) => setTimeout(resolve, ms)));
    this.random = options.random ?? Math.random;
    this.leaseMs = options.leaseMs ?? DEFAULT_LEASE_MS;
    this.maxAttempts = options.maxAttempts ?? DEFAULT_ATTEMPTS;
  }

  async acquireRotationLease(): Promise<RotationLease> {
    for (let attempt = 0; attempt < this.maxAttempts; attempt += 1) {
      const current = await this.readOrBootstrap();
      const lease = current.document.rotation_lease;
      if (lease && lease.owner_id !== this.ownerId && Date.parse(lease.expires_at) > this.now()) {
        await this.backoff(attempt);
        continue;
      }
      const next: MicrosoftTokenDocument = {
        ...current.document,
        rotation_lease: {
          owner_id: this.ownerId,
          expires_at: new Date(this.now() + this.leaseMs).toISOString(),
        },
      };
      try {
        const version = await this.store.replace(next, current.etag);
        return { ownerId: this.ownerId, refreshToken: this.cipher.decrypt(next.encrypted_refresh_token), version };
      } catch (error) {
        if (!(error instanceof RuntimeStateConflictError) || error.statusCode !== 412) throw error;
        await this.backoff(attempt);
      }
    }
    throw new PublicError("microsoft_rotation_busy", "Microsoft authorization is temporarily busy.", 503);
  }

  async commitRotation(lease: RotationLease, refreshToken: string): Promise<void> {
    this.assertOwned(lease);
    const committed: MicrosoftTokenDocument = {
      ...lease.version.document,
      encrypted_refresh_token: this.cipher.encrypt(refreshToken),
      updated_at: new Date(this.now()).toISOString(),
    };
    delete committed.rotation_lease;
    await this.store.replace(committed, lease.version.etag);
  }

  // A fresh interactive grant may initialize the document or replace an older grant.
  // Existing refresh operations are serialized through the same lease.
  async saveAuthorizedToken(refreshToken: string): Promise<void> {
    for (let attempt = 0; attempt < this.maxAttempts; attempt += 1) {
      const current = await this.store.read<MicrosoftTokenDocument>(MICROSOFT_TOKEN_DOCUMENT_ID);
      if (!current) {
        const document: MicrosoftTokenDocument = {
          id: MICROSOFT_TOKEN_DOCUMENT_ID,
          partitionKey: RUNTIME_PARTITION_KEY,
          schema_version: 1,
          encrypted_refresh_token: this.cipher.encrypt(refreshToken),
          updated_at: new Date(this.now()).toISOString(),
        };
        try {
          await this.store.create(document);
          return;
        } catch (error) {
          if (!(error instanceof RuntimeStateConflictError) || error.statusCode !== 409) throw error;
        }
      } else {
        const lease = current.document.rotation_lease;
        if (lease && Date.parse(lease.expires_at) > this.now()) {
          await this.backoff(attempt);
          continue;
        }
        const document: MicrosoftTokenDocument = {
          ...current.document,
          encrypted_refresh_token: this.cipher.encrypt(refreshToken),
          updated_at: new Date(this.now()).toISOString(),
        };
        delete document.rotation_lease;
        try {
          await this.store.replace(document, current.etag);
          return;
        } catch (error) {
          if (!(error instanceof RuntimeStateConflictError) || error.statusCode !== 412) throw error;
        }
      }
      await this.backoff(attempt);
    }
    throw new PublicError("microsoft_rotation_busy", "Microsoft authorization is temporarily busy.", 503);
  }

  async releaseRotationLease(lease: RotationLease): Promise<void> {
    this.assertOwned(lease);
    const released = { ...lease.version.document };
    delete released.rotation_lease;
    await this.store.replace(released, lease.version.etag).catch(() => undefined);
  }

  private async readOrBootstrap(): Promise<VersionedDocument<MicrosoftTokenDocument>> {
    const current = await this.store.read<MicrosoftTokenDocument>(MICROSOFT_TOKEN_DOCUMENT_ID);
    if (current) return current;
    if (!this.bootstrapRefreshToken) {
      throw new PublicError("microsoft_bootstrap_required", "Microsoft authorization requires its initial bootstrap token.", 503);
    }
    const now = new Date(this.now()).toISOString();
    const document: MicrosoftTokenDocument = {
      id: MICROSOFT_TOKEN_DOCUMENT_ID,
      partitionKey: RUNTIME_PARTITION_KEY,
      schema_version: 1,
      encrypted_refresh_token: this.cipher.encrypt(this.bootstrapRefreshToken),
      updated_at: now,
    };
    try {
      return await this.store.create(document);
    } catch (error) {
      if (!(error instanceof RuntimeStateConflictError) || error.statusCode !== 409) throw error;
      const winner = await this.store.read<MicrosoftTokenDocument>(MICROSOFT_TOKEN_DOCUMENT_ID);
      if (!winner) throw new PublicError("microsoft_token_state_unavailable", "Microsoft authorization storage is unavailable.", 503);
      return winner;
    }
  }

  private assertOwned(lease: RotationLease): void {
    if (lease.ownerId !== this.ownerId || lease.version.document.rotation_lease?.owner_id !== this.ownerId) {
      throw new PublicError("microsoft_rotation_lease_lost", "Microsoft authorization lease was lost.", 503);
    }
  }

  private backoff(attempt: number): Promise<void> {
    const cap = Math.min(1_000, 25 * 2 ** Math.min(attempt, 5));
    return this.sleep(Math.floor(cap / 2 + this.random() * cap / 2));
  }
}
