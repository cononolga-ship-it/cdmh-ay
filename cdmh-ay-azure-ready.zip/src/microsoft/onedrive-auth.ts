import type { AppConfig } from "../config.js";
import { RuntimeStateConflictError } from "../azure/runtime-state.js";
import { PublicError } from "../errors.js";
import type { CosmosMicrosoftTokenStore } from "./cosmos-token-store.js";

export const MICROSOFT_GRAPH_SCOPES = ["offline_access", "Files.ReadWrite.AppFolder"] as const;

type TokenResponse = {
  access_token?: string;
  refresh_token?: string;
  expires_in?: number;
  token_type?: string;
};

export class MicrosoftTokenProvider {
  private cached: { accessToken: string; expiresAt: number } | undefined;
  private refreshInFlight: Promise<string> | undefined;

  constructor(
    private readonly config: AppConfig,
    private readonly tokenStore: CosmosMicrosoftTokenStore,
    private readonly fetchImpl: typeof fetch = fetch,
  ) {}

  async getAccessToken(): Promise<string> {
    if (this.cached && this.cached.expiresAt - Date.now() > 60_000) {
      return this.cached.accessToken;
    }
    if (!this.refreshInFlight) {
      this.refreshInFlight = this.refresh().finally(() => {
        this.refreshInFlight = undefined;
      });
    }
    return this.refreshInFlight;
  }

  private async refresh(): Promise<string> {
    for (let attempt = 0; attempt < 3; attempt += 1) {
      const lease = await this.tokenStore.acquireRotationLease();
      try {
        const endpoint = `https://login.microsoftonline.com/${encodeURIComponent(this.config.microsoftTenantId)}/oauth2/v2.0/token`;
        const response = await this.fetchImpl(endpoint, {
          method: "POST",
          headers: { "content-type": "application/x-www-form-urlencoded" },
          body: new URLSearchParams({
            client_id: this.config.microsoftClientId,
            client_secret: this.config.microsoftClientSecret,
            refresh_token: lease.refreshToken,
            grant_type: "refresh_token",
            scope: MICROSOFT_GRAPH_SCOPES.join(" "),
          }),
          signal: AbortSignal.timeout(30_000),
        });
        if (!response.ok) throw microsoftAuthError();
        const token = await response.json() as TokenResponse;
        if (!token.access_token) throw microsoftAuthError();

        // The access token is deliberately unusable until the rotated refresh token is committed.
        await this.tokenStore.commitRotation(lease, token.refresh_token ?? lease.refreshToken);
        const expiresIn = Number.isFinite(token.expires_in) ? Number(token.expires_in) : 3600;
        this.cached = {
          accessToken: token.access_token,
          expiresAt: Date.now() + Math.max(300, expiresIn) * 1000,
        };
        return token.access_token;
      } catch (error) {
        await this.tokenStore.releaseRotationLease(lease);
        if (error instanceof RuntimeStateConflictError && error.statusCode === 412 && attempt < 2) continue;
        throw error;
      }
    }
    throw microsoftAuthError();
  }
}

function microsoftAuthError(): PublicError {
  return new PublicError("microsoft_auth_failed", "Microsoft OneDrive authorization is unavailable.", 502);
}

export async function exchangeMicrosoftAuthorizationCode(
  config: AppConfig,
  code: string,
  codeVerifier: string,
): Promise<{ accessToken: string; refreshToken: string; expiresIn: number }> {
  const endpoint = `https://login.microsoftonline.com/${encodeURIComponent(config.microsoftTenantId)}/oauth2/v2.0/token`;
  const response = await fetch(endpoint, {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      client_id: config.microsoftClientId,
      client_secret: config.microsoftClientSecret,
      code,
      code_verifier: codeVerifier,
      redirect_uri: config.microsoftRedirectUri,
      grant_type: "authorization_code",
      scope: MICROSOFT_GRAPH_SCOPES.join(" "),
    }),
    signal: AbortSignal.timeout(30_000),
  });
  if (!response.ok) {
    throw new PublicError("microsoft_auth_failed", "Microsoft OneDrive authorization failed.", 502);
  }
  const token = await response.json() as TokenResponse;
  if (!token.access_token || !token.refresh_token) {
    throw new PublicError("microsoft_offline_access_missing", "Microsoft did not grant offline access.", 502);
  }
  return {
    accessToken: token.access_token,
    refreshToken: token.refresh_token,
    expiresIn: Number.isFinite(token.expires_in) ? Number(token.expires_in) : 3600,
  };
}

export function buildMicrosoftAuthorizationUrl(
  config: AppConfig,
  state: string,
  codeChallenge: string,
): string {
  const url = new URL(
    `https://login.microsoftonline.com/${encodeURIComponent(config.microsoftTenantId)}/oauth2/v2.0/authorize`,
  );
  url.search = new URLSearchParams({
    client_id: config.microsoftClientId,
    response_type: "code",
    redirect_uri: config.microsoftRedirectUri,
    response_mode: "query",
    scope: MICROSOFT_GRAPH_SCOPES.join(" "),
    state,
    code_challenge: codeChallenge,
    code_challenge_method: "S256",
  }).toString();
  return url.toString();
}
