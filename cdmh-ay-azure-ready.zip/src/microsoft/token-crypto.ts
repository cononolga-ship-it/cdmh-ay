import { createCipheriv, createDecipheriv, randomBytes } from "node:crypto";
import { PublicError } from "../errors.js";

const ALGORITHM = "aes-256-gcm";
const AAD = Buffer.from("cdmh-ay:microsoft-refresh-token:v1", "utf8");

export type EncryptedTokenEnvelope = {
  version: 1;
  algorithm: "AES-256-GCM";
  iv: string;
  auth_tag: string;
  ciphertext: string;
};

export class MicrosoftTokenCipher {
  private readonly key: Buffer;

  constructor(encryptionKey: Uint8Array) {
    if (encryptionKey.byteLength !== 32) {
      throw new PublicError("microsoft_token_key_invalid", "Microsoft token encryption is misconfigured.", 500);
    }
    this.key = Buffer.from(encryptionKey);
  }

  encrypt(refreshToken: string): EncryptedTokenEnvelope {
    if (!refreshToken) throw tokenError();
    const iv = randomBytes(12);
    const cipher = createCipheriv(ALGORITHM, this.key, iv);
    cipher.setAAD(AAD);
    const plaintext = Buffer.from(refreshToken, "utf8");
    try {
      const ciphertext = Buffer.concat([cipher.update(plaintext), cipher.final()]);
      return {
        version: 1,
        algorithm: "AES-256-GCM",
        iv: iv.toString("base64"),
        auth_tag: cipher.getAuthTag().toString("base64"),
        ciphertext: ciphertext.toString("base64"),
      };
    } finally {
      plaintext.fill(0);
    }
  }

  decrypt(envelope: EncryptedTokenEnvelope): string {
    try {
      validateEnvelope(envelope);
      const decipher = createDecipheriv(ALGORITHM, this.key, Buffer.from(envelope.iv, "base64"));
      decipher.setAAD(AAD);
      decipher.setAuthTag(Buffer.from(envelope.auth_tag, "base64"));
      const plaintext = Buffer.concat([
        decipher.update(Buffer.from(envelope.ciphertext, "base64")),
        decipher.final(),
      ]);
      try {
        const token = plaintext.toString("utf8");
        if (!token) throw new Error("empty token");
        return token;
      } finally {
        plaintext.fill(0);
      }
    } catch {
      throw tokenError();
    }
  }
}

function validateEnvelope(value: EncryptedTokenEnvelope): void {
  if (
    value?.version !== 1 || value.algorithm !== "AES-256-GCM" ||
    Buffer.from(value.iv, "base64").byteLength !== 12 ||
    Buffer.from(value.auth_tag, "base64").byteLength !== 16 ||
    !value.ciphertext
  ) throw new Error("invalid envelope");
}

function tokenError(): PublicError {
  return new PublicError("microsoft_token_state_unavailable", "Microsoft authorization storage is unavailable.", 503);
}
