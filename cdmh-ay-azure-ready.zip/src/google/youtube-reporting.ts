import { parse } from "csv-parse/sync";
import type { ReachReportMetadata } from "../archive/types.js";
import { APP_DISPLAY_NAME } from "../app.js";
import type { AppConfig } from "../config.js";
import { PublicError } from "../errors.js";
import { log } from "../logging.js";
import { addUtcDays } from "../utils/dates.js";
import type { GoogleApis, GoogleAuth } from "./client.js";

export const REACH_REPORT_TYPE = "channel_reach_basic_a1";
const MAX_REPORT_BYTES = 50 * 1024 * 1024;

export type ReachRow = {
  date: string;
  videoId: string;
  channelId: string;
  thumbnailImpressions: number;
  thumbnailImpressionsCtr: number;
};

export type ReachReportBundle = {
  metadata: ReachReportMetadata;
  rawCsv: Uint8Array;
  rows: ReachRow[];
};

export function aggregateReachRows(
  rows: Array<Pick<ReachRow, "thumbnailImpressions" | "thumbnailImpressionsCtr"> & Partial<ReachRow>>,
) {
  const impressions = rows.reduce((sum, row) => sum + row.thumbnailImpressions, 0);
  const weightedCtr = impressions === 0
    ? null
    : rows.reduce(
        (sum, row) => sum + row.thumbnailImpressions * row.thumbnailImpressionsCtr,
        0,
      ) / impressions;
  return { thumbnailImpressions: impressions, thumbnailImpressionsCtr: weightedCtr };
}

export function parseReachCsv(
  csv: string,
  channelId: string,
  startDate: string,
  endDate: string,
): ReachRow[] {
  const records = parse(csv, {
    bom: true,
    columns: true,
    skip_empty_lines: true,
    relax_column_count: false,
  }) as Array<Record<string, string>>;

  return records.flatMap((record) => {
    if (
      record.channel_id !== channelId ||
      !record.video_id ||
      !record.date ||
      record.date < startDate ||
      record.date > endDate
    ) return [];
    const thumbnailImpressions = Number(record.video_thumbnail_impressions);
    const thumbnailImpressionsCtr = Number(record.video_thumbnail_impressions_ctr);
    if (!Number.isFinite(thumbnailImpressions) || !Number.isFinite(thumbnailImpressionsCtr)) return [];
    return [{
      date: record.date,
      videoId: record.video_id,
      channelId: record.channel_id,
      thumbnailImpressions,
      thumbnailImpressionsCtr,
    }];
  });
}

export class YoutubeReportingService {
  private reachJobId: string | undefined;
  private initialization: Promise<void> | undefined;

  constructor(
    private readonly config: AppConfig,
    private readonly auth: GoogleAuth,
    private readonly api: GoogleApis["reporting"],
  ) {
    this.reachJobId = config.ytReachJobId;
  }

  initialize(): Promise<void> {
    if (!this.initialization) this.initialization = this.resolveOrCreateReachJob().catch((error: unknown) => {
      this.initialization = undefined;
      throw error;
    });
    return this.initialization;
  }

  getResolvedJobId(): string | undefined {
    return this.reachJobId;
  }

  async getReportBundles(startDate: string, endDate: string): Promise<ReachReportBundle[]> {
    await this.initialize();
    if (!this.reachJobId) {
      throw new PublicError("reach_not_ready", "YouTube Reach reporting is not ready yet.", 503);
    }
    const reports = await this.listReports(this.reachJobId, startDate, endDate);
    const bundles: ReachReportBundle[] = [];
    for (const report of reports) {
      if (!report.downloadUrl || !report.id) continue;
      const rawCsv = await this.downloadCsv(report.downloadUrl);
      const csv = new TextDecoder("utf-8", { fatal: true }).decode(rawCsv);
      const allRows = parseReachCsv(csv, this.config.youtubeChannelId, "0000-01-01", "9999-12-31");
      const rows = allRows.filter((row) => row.date >= startDate && row.date <= endDate);
      const dates = allRows.map((row) => row.date).sort();
      bundles.push({
        rawCsv,
        rows,
        metadata: {
          report_id: report.id,
          job_id: report.jobId ?? this.reachJobId,
          create_time: report.createTime ?? null,
          start_time: report.startTime ?? null,
          end_time: report.endTime ?? null,
          covered_period: dates.length
            ? { start_date: dates[0]!, end_date: dates[dates.length - 1]! }
            : null,
        },
      });
    }
    return bundles.sort((a, b) =>
      String(a.metadata.create_time ?? "").localeCompare(String(b.metadata.create_time ?? "")),
    );
  }

  async getVideoReach(videoId: string, startDate: string, endDate: string) {
    const bundles = await this.getReportBundles(startDate, endDate);
    const rowsByDate = new Map<string, ReachRow>();
    for (const bundle of bundles) {
      for (const row of bundle.rows) {
        if (row.videoId === videoId) rowsByDate.set(row.date, row);
      }
    }
    const daily = [...rowsByDate.values()]
      .sort((a, b) => a.date.localeCompare(b.date))
      .map((row) => ({
        date: row.date,
        thumbnailImpressions: row.thumbnailImpressions,
        thumbnailImpressionsCtr: row.thumbnailImpressionsCtr,
      }));
    const aggregate = aggregateReachRows(daily);
    return {
      videoId,
      requestedPeriod: { startDate, endDate },
      coveredPeriod: daily.length
        ? { startDate: daily[0]!.date, endDate: daily[daily.length - 1]!.date }
        : null,
      ...aggregate,
      daily,
      reportsConsidered: bundles.length,
      note: "Reach reports are generated in batches and can lag behind current YouTube Analytics data.",
    };
  }

  private async resolveOrCreateReachJob(): Promise<void> {
    if (this.reachJobId) return;

    let pageToken: string | undefined;
    do {
      const response = await this.api.jobs.list({
        pageSize: 100,
        ...(pageToken ? { pageToken } : {}),
      });
      const existing = response.data.jobs?.find(
        (job) => job.reportTypeId === REACH_REPORT_TYPE && job.id,
      );
      if (existing?.id) {
        this.reachJobId = existing.id;
        log.info({ event: "reach_job_reused" });
        return;
      }
      pageToken = response.data.nextPageToken ?? undefined;
    } while (pageToken);

    const created = await this.api.jobs.create({
      requestBody: {
        reportTypeId: REACH_REPORT_TYPE,
        name: `${APP_DISPLAY_NAME} channel reach`,
      },
    });
    if (!created.data.id) {
      throw new PublicError(
        "reach_job_creation_failed",
        "YouTube Reach reporting could not be initialized.",
        502,
      );
    }
    this.reachJobId = created.data.id;
    log.info({ event: "reach_job_created" });
  }

  private async listReports(jobId: string, startDate: string, endDate: string) {
    const reports = [];
    let pageToken: string | undefined;
    do {
      const response = await this.api.jobs.reports.list({
        jobId,
        pageSize: 100,
        startTimeAtOrAfter: `${startDate}T00:00:00Z`,
        startTimeBefore: `${addUtcDays(endDate, 1)}T00:00:00Z`,
        ...(pageToken ? { pageToken } : {}),
      });
      reports.push(...(response.data.reports ?? []));
      pageToken = response.data.nextPageToken ?? undefined;
    } while (pageToken);
    return reports;
  }

  private async downloadCsv(downloadUrl: string): Promise<Uint8Array> {
    const url = new URL(downloadUrl);
    if (
      url.protocol !== "https:" ||
      !(url.hostname.endsWith(".googleapis.com") || url.hostname.endsWith(".googleusercontent.com"))
    ) {
      throw new PublicError("invalid_report_url", "YouTube returned an invalid report location.", 502);
    }

    const token = await this.auth.getAccessToken();
    if (!token.token) {
      throw new PublicError("google_auth_failed", "Google authorization is unavailable.", 502);
    }
    const response = await fetch(url, {
      headers: { authorization: `Bearer ${token.token}` },
      redirect: "error",
      signal: AbortSignal.timeout(60_000),
    });
    if (!response.ok) {
      throw new PublicError("report_download_failed", "A YouTube Reach report could not be downloaded.", 502);
    }
    const length = Number(response.headers.get("content-length") ?? 0);
    if (length > MAX_REPORT_BYTES) {
      throw new PublicError("report_too_large", "A YouTube Reach report exceeded the download limit.", 502);
    }
    const csv = new Uint8Array(await response.arrayBuffer());
    if (csv.byteLength > MAX_REPORT_BYTES) {
      throw new PublicError("report_too_large", "A YouTube Reach report exceeded the download limit.", 502);
    }
    return csv;
  }
}
