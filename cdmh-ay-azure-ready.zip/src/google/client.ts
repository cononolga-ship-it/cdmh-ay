import { google } from "googleapis";
import type { AppConfig } from "../config.js";

export function createGoogleAuth(config: AppConfig) {
  const auth = new google.auth.OAuth2(
    config.googleClientId,
    config.googleClientSecret,
    config.googleRedirectUri,
  );
  return auth;
}

export type GoogleAuth = ReturnType<typeof createGoogleAuth>;

export function createGoogleApis(auth: GoogleAuth) {
  return {
    youtube: google.youtube({ version: "v3", auth }),
    analytics: google.youtubeAnalytics({ version: "v2", auth }),
    reporting: google.youtubereporting({ version: "v1", auth }),
  };
}

export type GoogleApis = ReturnType<typeof createGoogleApis>;
