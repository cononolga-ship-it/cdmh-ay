import type { AppConfig } from "../config.js";
import { PublicError } from "../errors.js";
import type { GoogleApis } from "./client.js";

export class YoutubeDataService {
  constructor(
    private readonly config: AppConfig,
    private readonly api: GoogleApis["youtube"],
  ) {}

  async getChannel() {
    const response = await this.api.channels.list({
      part: ["snippet", "contentDetails", "statistics"],
      id: [this.config.youtubeChannelId],
    });
    const channel = response.data.items?.[0];
    if (!channel || channel.id !== this.config.youtubeChannelId) {
      throw new PublicError("channel_not_found", "The configured YouTube channel was not found.", 404);
    }
    const uploadsPlaylistId = channel.contentDetails?.relatedPlaylists?.uploads;
    if (!uploadsPlaylistId) {
      throw new PublicError("uploads_playlist_missing", "The channel uploads playlist is unavailable.", 502);
    }

    return {
      channelId: channel.id,
      title: channel.snippet?.title ?? null,
      description: channel.snippet?.description ?? null,
      customUrl: channel.snippet?.customUrl ?? null,
      publishedAt: channel.snippet?.publishedAt ?? null,
      country: channel.snippet?.country ?? null,
      lifetime: {
        views: toInteger(channel.statistics?.viewCount),
        subscribers: channel.statistics?.hiddenSubscriberCount
          ? null
          : toInteger(channel.statistics?.subscriberCount),
        videos: toInteger(channel.statistics?.videoCount),
      },
      uploadsPlaylistId,
    };
  }

  async listVideos(maxResults: number, pageToken?: string) {
    const channel = await this.getChannel();
    const response = await this.api.playlistItems.list({
      part: ["snippet", "contentDetails"],
      playlistId: channel.uploadsPlaylistId,
      maxResults,
      ...(pageToken ? { pageToken } : {}),
    });

    const videos = (response.data.items ?? []).flatMap((item) => {
      const videoId = item.contentDetails?.videoId ?? item.snippet?.resourceId?.videoId;
      if (!videoId || item.snippet?.channelId !== this.config.youtubeChannelId) return [];
      return [{
        videoId,
        channelId: this.config.youtubeChannelId,
        title: item.snippet?.title ?? null,
        publishedAt: item.contentDetails?.videoPublishedAt ?? item.snippet?.publishedAt ?? null,
        url: `https://www.youtube.com/watch?v=${videoId}`,
      }];
    });

    return {
      videos,
      nextPageToken: response.data.nextPageToken ?? null,
      prevPageToken: response.data.prevPageToken ?? null,
      pageInfo: response.data.pageInfo ?? null,
    };
  }

  async listAllVideos() {
    const videos: Awaited<ReturnType<YoutubeDataService["listVideos"]>>["videos"] = [];
    let pageToken: string | undefined;
    do {
      const page = await this.listVideos(50, pageToken);
      videos.push(...page.videos);
      pageToken = page.nextPageToken ?? undefined;
    } while (pageToken);
    return videos;
  }

  async assertOwnedVideo(videoId: string): Promise<void> {
    const response = await this.api.videos.list({ part: ["snippet"], id: [videoId] });
    const video = response.data.items?.[0];
    if (!video) throw new PublicError("video_not_found", "The requested video was not found.", 404);
    if (video.snippet?.channelId !== this.config.youtubeChannelId) {
      throw new PublicError("video_not_owned", "The requested video does not belong to this channel.", 403);
    }
  }
}

function toInteger(value: string | null | undefined): number | null {
  if (value === null || value === undefined) return null;
  const parsed = Number(value);
  return Number.isSafeInteger(parsed) ? parsed : null;
}
