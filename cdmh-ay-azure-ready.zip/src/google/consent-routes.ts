import { createHash, randomBytes, timingSafeEqual } from "node:crypto";
import express from "express";
import { google } from "googleapis";
import type { RuntimeDocument, RuntimeStateStore } from "../azure/runtime-state.js";
import { RuntimeStateConflictError, RUNTIME_PARTITION_KEY } from "../azure/runtime-state.js";
import type { AppConfig, ChannelConfig } from "../config.js";
import { log } from "../logging.js";
import type { AppRuntime } from "../runtime.js";
import type { CosmosGoogleTokenStore } from "./cosmos-token-store.js";

// Brand Account selection can require an additional Google sign-in step.
const MAX_AGE_MS = 30 * 60_000;
const cookieOptions = { httpOnly: true, secure: true, sameSite: "lax" as const, path: "/oauth", maxAge: MAX_AGE_MS };
type ConsentState = RuntimeDocument & {
  verifier: string;
  expires_at: string;
  used: boolean;
  ttl: number;
  stage: "identity" | "youtube";
  channel_key: string;
  owner_sub?: string;
};

function hash(value: string): string { return createHash("sha256").update(value).digest("base64url"); }
function equal(a: string | undefined, b: string): boolean {
  return !!a && a.length === b.length && timingSafeEqual(Buffer.from(a), Buffer.from(b));
}
function cookie(header: string | undefined): string | undefined {
  return header?.split(";").map((item) => item.trim()).find((item) => item.startsWith("gc_grant="))?.slice(9);
}

export function createGoogleCollectorConsentRouter(
  config: AppConfig,
  stateStore: RuntimeStateStore,
  tokenStore: CosmosGoogleTokenStore,
  runtime: Pick<AppRuntime, "getChannel">,
) {
  const router = express.Router();
  router.use((_req, res, next) => {
    res.set({ "Cache-Control": "no-store", "Referrer-Policy": "no-referrer", "X-Robots-Tag": "noindex" });
    next();
  });

  function configuredChannel(key: string): ChannelConfig {
    const channel = config.channels.find((item) => item.key === key);
    if (!channel) throw new Error("unknown channel");
    return channel;
  }

  async function beginGrant(
    res: express.Response,
    channel: ChannelConfig,
    stage: ConsentState["stage"],
    ownerSub?: string,
  ) {
    const state = randomBytes(32).toString("base64url");
    const verifier = randomBytes(48).toString("base64url");
    const document: ConsentState = {
      id: `google-consent-${hash(state)}`,
      partitionKey: RUNTIME_PARTITION_KEY,
      verifier,
      expires_at: new Date(Date.now() + MAX_AGE_MS).toISOString(),
      used: false,
      ttl: 3600,
      stage,
      channel_key: channel.key,
      ...(ownerSub ? { owner_sub: ownerSub } : {}),
    };
    await stateStore.create(document);
    res.cookie("gc_grant", hash(state), cookieOptions);
    const auth = new google.auth.OAuth2(config.googleClientId, config.googleClientSecret, config.googleRedirectUri);
    const ownerGoogleEmail = channel.ownerGoogleEmail ?? config.ownerGoogleEmail;
    const url = new URL(auth.generateAuthUrl(stage === "identity" ? {
      scope: ["openid", "email"], prompt: "select_account", login_hint: ownerGoogleEmail, state: `gi.${state}`,
    } : {
      scope: [
        "https://www.googleapis.com/auth/youtube.readonly",
        "https://www.googleapis.com/auth/yt-analytics.readonly",
      ],
      access_type: "offline",
      prompt: "consent",
      login_hint: ownerGoogleEmail,
      state: `gc.${state}`,
    }));
    url.searchParams.set("code_challenge", hash(verifier));
    url.searchParams.set("code_challenge_method", "S256");
    res.redirect(302, url.toString());
  }

  async function start(key: string, res: express.Response) {
    try {
      await beginGrant(res, configuredChannel(key), "identity");
    } catch {
      res.status(503).type("text/plain").send("Google collector authorization is temporarily unavailable.");
    }
  }

  router.get("/oauth/google/collector/start", async (_req, res) => start(config.defaultChannelKey, res));
  router.get("/oauth/google/collector/:channel/start", async (req, res) => start(req.params.channel, res));

  router.get("/oauth/google/callback", async (req, res, next) => {
    if (typeof req.query.state !== "string" || !/^(gi|gc)\./.test(req.query.state)) return next();
    // Fixed step names are safe to show to the user; never include Google's
    // error response, authorization code, state, or tokens in this response.
    let phase = "state_cookie";
    let channelKey = "unknown";
    try {
      const state = req.query.state.slice(3);
      const stage = req.query.state.startsWith("gi.") ? "identity" : "youtube";
      if (!/^[A-Za-z0-9_-]{32,256}$/.test(state) || !equal(cookie(req.headers.cookie), hash(state))) {
        throw new Error("invalid state");
      }
      res.clearCookie("gc_grant", cookieOptions);
      phase = "state_read";
      const current = await stateStore.read<ConsentState>(`google-consent-${hash(state)}`);
      phase = "state_validate";
      if (!current || current.document.stage !== stage || current.document.used ||
          Date.parse(current.document.expires_at) < Date.now() ||
          (stage === "youtube" && !current.document.owner_sub)) {
        throw new Error("expired state");
      }
      channelKey = current.document.channel_key;
      const channel = configuredChannel(channelKey);
      phase = "state_claim";
      try {
        await stateStore.replace({ ...current.document, used: true }, current.etag);
      } catch (error) {
        if (error instanceof RuntimeStateConflictError) throw new Error("used state");
        throw error;
      }
      const code = req.query.code;
      if (typeof code !== "string" || !code || code.length > 8192) throw new Error("invalid code");
      phase = "exchange";
      const auth = new google.auth.OAuth2(config.googleClientId, config.googleClientSecret, config.googleRedirectUri);
      const grant = (await auth.getToken({ code, codeVerifier: current.document.verifier })).tokens;
      if (stage === "identity") {
        if (!grant.id_token) throw new Error("missing identity");
        const identity = (await auth.verifyIdToken({ idToken: grant.id_token, audience: config.googleClientId })).getPayload();
        phase = "identity";
        if (!identity?.email_verified || identity.email?.toLowerCase() !== (channel.ownerGoogleEmail ?? config.ownerGoogleEmail) || !identity.sub) {
          throw new Error("wrong owner");
        }
        phase = "identity_redirect";
        await beginGrant(res, channel, "youtube", identity.sub);
        return;
      }
      phase = "grant";
      if (!grant.refresh_token || !grant.access_token) throw new Error("incomplete grant");
      auth.setCredentials(grant);
      phase = "channel";
      const youtube = google.youtube({ version: "v3", auth });
      const channels = await youtube.channels.list({ part: ["snippet"], mine: true });
      phase = "channel_match";
      if (!channels.data.items?.some((item) => item.id === channel.youtubeChannelId)) throw new Error("wrong channel");
      const analytics = google.youtubeAnalytics({ version: "v2", auth });
      const day = new Date(Date.now() - 3 * 86_400_000).toISOString().slice(0, 10);
      phase = "analytics";
      await analytics.reports.query({ ids: "channel==MINE", startDate: day, endDate: day, metrics: "views" });
      phase = "reporting";
      await google.youtubereporting({ version: "v1", auth }).jobs.list({});
      phase = "save";
      await tokenStore.save(grant.refresh_token, channel.youtubeChannelId);
      runtime.getChannel(channel.key).googleAuth.setCredentials({ refresh_token: grant.refresh_token });
      res.status(200).type("text/plain").send(`YouTube collector authorization saved for ${channel.name}. You can close this page.`);
    } catch {
      log.error({ event: "google_collector_consent_failed", channel: channelKey, code: phase });
      res.status(400).type("text/plain").send(`YouTube collector authorization was not saved (step: ${phase}). Retry from the channel-specific start URL.`);
    }
  });
  return router;
}
