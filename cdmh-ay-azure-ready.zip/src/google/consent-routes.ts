import { createHash, randomBytes, timingSafeEqual } from "node:crypto";
import express from "express";
import { google } from "googleapis";
import type { RuntimeDocument, RuntimeStateStore } from "../azure/runtime-state.js";
import { RuntimeStateConflictError, RUNTIME_PARTITION_KEY } from "../azure/runtime-state.js";
import type { AppConfig } from "../config.js";
import { log } from "../logging.js";
import type { CosmosGoogleTokenStore } from "./cosmos-token-store.js";
import type { GoogleAuth } from "./client.js";

const OWNER_EMAIL = "kadrgruppa@gmail.com";
const MAX_AGE_MS = 10 * 60_000;
const cookieOptions = { httpOnly: true, secure: true, sameSite: "lax" as const, path: "/oauth", maxAge: MAX_AGE_MS };
type ConsentState = RuntimeDocument & { verifier: string; expires_at: string; used: boolean; ttl: number };

function hash(value: string): string { return createHash("sha256").update(value).digest("base64url"); }
function equal(a: string | undefined, b: string): boolean {
  return !!a && a.length === b.length && timingSafeEqual(Buffer.from(a), Buffer.from(b));
}
function cookie(header: string | undefined): string | undefined {
  return header?.split(";").map((item) => item.trim()).find((item) => item.startsWith("gc_grant="))?.slice(9);
}

export function createGoogleCollectorConsentRouter(
  config: AppConfig,
  stateStore: RuntimeStateStore,
  tokenStore: CosmosGoogleTokenStore,
  runtimeAuth: GoogleAuth,
) {
  const router = express.Router();
  router.use((_req, res, next) => {
    res.set({ "Cache-Control": "no-store", "Referrer-Policy": "no-referrer", "X-Robots-Tag": "noindex" });
    next();
  });

  router.get("/oauth/google/collector/start", async (_req, res) => {
    try {
      const state = randomBytes(32).toString("base64url");
      const verifier = randomBytes(48).toString("base64url");
      const document: ConsentState = {
        id: `google-consent-${hash(state)}`, partitionKey: RUNTIME_PARTITION_KEY,
        verifier, expires_at: new Date(Date.now() + MAX_AGE_MS).toISOString(), used: false, ttl: 3600,
      };
      await stateStore.create(document);
      res.cookie("gc_grant", hash(state), cookieOptions);
      const auth = new google.auth.OAuth2(config.googleClientId, config.googleClientSecret, config.googleRedirectUri);
      const url = new URL(auth.generateAuthUrl({
        scope: ["openid", "email", "https://www.googleapis.com/auth/youtube.readonly",
          "https://www.googleapis.com/auth/yt-analytics.readonly"],
        access_type: "offline", prompt: "consent select_account", state: `gc.${state}`,
      }));
      url.searchParams.set("code_challenge", hash(verifier));
      url.searchParams.set("code_challenge_method", "S256");
      res.redirect(302, url.toString());
    } catch {
      res.status(503).type("text/plain").send("Google collector authorization is temporarily unavailable.");
    }
  });

  router.get("/oauth/google/callback", async (req, res, next) => {
    if (typeof req.query.state !== "string" || !req.query.state.startsWith("gc.")) return next();
    let phase = "state";
    try {
      const state = req.query.state.slice(3);
      if (!/^[A-Za-z0-9_-]{32,256}$/.test(state) || !equal(cookie(req.headers.cookie), hash(state))) {
        throw new Error("invalid state");
      }
      res.clearCookie("gc_grant", cookieOptions);
      const current = await stateStore.read<ConsentState>(`google-consent-${hash(state)}`);
      if (!current || current.document.used || Date.parse(current.document.expires_at) < Date.now()) {
        throw new Error("expired state");
      }
      try {
        await stateStore.replace({ ...current.document, used: true }, current.etag);
      } catch (error) {
        if (error instanceof RuntimeStateConflictError) throw new Error("used state");
        throw error;
      }
      const code = req.query.code;
      if (typeof code !== "string" || !code || code.length > 8192) throw new Error("invalid code");
      phase = "exchange";
      const auth = new google.auth.OAuth2(config.googleClientId, config.googleClientSecret, config.googleRedirectUri);
      const grant = (await auth.getToken({ code, codeVerifier: current.document.verifier })).tokens;
      if (!grant.id_token || !grant.refresh_token || !grant.access_token) throw new Error("incomplete grant");
      const identity = (await auth.verifyIdToken({ idToken: grant.id_token, audience: config.googleClientId })).getPayload();
      phase = "identity";
      if (!identity?.email_verified || identity.email?.toLowerCase() !== OWNER_EMAIL) throw new Error("wrong owner");
      auth.setCredentials(grant);
      phase = "channel";
      const youtube = google.youtube({ version: "v3", auth });
      const channels = await youtube.channels.list({ part: ["snippet"], mine: true });
      if (!channels.data.items?.some((channel) => channel.id === config.youtubeChannelId)) throw new Error("wrong channel");
      const analytics = google.youtubeAnalytics({ version: "v2", auth });
      const day = new Date(Date.now() - 3 * 86_400_000).toISOString().slice(0, 10);
      phase = "analytics";
      await analytics.reports.query({ ids: "channel==MINE", startDate: day, endDate: day, metrics: "views" });
      phase = "reporting";
      await google.youtubereporting({ version: "v1", auth }).jobs.list({});
      phase = "save";
      await tokenStore.save(grant.refresh_token, config.youtubeChannelId);
      runtimeAuth.setCredentials({ refresh_token: grant.refresh_token });
      res.status(200).type("text/plain").send("YouTube collector authorization saved. You can close this page.");
    } catch {
      log.error({ event: "google_collector_consent_failed", code: phase });
      res.status(400).type("text/plain").send("YouTube collector authorization was not saved. Retry from /oauth/google/collector/start.");
    }
  });
  return router;
}
