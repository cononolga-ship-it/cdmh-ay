import type { GoogleApis } from "./client.js";
import { rowsToObjects } from "../utils/tables.js";

const VIDEO_METRICS = [
  "views",
  "averageViewDuration",
  "averageViewPercentage",
  "estimatedMinutesWatched",
  "likes",
  "comments",
  "shares",
  "subscribersGained",
  "subscribersLost",
].join(",");

export class YoutubeAnalyticsService {
  constructor(private readonly api: GoogleApis["analytics"]) {}

  async channelMetrics(startDate: string, endDate: string) {
    return this.query({ startDate, endDate, metrics: VIDEO_METRICS });
  }

  async videoMetrics(videoId: string, startDate: string, endDate: string) {
    return this.query({
      startDate,
      endDate,
      metrics: VIDEO_METRICS,
      filters: `video==${videoId}`,
    });
  }

  async videoDailyMetrics(videoId: string, startDate: string, endDate: string) {
    return this.query({
      startDate,
      endDate,
      metrics: VIDEO_METRICS,
      dimensions: "day",
      filters: `video==${videoId}`,
      sort: "day",
    });
  }

  async trafficSources(videoId: string, startDate: string, endDate: string) {
    return this.query({
      startDate,
      endDate,
      metrics: "views,estimatedMinutesWatched",
      dimensions: "insightTrafficSourceType",
      filters: `video==${videoId}`,
      sort: "-views",
    });
  }

  private async query(params: {
    startDate: string;
    endDate: string;
    metrics: string;
    dimensions?: string;
    filters?: string;
    sort?: string;
  }) {
    const response = await this.api.reports.query({
      ids: "channel==MINE",
      startDate: params.startDate,
      endDate: params.endDate,
      metrics: params.metrics,
      ...(params.dimensions ? { dimensions: params.dimensions } : {}),
      ...(params.filters ? { filters: params.filters } : {}),
      ...(params.sort ? { sort: params.sort } : {}),
    });

    return {
      startDate: params.startDate,
      endDate: params.endDate,
      rows: rowsToObjects(response.data),
    };
  }
}
