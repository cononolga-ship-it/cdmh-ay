import { RUNTIME_PARTITION_KEY, RuntimeStateConflictError, type RuntimeDocument, type RuntimeStateStore } from "../azure/runtime-state.js";
import { PublicError } from "../errors.js";
import { MicrosoftTokenCipher, type EncryptedTokenEnvelope } from "../microsoft/token-crypto.js";

export const GOOGLE_TOKEN_DOCUMENT_ID = "google-collector-refresh-token";
export function googleTokenDocumentId(channelId: string): string {
  return `${GOOGLE_TOKEN_DOCUMENT_ID}:${channelId}`;
}

type GoogleTokenDocument = RuntimeDocument & {
  schema_version: 1;
  encrypted_refresh_token: EncryptedTokenEnvelope;
  updated_at: string;
  authorized_channel_id: string;
};

export class CosmosGoogleTokenStore {
  private readonly cipher: MicrosoftTokenCipher;

  constructor(private readonly state: RuntimeStateStore, encryptionKey: Uint8Array) {
    this.cipher = new MicrosoftTokenCipher(encryptionKey, "google-refresh-token");
  }

  async read(channelId: string): Promise<string | null> {
    const scopedId = googleTokenDocumentId(channelId);
    let current = await this.state.read<GoogleTokenDocument>(scopedId);
    if (!current) {
      const legacy = await this.state.read<GoogleTokenDocument>(GOOGLE_TOKEN_DOCUMENT_ID);
      if (!legacy) return null;
      if (legacy.document.authorized_channel_id !== channelId) return null;
      const refreshToken = this.cipher.decrypt(legacy.document.encrypted_refresh_token);
      await this.save(refreshToken, channelId);
      current = await this.state.read<GoogleTokenDocument>(scopedId);
      if (!current) throw new PublicError("google_token_state_unavailable", "Google authorization storage is unavailable.", 503);
    }
    if (current.document.authorized_channel_id !== channelId) {
      throw new PublicError("google_channel_mismatch", "Google authorization is for another channel.", 503);
    }
    return this.cipher.decrypt(current.document.encrypted_refresh_token);
  }

  async save(refreshToken: string, channelId: string): Promise<void> {
    const id = googleTokenDocumentId(channelId);
    for (let attempt = 0; attempt < 5; attempt += 1) {
      const current = await this.state.read<GoogleTokenDocument>(id);
      const document: GoogleTokenDocument = {
        id,
        partitionKey: RUNTIME_PARTITION_KEY,
        schema_version: 1,
        encrypted_refresh_token: this.cipher.encrypt(refreshToken),
        updated_at: new Date().toISOString(),
        authorized_channel_id: channelId,
      };
      try {
        if (current) await this.state.replace(document, current.etag);
        else await this.state.create(document);
        return;
      } catch (error) {
        if (!(error instanceof RuntimeStateConflictError)) throw error;
      }
    }
    throw new PublicError("google_token_conflict", "Google authorization state is busy.", 503);
  }
}
