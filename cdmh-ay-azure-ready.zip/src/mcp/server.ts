import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { z } from "zod";
import { APP_DISPLAY_NAME, APP_PACKAGE_NAME, APP_VERSION } from "../app.js";
import type { ArchiveHistoryService } from "../archive/history-service.js";
import type { AppConfig } from "../config.js";
import { PublicError, toSafeError } from "../errors.js";
import type { YoutubeAnalyticsService } from "../google/youtube-analytics.js";
import type { YoutubeDataService } from "../google/youtube-data.js";
import type { YoutubeReportingService } from "../google/youtube-reporting.js";
import { lastCompleteYoutubeDays, validateDateRange } from "../utils/dates.js";

type Services = {
  data: YoutubeDataService;
  analytics: YoutubeAnalyticsService;
  reporting: YoutubeReportingService;
  history: ArchiveHistoryService;
};

const readOnlyTool = {
  securitySchemes: [{ type: "oauth2" as const, scopes: ["youtube.analytics.read"] }],
  annotations: {
    readOnlyHint: true,
    destructiveHint: false,
    idempotentHint: true,
    openWorldHint: false,
  },
};

const dateInput = {
  video_id: z.string().regex(/^[A-Za-z0-9_-]{11}$/).describe("YouTube video ID from list_videos"),
  start_date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).describe("Inclusive date in YYYY-MM-DD format"),
  end_date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).describe("Inclusive date in YYYY-MM-DD format"),
};

function requireOwner(config: AppConfig, extra: { authInfo?: { extra?: Record<string, unknown> } }): void {
  if (extra.authInfo?.extra?.email !== config.ownerGoogleEmail) {
    throw new PublicError("access_denied", "This MCP server is restricted to its owner.", 403);
  }
}

function result(data: Record<string, unknown>, summary: string) {
  return {
    structuredContent: data,
    content: [{ type: "text" as const, text: summary }],
  };
}

async function safely<T extends Record<string, unknown>>(
  operation: () => Promise<T>,
  summary: (value: T) => string,
) {
  try {
    const value = await operation();
    return result(value, summary(value));
  } catch (error) {
    const safe = toSafeError(error);
    return {
      isError: true,
      structuredContent: { error: { code: safe.code, message: safe.publicMessage } },
      content: [{ type: "text" as const, text: safe.publicMessage }],
    };
  }
}

export function createMcpServer(config: AppConfig, services: Services): McpServer {
  const server = new McpServer(
    { name: APP_PACKAGE_NAME, version: APP_VERSION },
    {
      instructions:
        `${APP_DISPLAY_NAME} provides read-only YouTube analytics and immutable metric history. ` +
        "Use list_videos to resolve video IDs. Never imply that tools can edit YouTube or OneDrive. " +
        "Reach data is batch-generated and may lag.",
    },
  );

  server.registerTool(
    "channel_overview",
    {
      ...readOnlyTool,
      title: "Channel overview",
      description: "Get channel identity, lifetime public counts, and analytics for the last 28 complete YouTube days.",
      inputSchema: {},
    },
    async (_input, extra) => safely(async () => {
      requireOwner(config, extra);
      const period = lastCompleteYoutubeDays(28);
      const [channel, analytics] = await Promise.all([
        services.data.getChannel(),
        services.analytics.channelMetrics(period.startDate, period.endDate),
      ]);
      return { channel, period, analytics };
    }, (value) => `Loaded the channel overview for ${value.period.startDate} through ${value.period.endDate}.`),
  );

  server.registerTool(
    "list_videos",
    {
      ...readOnlyTool,
      title: "List channel videos",
      description: "List videos uploaded by this channel with stable IDs, titles, publication dates, and pagination.",
      inputSchema: {
        max_results: z.number().int().min(1).max(50).default(25),
        page_token: z.string().min(1).max(512).optional(),
      },
    },
    async ({ max_results, page_token }, extra) => safely(async () => {
      requireOwner(config, extra);
      return services.data.listVideos(max_results, page_token);
    }, (value) => `Loaded ${value.videos.length} channel videos.`),
  );

  server.registerTool(
    "video_metrics",
    {
      ...readOnlyTool,
      title: "Video metrics",
      description: "Get aggregate watch, engagement, and subscriber metrics for one owned video and date range.",
      inputSchema: dateInput,
    },
    async ({ video_id, start_date, end_date }, extra) => safely(async () => {
      requireOwner(config, extra);
      const range = validateDateRange(start_date, end_date);
      await services.data.assertOwnedVideo(video_id);
      const metrics = await services.analytics.videoMetrics(video_id, range.startDate, range.endDate);
      return { videoId: video_id, ...metrics };
    }, () => "Loaded aggregate metrics for the requested video."),
  );

  server.registerTool(
    "video_daily_metrics",
    {
      ...readOnlyTool,
      title: "Daily video metrics",
      description: "Get daily watch, engagement, and subscriber metrics for one owned video and date range.",
      inputSchema: dateInput,
    },
    async ({ video_id, start_date, end_date }, extra) => safely(async () => {
      requireOwner(config, extra);
      const range = validateDateRange(start_date, end_date);
      await services.data.assertOwnedVideo(video_id);
      const metrics = await services.analytics.videoDailyMetrics(video_id, range.startDate, range.endDate);
      return { videoId: video_id, ...metrics };
    }, (value) => `Loaded ${value.rows.length} daily metric rows.`),
  );

  server.registerTool(
    "traffic_sources",
    {
      ...readOnlyTool,
      title: "Video traffic sources",
      description: "Get views and watch time grouped by traffic-source type for one owned video and date range.",
      inputSchema: dateInput,
    },
    async ({ video_id, start_date, end_date }, extra) => safely(async () => {
      requireOwner(config, extra);
      const range = validateDateRange(start_date, end_date);
      await services.data.assertOwnedVideo(video_id);
      const metrics = await services.analytics.trafficSources(video_id, range.startDate, range.endDate);
      return { videoId: video_id, ...metrics };
    }, (value) => `Loaded ${value.rows.length} traffic-source rows.`),
  );

  server.registerTool(
    "video_reach",
    {
      ...readOnlyTool,
      title: "Video reach",
      description: "Get thumbnail impressions, weighted thumbnail CTR, daily rows, and available report coverage for one owned video.",
      inputSchema: dateInput,
    },
    async ({ video_id, start_date, end_date }, extra) => safely(async () => {
      requireOwner(config, extra);
      const range = validateDateRange(start_date, end_date);
      await services.data.assertOwnedVideo(video_id);
      return services.reporting.getVideoReach(video_id, range.startDate, range.endDate);
    }, (value) => `Loaded ${value.daily.length} daily Reach rows.`),
  );

  server.registerTool(
    "metric_history",
    {
      ...readOnlyTool,
      title: "Metric observation history",
      description: "Read archived observations of one metric, preserving both metric_date and observed_at.",
      inputSchema: {
        ...dateInput,
        metric: z.string().regex(/^[A-Za-z][A-Za-z0-9_]*$/).max(128),
      },
    },
    async ({ video_id, metric, start_date, end_date }, extra) => safely(async () => {
      requireOwner(config, extra);
      const range = validateDateRange(start_date, end_date);
      await services.data.assertOwnedVideo(video_id);
      return services.history.metricHistory(video_id, metric, range.startDate, range.endDate);
    }, (value) => `Loaded ${value.observations.length} archived observations.`),
  );

  server.registerTool(
    "metric_revisions",
    {
      ...readOnlyTool,
      title: "Metric revisions",
      description: "Find metric dates whose archived values changed across collection times.",
      inputSchema: dateInput,
    },
    async ({ video_id, start_date, end_date }, extra) => safely(async () => {
      requireOwner(config, extra);
      const range = validateDateRange(start_date, end_date);
      await services.data.assertOwnedVideo(video_id);
      return services.history.metricRevisions(video_id, range.startDate, range.endDate);
    }, (value) => `Found ${value.revisions.length} revised date/source groups.`),
  );

  server.registerTool(
    "snapshot_diff",
    {
      ...readOnlyTool,
      title: "Snapshot diff",
      description: "Compare archived metrics for one owned video at two exact observed_at timestamps.",
      inputSchema: {
        video_id: dateInput.video_id,
        observed_at_a: z.string().datetime({ offset: true }),
        observed_at_b: z.string().datetime({ offset: true }),
      },
    },
    async ({ video_id, observed_at_a, observed_at_b }, extra) => safely(async () => {
      requireOwner(config, extra);
      await services.data.assertOwnedVideo(video_id);
      return services.history.snapshotDiff(video_id, observed_at_a, observed_at_b);
    }, (value) => `Found ${value.changes.length} differences between the snapshots.`),
  );

  return server;
}
