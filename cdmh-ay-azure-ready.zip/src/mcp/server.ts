import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { z } from "zod";
import { APP_DISPLAY_NAME, APP_PACKAGE_NAME, APP_VERSION } from "../app.js";
import type { AppConfig } from "../config.js";
import { PublicError, toSafeError } from "../errors.js";
import type { AppRuntime, ChannelRuntime } from "../runtime.js";
import { lastCompleteYoutubeDays, validateDateRange } from "../utils/dates.js";

const readOnlyTool = {
  securitySchemes: [{ type: "oauth2" as const, scopes: ["youtube.analytics.read"] }],
  annotations: {
    readOnlyHint: true,
    destructiveHint: false,
    idempotentHint: true,
    openWorldHint: false,
  },
};

const channelInput = z.string().min(1).max(32).optional().describe(
  "Configured channel key. Omit for the default Conon & D channel; use kadr19 for KADR19.",
);

const dateInput = {
  channel: channelInput,
  video_id: z.string().regex(/^[A-Za-z0-9_-]{11}$/).describe("YouTube video ID from list_videos"),
  start_date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).describe("Inclusive date in YYYY-MM-DD format"),
  end_date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).describe("Inclusive date in YYYY-MM-DD format"),
};

function requireOwner(config: AppConfig, extra: { authInfo?: { extra?: Record<string, unknown> } }): void {
  if (extra.authInfo?.extra?.email !== config.ownerGoogleEmail) {
    throw new PublicError("access_denied", "This MCP server is restricted to its owner.", 403);
  }
}

function result(data: Record<string, unknown>, summary: string) {
  return {
    structuredContent: data,
    content: [{ type: "text" as const, text: summary }],
  };
}

async function safely<T extends Record<string, unknown>>(
  operation: () => Promise<T>,
  summary: (value: T) => string,
) {
  try {
    const value = await operation();
    return result(value, summary(value));
  } catch (error) {
    const safe = toSafeError(error);
    return {
      isError: true,
      structuredContent: { error: { code: safe.code, message: safe.publicMessage } },
      content: [{ type: "text" as const, text: safe.publicMessage }],
    };
  }
}

export function createMcpServer(config: AppConfig, services: Pick<AppRuntime, "getChannel">): McpServer {
  const selected = (key?: string): ChannelRuntime => services.getChannel(key ?? config.defaultChannelKey);
  const authorized = async (key?: string): Promise<ChannelRuntime> => {
    const channel = selected(key);
    await channel.data.assertAuthorizedChannel();
    return channel;
  };
  const server = new McpServer(
    { name: APP_PACKAGE_NAME, version: APP_VERSION },
    {
      instructions:
        `${APP_DISPLAY_NAME} provides read-only YouTube analytics and immutable metric history. ` +
        "Every tool accepts a channel key; omit it for Conon & D or use kadr19 for KADR19. " +
        "Use list_videos to resolve video IDs. Never imply that tools can edit YouTube. " +
        "Reach data is batch-generated and may lag.",
    },
  );

  server.registerTool(
    "channel_overview",
    {
      ...readOnlyTool,
      title: "Channel overview",
      description: "Get channel identity, lifetime public counts, and analytics for the last 28 complete YouTube days.",
      inputSchema: { channel: channelInput },
    },
    async ({ channel: channelKey }, extra) => safely(async () => {
      requireOwner(config, extra);
      const services = await authorized(channelKey);
      const period = lastCompleteYoutubeDays(28);
      const [channel, analytics] = await Promise.all([
        services.data.getChannel(),
        services.analytics.channelMetrics(period.startDate, period.endDate),
      ]);
      return { channelKey: services.channel.key, channel, period, analytics };
    }, (value) => `Loaded the channel overview for ${value.period.startDate} through ${value.period.endDate}.`),
  );

  server.registerTool(
    "list_videos",
    {
      ...readOnlyTool,
      title: "List channel videos",
      description: "List videos uploaded by this channel with stable IDs, titles, publication dates, and pagination.",
      inputSchema: {
        channel: channelInput,
        max_results: z.number().int().min(1).max(50).default(25),
        page_token: z.string().min(1).max(512).optional(),
      },
    },
    async ({ channel: channelKey, max_results, page_token }, extra) => safely(async () => {
      requireOwner(config, extra);
      const services = await authorized(channelKey);
      return { channelKey: services.channel.key, ...(await services.data.listVideos(max_results, page_token)) };
    }, (value) => `Loaded ${value.videos.length} channel videos.`),
  );

  server.registerTool(
    "video_metrics",
    {
      ...readOnlyTool,
      title: "Video metrics",
      description: "Get aggregate watch, engagement, and subscriber metrics for one owned video and date range.",
      inputSchema: dateInput,
    },
    async ({ channel: channelKey, video_id, start_date, end_date }, extra) => safely(async () => {
      requireOwner(config, extra);
      const services = await authorized(channelKey);
      const range = validateDateRange(start_date, end_date);
      await services.data.assertOwnedVideo(video_id);
      const metrics = await services.analytics.videoMetrics(video_id, range.startDate, range.endDate);
      return { channelKey: services.channel.key, videoId: video_id, ...metrics };
    }, () => "Loaded aggregate metrics for the requested video."),
  );

  server.registerTool(
    "video_daily_metrics",
    {
      ...readOnlyTool,
      title: "Daily video metrics",
      description: "Get daily watch, engagement, and subscriber metrics for one owned video and date range.",
      inputSchema: dateInput,
    },
    async ({ channel: channelKey, video_id, start_date, end_date }, extra) => safely(async () => {
      requireOwner(config, extra);
      const services = await authorized(channelKey);
      const range = validateDateRange(start_date, end_date);
      await services.data.assertOwnedVideo(video_id);
      const metrics = await services.analytics.videoDailyMetrics(video_id, range.startDate, range.endDate);
      return { channelKey: services.channel.key, videoId: video_id, ...metrics };
    }, (value) => `Loaded ${value.rows.length} daily metric rows.`),
  );

  server.registerTool(
    "traffic_sources",
    {
      ...readOnlyTool,
      title: "Video traffic sources",
      description: "Get views and watch time grouped by traffic-source type for one owned video and date range.",
      inputSchema: dateInput,
    },
    async ({ channel: channelKey, video_id, start_date, end_date }, extra) => safely(async () => {
      requireOwner(config, extra);
      const services = await authorized(channelKey);
      const range = validateDateRange(start_date, end_date);
      await services.data.assertOwnedVideo(video_id);
      const metrics = await services.analytics.trafficSources(video_id, range.startDate, range.endDate);
      return { channelKey: services.channel.key, videoId: video_id, ...metrics };
    }, (value) => `Loaded ${value.rows.length} traffic-source rows.`),
  );

  server.registerTool(
    "video_reach",
    {
      ...readOnlyTool,
      title: "Video reach",
      description: "Get thumbnail impressions, weighted thumbnail CTR, daily rows, and available report coverage for one owned video.",
      inputSchema: dateInput,
    },
    async ({ channel: channelKey, video_id, start_date, end_date }, extra) => safely(async () => {
      requireOwner(config, extra);
      const services = await authorized(channelKey);
      const range = validateDateRange(start_date, end_date);
      await services.data.assertOwnedVideo(video_id);
      return { channelKey: services.channel.key, ...(await services.reporting.getVideoReach(video_id, range.startDate, range.endDate)) };
    }, (value) => `Loaded ${value.daily.length} daily Reach rows.`),
  );

  server.registerTool(
    "latest_snapshot",
    {
      ...readOnlyTool,
      title: "Latest immutable snapshot",
      description: "Export the newest complete immutable collector snapshot for one configured channel.",
      inputSchema: { channel: channelInput },
    },
    async ({ channel: channelKey }, extra) => safely(async () => {
      requireOwner(config, extra);
      const services = selected(channelKey);
      const exported = await services.store.latestSnapshot();
      if (!exported) throw new PublicError("snapshot_not_found", "No archived snapshot was found.", 404);
      return {
        channelKey: services.channel.key,
        archivePath: exported.path,
        snapshot: exported.snapshot,
      };
    }, (value) => `Exported snapshot ${value.snapshot.snapshot_id} observed at ${value.snapshot.observed_at}.`),
  );

  server.registerTool(
    "export_snapshot",
    {
      ...readOnlyTool,
      title: "Export immutable snapshot",
      description: "Export one complete immutable collector snapshot by snapshot_id or exact observed_at.",
      inputSchema: {
        channel: channelInput,
        snapshot_id: z.string().uuid().optional(),
        observed_at: z.string().datetime({ offset: true }).optional(),
      },
    },
    async ({ channel: channelKey, snapshot_id, observed_at }, extra) => safely(async () => {
      requireOwner(config, extra);
      const services = selected(channelKey);
      const exported = await services.store.exportSnapshot({ snapshotId: snapshot_id, observedAt: observed_at });
      if (!exported) throw new PublicError("snapshot_not_found", "The requested snapshot was not found.", 404);
      return {
        channelKey: services.channel.key,
        archivePath: exported.path,
        snapshot: exported.snapshot,
      };
    }, (value) => `Exported snapshot ${value.snapshot.snapshot_id} observed at ${value.snapshot.observed_at}.`),
  );

  server.registerTool(
    "export_reach_report",
    {
      ...readOnlyTool,
      title: "Export raw Reach report",
      description: "Export the original Reach CSV and metadata referenced by one immutable collector snapshot.",
      inputSchema: {
        channel: channelInput,
        report_id: z.string().min(1).max(512),
        snapshot_id: z.string().uuid().optional(),
        observed_at: z.string().datetime({ offset: true }).optional(),
      },
    },
    async ({ channel: channelKey, report_id, snapshot_id, observed_at }, extra) => safely(async () => {
      requireOwner(config, extra);
      const services = selected(channelKey);
      const exported = await services.store.exportSnapshot({ snapshotId: snapshot_id, observedAt: observed_at });
      if (!exported) throw new PublicError("snapshot_not_found", "The requested snapshot was not found.", 404);
      const report = await services.store.exportReachReport(exported.snapshot, report_id);
      if (!report) {
        throw new PublicError(
          "reach_report_not_found",
          "The requested Reach report was not found in this snapshot.",
          404,
        );
      }
      return {
        channelKey: services.channel.key,
        snapshot: {
          snapshot_id: exported.snapshot.snapshot_id,
          observed_at: exported.snapshot.observed_at,
          archive_path: exported.path,
        },
        report: {
          report_id,
          metadata: report.metadata,
          metadata_archive_path: report.metadataPath,
          csv_archive_path: report.csvPath,
          csv_content_type: "text/csv; charset=utf-8",
          csv: report.csv,
        },
      };
    }, (value) => `Exported Reach report ${value.report.report_id} from snapshot ${value.snapshot.snapshot_id}.`),
  );

  server.registerTool(
    "metric_history",
    {
      ...readOnlyTool,
      title: "Metric observation history",
      description: "Read archived observations of one metric, preserving both metric_date and observed_at.",
      inputSchema: {
        ...dateInput,
        metric: z.string().regex(/^[A-Za-z][A-Za-z0-9_]*$/).max(128),
      },
    },
    async ({ channel: channelKey, video_id, metric, start_date, end_date }, extra) => safely(async () => {
      requireOwner(config, extra);
      const services = await authorized(channelKey);
      const range = validateDateRange(start_date, end_date);
      await services.data.assertOwnedVideo(video_id);
      return { channelKey: services.channel.key, ...(await services.history.metricHistory(video_id, metric, range.startDate, range.endDate)) };
    }, (value) => `Loaded ${value.observations.length} archived observations.`),
  );

  server.registerTool(
    "metric_revisions",
    {
      ...readOnlyTool,
      title: "Metric revisions",
      description: "Find metric dates whose archived values changed across collection times.",
      inputSchema: dateInput,
    },
    async ({ channel: channelKey, video_id, start_date, end_date }, extra) => safely(async () => {
      requireOwner(config, extra);
      const services = await authorized(channelKey);
      const range = validateDateRange(start_date, end_date);
      await services.data.assertOwnedVideo(video_id);
      return { channelKey: services.channel.key, ...(await services.history.metricRevisions(video_id, range.startDate, range.endDate)) };
    }, (value) => `Found ${value.revisions.length} revised date/source groups.`),
  );

  server.registerTool(
    "snapshot_diff",
    {
      ...readOnlyTool,
      title: "Snapshot diff",
      description: "Compare archived metrics for one owned video at two exact observed_at timestamps.",
      inputSchema: {
        channel: channelInput,
        video_id: dateInput.video_id,
        observed_at_a: z.string().datetime({ offset: true }),
        observed_at_b: z.string().datetime({ offset: true }),
      },
    },
    async ({ channel: channelKey, video_id, observed_at_a, observed_at_b }, extra) => safely(async () => {
      requireOwner(config, extra);
      const services = await authorized(channelKey);
      await services.data.assertOwnedVideo(video_id);
      return { channelKey: services.channel.key, ...(await services.history.snapshotDiff(video_id, observed_at_a, observed_at_b)) };
    }, (value) => `Found ${value.changes.length} differences between the snapshots.`),
  );

  return server;
}
