export const APP_DISPLAY_NAME = "CDMH AY";
export const APP_PACKAGE_NAME = "cdmh-ay";
export const APP_VERSION = "0.3.0";
