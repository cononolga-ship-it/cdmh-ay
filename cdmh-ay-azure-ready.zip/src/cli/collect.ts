import { loadCollectorConfig } from "../config.js";
import { log } from "../logging.js";
import { createRuntime } from "../runtime.js";
import { runOneDriveExportPostStep } from "../onedrive/post-step.js";

async function main(): Promise<void> {
  const config = loadCollectorConfig();
  const runtime = createRuntime(config);
  await runtime.loadGoogleTokens();
  const targets = config.collectChannel
    ? [runtime.getChannel(config.collectChannel)]
    : config.channels.map((channel) => runtime.getChannel(channel.key));
  const execution = await runtime.collectorLease.runExclusive(async () => {
    for (const target of targets) {
      const result = await target.collector.collect();
      log.info({
        event: "channel_collection_completed",
        channel: target.channel.key,
        snapshot_path: result.snapshotPath,
        snapshot_id: result.snapshotId,
        analytics_status: "Сбор аналитики: завершен",
      });
      if (runtime.oneDrive) {
        const exported = await runOneDriveExportPostStep(
          target.channel.key,
          result,
          target.store,
          runtime.oneDrive,
        );
        log.info({
          event: exported.status === "completed" ? "onedrive_export_completed" : "onedrive_export_pending_retry",
          channel: target.channel.key,
          snapshot_id: result.snapshotId,
          onedrive_status: exported.status === "completed"
            ? "Экспорт OneDrive: завершен"
            : "Экспорт OneDrive: ожидает повторной попытки",
          files: exported.files,
          pending: exported.pendingCount,
        });
      }
    }
  });
  log.info({ event: execution.executed ? "collection_completed" : "collection_skipped_lease_held" });
}

main().catch(() => {
  log.error({ event: "collection_failed", code: "collector_error" });
  process.exitCode = 1;
});
