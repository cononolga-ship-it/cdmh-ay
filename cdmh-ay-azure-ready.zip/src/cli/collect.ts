import { loadCollectorConfig } from "../config.js";
import { log } from "../logging.js";
import { createRuntime } from "../runtime.js";

async function main(): Promise<void> {
  const config = loadCollectorConfig();
  const runtime = createRuntime(config);
  await runtime.loadGoogleToken();
  const execution = await runtime.collectorLease.runExclusive(() => runtime.collector.collect());
  log.info({ event: execution.executed ? "collection_completed" : "collection_skipped_lease_held" });
}

main().catch(() => {
  log.error({ event: "collection_failed", code: "collector_error" });
  process.exitCode = 1;
});
