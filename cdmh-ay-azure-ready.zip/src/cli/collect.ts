import { loadCollectorConfig } from "../config.js";
import { log } from "../logging.js";
import { createRuntime } from "../runtime.js";

async function main(): Promise<void> {
  const config = loadCollectorConfig();
  const runtime = createRuntime(config);
  await runtime.loadGoogleTokens();
  const targets = config.collectChannel
    ? [runtime.getChannel(config.collectChannel)]
    : config.channels.map((channel) => runtime.getChannel(channel.key));
  const execution = await runtime.collectorLease.runExclusive(async () => {
    for (const target of targets) {
      const result = await target.collector.collect();
      log.info({
        event: "channel_collection_completed",
        channel: target.channel.key,
        snapshot_path: result.snapshotPath,
      });
    }
  });
  log.info({ event: execution.executed ? "collection_completed" : "collection_skipped_lease_held" });
}

main().catch(() => {
  log.error({ event: "collection_failed", code: "collector_error" });
  process.exitCode = 1;
});
