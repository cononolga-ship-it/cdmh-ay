import { loadConfig } from "../config.js";
import { createOneDriveConsentUrl } from "../onedrive/consent.js";
import { createRuntime } from "../runtime.js";

async function main(): Promise<void> {
  const config = loadConfig();
  if (!config.oneDriveExport) throw new Error("OneDrive export is disabled.");
  const runtime = createRuntime(config);
  process.stdout.write(`${await createOneDriveConsentUrl(config, runtime.runtimeState)}\n`);
}

main().catch(() => {
  process.stderr.write("Could not create a OneDrive consent URL.\n");
  process.exitCode = 1;
});
