import { createRuntimeStateStore } from "../azure/runtime-state.js";
import { loadCollectorConfig } from "../config.js";
import { toSafeError } from "../errors.js";
import { log } from "../logging.js";
import { CosmosMicrosoftTokenStore } from "../microsoft/cosmos-token-store.js";
import { GraphClient } from "../microsoft/graph-client.js";
import { MicrosoftTokenProvider } from "../microsoft/onedrive-auth.js";
import { MicrosoftTokenCipher } from "../microsoft/token-crypto.js";

const migrationRoots = [
  { channel: "conon_d", root: "0_0COD/01_0 CDMH AY" },
  { channel: "kadr19", root: "0_0COD/02_0 KADR AY" },
] as const;
const youtubeFolders = ["snapshots", "index", "reach-reports"] as const;

async function main(): Promise<void> {
  log.info({ event: "archive_migration_start" });
  const config = loadCollectorConfig();
  const runtimeState = createRuntimeStateStore(config);
  const tokenStore = new CosmosMicrosoftTokenStore(
    runtimeState,
    new MicrosoftTokenCipher(config.microsoftTokenEncryptionKey),
    config.microsoftBootstrapRefreshToken,
  );
  const tokens = new MicrosoftTokenProvider(config, tokenStore);

  for (const migration of migrationRoots) {
    log.info({ event: "archive_migration_channel_start", channel: migration.channel });
    const graph = new GraphClient(tokens, fetch, migration.root);
    let movedFiles = 0;
    for (const folder of youtubeFolders) {
      log.info({ event: "archive_migration_folder_start", channel: migration.channel, folder });
      const result = await graph.moveFolderInto(folder, "YouTube");
      movedFiles += result.files;
      log.info({
        event: "archive_folder_migration",
        channel: migration.channel,
        folder,
        moved: result.moved,
        files: result.files,
      });
    }
    log.info({ event: "archive_migration_completed", channel: migration.channel, moved_files: movedFiles });
  }
}

main().catch((error: unknown) => {
  log.error({ event: "archive_migration_failed", code: toSafeError(error).code });
  process.exitCode = 1;
});
