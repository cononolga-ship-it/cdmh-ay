import { ArchiveHistoryService } from "./archive/history-service.js";
import { HistoricalCollector } from "./archive/collector.js";
import { CosmosArchiveBackend } from "./archive/cosmos-backend.js";
import { SnapshotStore } from "./archive/snapshot-store.js";
import { CollectorDistributedLease } from "./azure/distributed-lease.js";
import { createRuntimeStateStore } from "./azure/runtime-state.js";
import type { AppConfig, ChannelConfig } from "./config.js";
import { PublicError } from "./errors.js";
import { createGoogleApis, createGoogleAuth, type GoogleAuth } from "./google/client.js";
import { CosmosGoogleTokenStore } from "./google/cosmos-token-store.js";
import { YoutubeAnalyticsService } from "./google/youtube-analytics.js";
import { YoutubeDataService } from "./google/youtube-data.js";
import { YoutubeReportingService } from "./google/youtube-reporting.js";
import { OneDriveTokenProvider } from "./onedrive/auth.js";
import { OneDriveExportQueue } from "./onedrive/export-queue.js";
import { OneDriveSnapshotExporter } from "./onedrive/exporter.js";
import { OneDriveGraphClient } from "./onedrive/graph-client.js";
import { OneDriveTokenStore } from "./onedrive/token-store.js";

export type ChannelRuntime = {
  channel: ChannelConfig;
  googleAuth: GoogleAuth;
  data: YoutubeDataService;
  analytics: YoutubeAnalyticsService;
  reporting: YoutubeReportingService;
  store: SnapshotStore;
  history: ArchiveHistoryService;
  collector: HistoricalCollector;
};

export function createRuntime(config: AppConfig) {
  const runtimeState = createRuntimeStateStore(config);
  const googleTokenStore = new CosmosGoogleTokenStore(runtimeState, config.runtimeStateEncryptionKey);
  const channels = new Map<string, ChannelRuntime>();

  for (const channel of config.channels) {
    const googleAuth = createGoogleAuth(config);
    const googleApis = createGoogleApis(googleAuth);
    const data = new YoutubeDataService(channel.youtubeChannelId, googleApis.youtube);
    const analytics = new YoutubeAnalyticsService(googleApis.analytics);
    const reporting = new YoutubeReportingService(
      channel.youtubeChannelId,
      channel.name,
      googleAuth,
      googleApis.reporting,
      channel.reachJobId,
    );
    const store = new SnapshotStore(new CosmosArchiveBackend(runtimeState, channel.key));
    const history = new ArchiveHistoryService(store);
    const collector = new HistoricalCollector({
      youtubeChannelId: channel.youtubeChannelId,
      collectionLookbackDays: config.collectionLookbackDays,
      collectorConcurrency: config.collectorConcurrency,
    }, { data, analytics, reporting, store });
    channels.set(channel.key, { channel, googleAuth, data, analytics, reporting, store, history, collector });
  }

  const collectorLease = new CollectorDistributedLease(runtimeState);
  const oneDrive = config.oneDriveExport ? (() => {
    const tokenStore = new OneDriveTokenStore(runtimeState, config.runtimeStateEncryptionKey);
    const tokenProvider = new OneDriveTokenProvider(config.oneDriveExport!, tokenStore);
    const graph = new OneDriveGraphClient(tokenProvider);
    return {
      tokenStore,
      queue: new OneDriveExportQueue(runtimeState),
      graph,
      exporter: new OneDriveSnapshotExporter(graph, config.oneDriveExport!.rootPath),
    };
  })() : undefined;
  const getChannel = (key = config.defaultChannelKey): ChannelRuntime => {
    const channel = channels.get(key);
    if (!channel) throw new PublicError("unknown_channel", "The requested channel is not configured.", 404);
    return channel;
  };
  const loadGoogleTokens = async () => {
    for (const channel of channels.values()) {
      const stored = await googleTokenStore.read(channel.channel.youtubeChannelId);
      const refreshToken = stored ?? (
        channel.channel.key === config.defaultChannelKey ? config.googleBootstrapRefreshToken : null
      );
      if (refreshToken) channel.googleAuth.setCredentials({ refresh_token: refreshToken });
    }
  };

  return {
    channels,
    getChannel,
    collectorLease,
    runtimeState,
    googleTokenStore,
    loadGoogleTokens,
    oneDrive,
  };
}

export type AppRuntime = ReturnType<typeof createRuntime>;
