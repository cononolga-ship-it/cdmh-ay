import { ArchiveHistoryService } from "./archive/history-service.js";
import { HistoricalCollector } from "./archive/collector.js";
import { SnapshotStore } from "./archive/snapshot-store.js";
import { CollectorDistributedLease } from "./azure/distributed-lease.js";
import { createRuntimeStateStore } from "./azure/runtime-state.js";
import type { AppConfig, ChannelConfig } from "./config.js";
import { PublicError } from "./errors.js";
import { createGoogleApis, createGoogleAuth, type GoogleAuth } from "./google/client.js";
import { CosmosGoogleTokenStore } from "./google/cosmos-token-store.js";
import { YoutubeAnalyticsService } from "./google/youtube-analytics.js";
import { YoutubeDataService } from "./google/youtube-data.js";
import { YoutubeReportingService } from "./google/youtube-reporting.js";
import { GraphClient } from "./microsoft/graph-client.js";
import { CosmosMicrosoftTokenStore } from "./microsoft/cosmos-token-store.js";
import { MicrosoftTokenProvider } from "./microsoft/onedrive-auth.js";
import { MicrosoftTokenCipher } from "./microsoft/token-crypto.js";

export type ChannelRuntime = {
  channel: ChannelConfig;
  googleAuth: GoogleAuth;
  data: YoutubeDataService;
  analytics: YoutubeAnalyticsService;
  reporting: YoutubeReportingService;
  graph: GraphClient;
  store: SnapshotStore;
  history: ArchiveHistoryService;
  collector: HistoricalCollector;
};

export function createRuntime(config: AppConfig) {
  const runtimeState = createRuntimeStateStore(config);
  const googleTokenStore = new CosmosGoogleTokenStore(runtimeState, config.microsoftTokenEncryptionKey);
  const microsoftTokenStore = new CosmosMicrosoftTokenStore(
    runtimeState,
    new MicrosoftTokenCipher(config.microsoftTokenEncryptionKey),
    config.microsoftBootstrapRefreshToken,
  );
  const microsoftTokens = new MicrosoftTokenProvider(config, microsoftTokenStore);
  const channels = new Map<string, ChannelRuntime>();

  for (const channel of config.channels) {
    const googleAuth = createGoogleAuth(config);
    const googleApis = createGoogleApis(googleAuth);
    const data = new YoutubeDataService(channel.youtubeChannelId, googleApis.youtube);
    const analytics = new YoutubeAnalyticsService(googleApis.analytics);
    const reporting = new YoutubeReportingService(
      channel.youtubeChannelId,
      channel.name,
      googleAuth,
      googleApis.reporting,
      channel.reachJobId,
    );
    const graph = new GraphClient(microsoftTokens, fetch, channel.archiveRoot);
    const store = new SnapshotStore(graph);
    const history = new ArchiveHistoryService(store);
    const collector = new HistoricalCollector({
      youtubeChannelId: channel.youtubeChannelId,
      collectionLookbackDays: config.collectionLookbackDays,
      collectorConcurrency: config.collectorConcurrency,
    }, { data, analytics, reporting, store });
    channels.set(channel.key, { channel, googleAuth, data, analytics, reporting, graph, store, history, collector });
  }

  const collectorLease = new CollectorDistributedLease(runtimeState);
  const getChannel = (key = config.defaultChannelKey): ChannelRuntime => {
    const channel = channels.get(key);
    if (!channel) throw new PublicError("unknown_channel", "The requested channel is not configured.", 404);
    return channel;
  };
  const loadGoogleTokens = async () => {
    for (const channel of channels.values()) {
      const stored = await googleTokenStore.read(channel.channel.youtubeChannelId);
      const refreshToken = stored ?? (
        channel.channel.key === config.defaultChannelKey ? config.googleBootstrapRefreshToken : null
      );
      if (refreshToken) channel.googleAuth.setCredentials({ refresh_token: refreshToken });
    }
  };

  return {
    channels,
    getChannel,
    collectorLease,
    runtimeState,
    microsoftTokenStore,
    googleTokenStore,
    loadGoogleTokens,
  };
}

export type AppRuntime = ReturnType<typeof createRuntime>;
