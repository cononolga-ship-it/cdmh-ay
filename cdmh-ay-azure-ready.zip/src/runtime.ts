import { ArchiveHistoryService } from "./archive/history-service.js";
import { HistoricalCollector } from "./archive/collector.js";
import { SnapshotStore } from "./archive/snapshot-store.js";
import { CollectorDistributedLease } from "./azure/distributed-lease.js";
import { createRuntimeStateStore } from "./azure/runtime-state.js";
import type { AppConfig } from "./config.js";
import { createGoogleApis, createGoogleAuth } from "./google/client.js";
import { YoutubeAnalyticsService } from "./google/youtube-analytics.js";
import { YoutubeDataService } from "./google/youtube-data.js";
import { YoutubeReportingService } from "./google/youtube-reporting.js";
import { GraphClient } from "./microsoft/graph-client.js";
import { CosmosMicrosoftTokenStore } from "./microsoft/cosmos-token-store.js";
import { MicrosoftTokenProvider } from "./microsoft/onedrive-auth.js";
import { MicrosoftTokenCipher } from "./microsoft/token-crypto.js";

export function createRuntime(config: AppConfig) {
  const googleAuth = createGoogleAuth(config);
  const googleApis = createGoogleApis(googleAuth);
  const data = new YoutubeDataService(config, googleApis.youtube);
  const analytics = new YoutubeAnalyticsService(googleApis.analytics);
  const reporting = new YoutubeReportingService(config, googleAuth, googleApis.reporting);
  const runtimeState = createRuntimeStateStore(config);
  const microsoftTokenStore = new CosmosMicrosoftTokenStore(
    runtimeState,
    new MicrosoftTokenCipher(config.microsoftTokenEncryptionKey),
    config.microsoftBootstrapRefreshToken,
  );
  const microsoftTokens = new MicrosoftTokenProvider(config, microsoftTokenStore);
  const graph = new GraphClient(microsoftTokens);
  const store = new SnapshotStore(graph);
  const history = new ArchiveHistoryService(store);
  const collector = new HistoricalCollector(config, { data, analytics, reporting, store });
  const collectorLease = new CollectorDistributedLease(runtimeState);
  return { data, analytics, reporting, graph, store, history, collector, collectorLease, runtimeState, microsoftTokenStore };
}
