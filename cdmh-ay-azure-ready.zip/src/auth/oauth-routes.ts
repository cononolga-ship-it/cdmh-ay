import { createHash, randomBytes } from "node:crypto";
import express, { type Request, type Response } from "express";
import { CodeChallengeMethod } from "google-auth-library";
import { google } from "googleapis";
import type { AppConfig } from "../config.js";
import { PublicError } from "../errors.js";
import { MCP_SCOPE, TokenService } from "./tokens.js";

function stringValue(value: unknown, name: string, maxLength = 4096): string {
  if (typeof value !== "string" || value.length < 1 || value.length > maxLength) {
    throw new PublicError("invalid_request", `Missing or invalid ${name}.`);
  }
  return value;
}

function validateRedirectUri(value: string): void {
  const url = new URL(value);
  const loopback = url.hostname === "localhost" || url.hostname === "127.0.0.1" || url.hostname === "[::1]";
  if (url.hash || (!loopback && url.protocol !== "https:") || (loopback && !["http:", "https:"].includes(url.protocol))) {
    throw new PublicError("invalid_redirect_uri", "The OAuth redirect URI is not allowed.");
  }
  if (!loopback && url.hostname !== "chatgpt.com") {
    throw new PublicError("invalid_redirect_uri", "The OAuth redirect URI is not allowed.");
  }
}

function validateScope(value: string): string {
  const scopes = [...new Set(value.split(/\s+/).filter(Boolean))];
  if (scopes.length !== 1 || scopes[0] !== MCP_SCOPE) {
    throw new PublicError("invalid_scope", "Only the read-only YouTube analytics scope is available.");
  }
  return MCP_SCOPE;
}

function oauthError(res: Response, error: unknown): void {
  const status = error instanceof PublicError ? error.status : 400;
  const code = error instanceof PublicError ? error.code : "invalid_request";
  const description = error instanceof PublicError ? error.publicMessage : "The OAuth request is invalid.";
  res.status(status).json({ error: code, error_description: description });
}

export function createOAuthRouter(config: AppConfig, tokens: TokenService) {
  const router = express.Router();

  router.get("/.well-known/oauth-protected-resource", (_req, res) => {
    res.json({
      resource: config.mcpResourceUrl,
      authorization_servers: [config.publicBaseUrl],
      scopes_supported: [MCP_SCOPE],
      resource_documentation: `${config.publicBaseUrl}/`,
    });
  });

  router.get("/.well-known/oauth-authorization-server", (_req, res) => {
    res.json({
      issuer: config.publicBaseUrl,
      authorization_endpoint: `${config.publicBaseUrl}/oauth/authorize`,
      token_endpoint: `${config.publicBaseUrl}/oauth/token`,
      registration_endpoint: `${config.publicBaseUrl}/oauth/register`,
      scopes_supported: [MCP_SCOPE],
      response_types_supported: ["code"],
      grant_types_supported: ["authorization_code", "refresh_token"],
      token_endpoint_auth_methods_supported: ["none"],
      code_challenge_methods_supported: ["S256"],
      authorization_response_iss_parameter_supported: true,
    });
  });

  router.post("/oauth/register", express.json({ limit: "16kb" }), async (req, res) => {
    try {
      const redirectUris = Array.isArray(req.body?.redirect_uris)
        ? req.body.redirect_uris.map((uri: unknown) => stringValue(uri, "redirect_uri"))
        : [];
      if (!redirectUris.length || redirectUris.length > 10) {
        throw new PublicError("invalid_client_metadata", "One or more redirect URIs are required.");
      }
      redirectUris.forEach(validateRedirectUri);
      const authMethod = req.body?.token_endpoint_auth_method ?? "none";
      if (authMethod !== "none") {
        throw new PublicError("invalid_client_metadata", "Only public PKCE clients are supported.");
      }
      const clientName = typeof req.body?.client_name === "string"
        ? req.body.client_name.slice(0, 200)
        : "ChatGPT MCP client";
      const clientId = await tokens.registerClient({ redirectUris, clientName });
      res.status(201).json({
        client_id: clientId,
        client_id_issued_at: Math.floor(Date.now() / 1000),
        client_name: clientName,
        redirect_uris: redirectUris,
        grant_types: ["authorization_code", "refresh_token"],
        response_types: ["code"],
        token_endpoint_auth_method: "none",
      });
    } catch (error) {
      oauthError(res, error);
    }
  });

  router.get("/oauth/authorize", async (req, res) => {
    try {
      const responseType = stringValue(req.query.response_type, "response_type", 32);
      if (responseType !== "code") throw new PublicError("unsupported_response_type", "Only response_type=code is supported.");
      const clientId = stringValue(req.query.client_id, "client_id", 8192);
      const client = await tokens.verifyClient(clientId);
      const redirectUri = stringValue(req.query.redirect_uri, "redirect_uri");
      if (!client.redirectUris.includes(redirectUri)) {
        throw new PublicError("invalid_redirect_uri", "The OAuth redirect URI does not match the registered client.");
      }
      const resource = stringValue(req.query.resource, "resource");
      if (resource !== config.mcpResourceUrl) throw new PublicError("invalid_target", "The OAuth resource is invalid.");
      const scope = validateScope(stringValue(req.query.scope, "scope", 512));
      const challengeMethod = stringValue(req.query.code_challenge_method, "code_challenge_method", 16);
      if (challengeMethod !== "S256") throw new PublicError("invalid_request", "PKCE with S256 is required.");
      const codeChallenge = stringValue(req.query.code_challenge, "code_challenge", 128);
      if (!/^[A-Za-z0-9_-]{43,128}$/.test(codeChallenge)) {
        throw new PublicError("invalid_request", "The PKCE code challenge is invalid.");
      }
      const state = typeof req.query.state === "string"
        ? stringValue(req.query.state, "state", 4096)
        : undefined;

      const googleCodeVerifier = randomBytes(48).toString("base64url");
      const googleCodeChallenge = createHash("sha256").update(googleCodeVerifier).digest("base64url");
      const loginState = await tokens.createGoogleLoginState({
        clientIdHash: tokens.hashClientId(clientId),
        redirectUri,
        scope,
        resource,
        codeChallenge,
        googleCodeVerifier,
        ...(state ? { state } : {}),
      });
      const googleAuth = new google.auth.OAuth2(
        config.googleClientId,
        config.googleClientSecret,
        config.googleRedirectUri,
      );
      const url = googleAuth.generateAuthUrl({
        access_type: "online",
        prompt: "select_account",
        scope: ["openid", "email"],
        state: loginState,
        code_challenge: googleCodeChallenge,
        code_challenge_method: CodeChallengeMethod.S256,
      });
      res.redirect(302, url);
    } catch (error) {
      oauthError(res, error);
    }
  });

  router.get("/oauth/google/callback", async (req, res) => {
    try {
      const code = stringValue(req.query.code, "code", 4096);
      const stateToken = stringValue(req.query.state, "state", 8192);
      const request = await tokens.verifyGoogleLoginState(stateToken);
      const googleAuth = new google.auth.OAuth2(
        config.googleClientId,
        config.googleClientSecret,
        config.googleRedirectUri,
      );
      const tokenResponse = await googleAuth.getToken({
        code,
        codeVerifier: request.googleCodeVerifier,
      });
      const idToken = tokenResponse.tokens.id_token;
      if (!idToken) throw new PublicError("access_denied", "Google did not return a verified identity.", 403);
      const ticket = await googleAuth.verifyIdToken({ idToken, audience: config.googleClientId });
      const identity = ticket.getPayload();
      if (!identity?.email_verified || identity.email?.toLowerCase() !== config.ownerGoogleEmail) {
        throw new PublicError("access_denied", "This MCP server is restricted to its owner.", 403);
      }

      const authorizationCode = await tokens.createAuthorizationCode({
        clientIdHash: request.clientIdHash,
        redirectUri: request.redirectUri,
        scope: request.scope,
        resource: request.resource,
        codeChallenge: request.codeChallenge,
        ...(request.state ? { state: request.state } : {}),
      });
      const redirect = new URL(request.redirectUri);
      redirect.searchParams.set("code", authorizationCode);
      if (request.state) redirect.searchParams.set("state", request.state);
      redirect.searchParams.set("iss", config.publicBaseUrl);
      res.redirect(302, redirect.toString());
    } catch (error) {
      oauthError(res, error);
    }
  });

  router.post("/oauth/token", express.urlencoded({ extended: false, limit: "16kb" }), async (req: Request, res) => {
    res.set("Cache-Control", "no-store");
    res.set("Pragma", "no-cache");
    try {
      const grantType = stringValue(req.body?.grant_type, "grant_type", 64);
      const clientId = stringValue(req.body?.client_id, "client_id", 8192);
      await tokens.verifyClient(clientId);
      const clientIdHash = tokens.hashClientId(clientId);
      const resource = stringValue(req.body?.resource, "resource");
      if (resource !== config.mcpResourceUrl) throw new PublicError("invalid_target", "The OAuth resource is invalid.");

      if (grantType === "authorization_code") {
        const code = stringValue(req.body?.code, "code", 8192);
        const redirectUri = stringValue(req.body?.redirect_uri, "redirect_uri");
        const codeVerifier = stringValue(req.body?.code_verifier, "code_verifier", 128);
        const authorization = await tokens.consumeAuthorizationCode(code);
        if (
          authorization.clientIdHash !== clientIdHash ||
          authorization.redirectUri !== redirectUri ||
          authorization.resource !== resource ||
          !tokens.verifyPkce(codeVerifier, authorization.codeChallenge)
        ) throw new PublicError("invalid_grant", "The authorization code could not be verified.");
        res.json(await tokens.issueTokenPair(clientIdHash, authorization.scope));
        return;
      }

      if (grantType === "refresh_token") {
        const refreshToken = stringValue(req.body?.refresh_token, "refresh_token", 8192);
        const verified = await tokens.verifyRefreshToken(refreshToken);
        if (verified.clientIdHash !== clientIdHash) {
          throw new PublicError("invalid_grant", "The refresh token does not belong to this client.");
        }
        res.json(await tokens.issueTokenPair(clientIdHash, verified.scope));
        return;
      }

      throw new PublicError("unsupported_grant_type", "The OAuth grant type is not supported.");
    } catch (error) {
      oauthError(res, error);
    }
  });

  return router;
}
