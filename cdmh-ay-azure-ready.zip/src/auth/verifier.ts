import type { OAuthTokenVerifier } from "@modelcontextprotocol/sdk/server/auth/provider.js";
import { InvalidTokenError } from "@modelcontextprotocol/sdk/server/auth/errors.js";
import type { AppConfig } from "../config.js";
import { TokenService } from "./tokens.js";

export class McpAccessTokenVerifier implements OAuthTokenVerifier {
  constructor(
    private readonly config: AppConfig,
    private readonly tokens: TokenService,
  ) {}

  async verifyAccessToken(token: string) {
    try {
      const payload = await this.tokens.verifyAccessToken(token);
      return {
        token,
        clientId: payload.client_id_hash as string,
        scopes: String(payload.scope).split(" "),
        expiresAt: payload.exp,
        resource: new URL(this.config.mcpResourceUrl),
        extra: { email: payload.sub },
      };
    } catch {
      throw new InvalidTokenError("Invalid or expired access token");
    }
  }
}
