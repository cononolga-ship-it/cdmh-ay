import { createHash, randomUUID } from "node:crypto";
import { SignJWT, jwtVerify, type JWTPayload } from "jose";
import type { AppConfig } from "../config.js";
import { PublicError } from "../errors.js";

export const MCP_SCOPE = "youtube.analytics.read";

export type RegisteredClient = {
  redirectUris: string[];
  clientName: string;
};

type AuthorizationRequest = {
  clientIdHash: string;
  redirectUri: string;
  scope: string;
  resource: string;
  codeChallenge: string;
  state?: string;
  googleCodeVerifier: string;
};

export class TokenService {
  private readonly usedAuthorizationCodes = new Map<string, number>();

  constructor(private readonly config: AppConfig) {}

  async registerClient(client: RegisteredClient): Promise<string> {
    return new SignJWT({
      kind: "oauth_client",
      redirect_uris: client.redirectUris,
      client_name: client.clientName,
    })
      .setProtectedHeader({ alg: "HS256", typ: "JWT" })
      .setIssuer(this.config.publicBaseUrl)
      .setIssuedAt()
      .sign(this.config.signingSecret);
  }

  async verifyClient(clientId: string): Promise<RegisteredClient> {
    const { payload } = await jwtVerify(clientId, this.config.signingSecret, {
      issuer: this.config.publicBaseUrl,
      algorithms: ["HS256"],
    });
    if (payload.kind !== "oauth_client" || !Array.isArray(payload.redirect_uris)) {
      throw new PublicError("invalid_client", "The OAuth client is invalid.", 401);
    }
    const redirectUris = payload.redirect_uris.filter((value): value is string => typeof value === "string");
    if (!redirectUris.length) throw new PublicError("invalid_client", "The OAuth client is invalid.", 401);
    return {
      redirectUris,
      clientName: typeof payload.client_name === "string" ? payload.client_name : "MCP client",
    };
  }

  async createGoogleLoginState(request: AuthorizationRequest): Promise<string> {
    return new SignJWT({ kind: "google_login_state", ...request })
      .setProtectedHeader({ alg: "HS256", typ: "JWT" })
      .setIssuer(this.config.publicBaseUrl)
      .setAudience("google-oauth-callback")
      .setIssuedAt()
      .setExpirationTime("10m")
      .setJti(randomUUID())
      .sign(this.config.signingSecret);
  }

  async verifyGoogleLoginState(token: string): Promise<AuthorizationRequest> {
    const { payload } = await jwtVerify(token, this.config.signingSecret, {
      issuer: this.config.publicBaseUrl,
      audience: "google-oauth-callback",
      algorithms: ["HS256"],
    });
    if (
      payload.kind !== "google_login_state" ||
      typeof payload.clientIdHash !== "string" ||
      typeof payload.redirectUri !== "string" ||
      typeof payload.scope !== "string" ||
      typeof payload.resource !== "string" ||
      typeof payload.codeChallenge !== "string" ||
      typeof payload.googleCodeVerifier !== "string"
    ) throw new PublicError("invalid_request", "The authorization request is invalid.");
    return {
      clientIdHash: payload.clientIdHash,
      redirectUri: payload.redirectUri,
      scope: payload.scope,
      resource: payload.resource,
      codeChallenge: payload.codeChallenge,
      googleCodeVerifier: payload.googleCodeVerifier,
      ...(typeof payload.state === "string" ? { state: payload.state } : {}),
    };
  }

  async createAuthorizationCode(request: Omit<AuthorizationRequest, "googleCodeVerifier">): Promise<string> {
    return new SignJWT({ kind: "authorization_code", ...request })
      .setProtectedHeader({ alg: "HS256", typ: "JWT" })
      .setIssuer(this.config.publicBaseUrl)
      .setAudience("oauth-token-endpoint")
      .setIssuedAt()
      .setExpirationTime("5m")
      .setJti(randomUUID())
      .sign(this.config.signingSecret);
  }

  async consumeAuthorizationCode(code: string) {
    const { payload } = await jwtVerify(code, this.config.signingSecret, {
      issuer: this.config.publicBaseUrl,
      audience: "oauth-token-endpoint",
      algorithms: ["HS256"],
    });
    if (
      payload.kind !== "authorization_code" ||
      typeof payload.jti !== "string" ||
      typeof payload.clientIdHash !== "string" ||
      typeof payload.redirectUri !== "string" ||
      typeof payload.scope !== "string" ||
      typeof payload.resource !== "string" ||
      typeof payload.codeChallenge !== "string"
    ) throw new PublicError("invalid_grant", "The authorization code is invalid.");

    this.removeExpiredCodeMarkers();
    if (this.usedAuthorizationCodes.has(payload.jti)) {
      throw new PublicError("invalid_grant", "The authorization code was already used.");
    }
    this.usedAuthorizationCodes.set(payload.jti, payload.exp ?? Math.floor(Date.now() / 1000) + 300);
    return payload as JWTPayload & {
      clientIdHash: string;
      redirectUri: string;
      scope: string;
      resource: string;
      codeChallenge: string;
    };
  }

  async issueTokenPair(clientIdHash: string, scope = MCP_SCOPE) {
    const accessToken = await this.signUserToken("access_token", clientIdHash, scope, this.config.accessTokenTtlSeconds);
    const refreshToken = await this.signUserToken("refresh_token", clientIdHash, scope, this.config.refreshTokenTtlSeconds);
    return {
      access_token: accessToken,
      token_type: "Bearer",
      expires_in: this.config.accessTokenTtlSeconds,
      refresh_token: refreshToken,
      scope,
    };
  }

  async verifyRefreshToken(token: string) {
    const payload = await this.verifyUserToken(token, "refresh_token");
    return { clientIdHash: payload.client_id_hash as string, scope: payload.scope as string };
  }

  async verifyAccessToken(token: string) {
    return this.verifyUserToken(token, "access_token");
  }

  hashClientId(clientId: string): string {
    return createHash("sha256").update(clientId).digest("base64url");
  }

  verifyPkce(codeVerifier: string, expectedChallenge: string): boolean {
    if (!/^[A-Za-z0-9._~-]{43,128}$/.test(codeVerifier)) return false;
    const actual = createHash("sha256").update(codeVerifier).digest("base64url");
    return actual === expectedChallenge;
  }

  private async signUserToken(
    kind: "access_token" | "refresh_token",
    clientIdHash: string,
    scope: string,
    ttlSeconds: number,
  ) {
    return new SignJWT({ kind, scope, client_id_hash: clientIdHash })
      .setProtectedHeader({ alg: "HS256", typ: "JWT" })
      .setIssuer(this.config.publicBaseUrl)
      .setAudience(this.config.mcpResourceUrl)
      .setSubject(this.config.ownerGoogleEmail)
      .setIssuedAt()
      .setExpirationTime(Math.floor(Date.now() / 1000) + ttlSeconds)
      .setJti(randomUUID())
      .sign(this.config.signingSecret);
  }

  private async verifyUserToken(token: string, kind: "access_token" | "refresh_token") {
    const { payload } = await jwtVerify(token, this.config.signingSecret, {
      issuer: this.config.publicBaseUrl,
      audience: this.config.mcpResourceUrl,
      algorithms: ["HS256"],
    });
    if (
      payload.kind !== kind ||
      payload.sub !== this.config.ownerGoogleEmail ||
      payload.scope !== MCP_SCOPE ||
      typeof payload.client_id_hash !== "string"
    ) throw new PublicError("invalid_token", "The OAuth token is invalid.", 401);
    return payload;
  }

  private removeExpiredCodeMarkers(): void {
    const now = Math.floor(Date.now() / 1000);
    for (const [jti, exp] of this.usedAuthorizationCodes) {
      if (exp < now) this.usedAuthorizationCodes.delete(jti);
    }
  }
}
