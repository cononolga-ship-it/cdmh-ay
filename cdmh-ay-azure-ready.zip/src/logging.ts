type LogFields = {
  event: string;
  method?: string;
  path?: string;
  status?: number;
  code?: string;
  channel?: string;
  snapshot_path?: string;
};

function write(level: "info" | "error", fields: LogFields): void {
  // Deliberately accept only a small allowlist. Never pass headers, bodies,
  // query strings, tokens, Google error responses, or tool result data here.
  const line = JSON.stringify({ level, time: new Date().toISOString(), ...fields });
  if (level === "error") process.stderr.write(`${line}\n`);
  else process.stdout.write(`${line}\n`);
}

export const log = {
  info: (fields: LogFields) => write("info", fields),
  error: (fields: LogFields) => write("error", fields),
};
