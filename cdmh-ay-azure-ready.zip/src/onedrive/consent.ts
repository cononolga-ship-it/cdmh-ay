import { createHash, randomBytes } from "node:crypto";
import express from "express";
import {
  RUNTIME_PARTITION_KEY,
  RuntimeStateConflictError,
  type RuntimeDocument,
  type RuntimeStateStore,
} from "../azure/runtime-state.js";
import type { AppConfig } from "../config.js";
import { PublicError } from "../errors.js";
import {
  buildAuthorizationUrl,
  exchangeAuthorizationCode,
  readAuthorizedAccount,
} from "./auth.js";
import type { OneDriveTokenStore } from "./token-store.js";

const CONSENT_TTL_MS = 15 * 60_000;

type ConsentDocument = RuntimeDocument & {
  schema_version: 1;
  kind: "onedrive_export_consent";
  verifier: string;
  expires_at: string;
  used: boolean;
  ttl: number;
};

export async function createOneDriveConsentUrl(
  config: AppConfig,
  stateStore: RuntimeStateStore,
): Promise<string> {
  const oneDrive = requiredConfig(config);
  const state = randomBytes(32).toString("base64url");
  const verifier = randomBytes(48).toString("base64url");
  const document: ConsentDocument = {
    id: consentId(state),
    partitionKey: RUNTIME_PARTITION_KEY,
    schema_version: 1,
    kind: "onedrive_export_consent",
    verifier,
    expires_at: new Date(Date.now() + CONSENT_TTL_MS).toISOString(),
    used: false,
    ttl: 3600,
  };
  await stateStore.create(document);
  return buildAuthorizationUrl(oneDrive, state, hash(verifier));
}

export function createOneDriveConsentRouter(
  config: AppConfig,
  stateStore: RuntimeStateStore,
  tokenStore: OneDriveTokenStore,
) {
  const router = express.Router();
  router.use((_req, res, next) => {
    res.set({ "Cache-Control": "no-store", "Referrer-Policy": "no-referrer", "X-Robots-Tag": "noindex" });
    next();
  });

  router.get("/oauth/onedrive/callback", async (req, res) => {
    try {
      const oneDrive = requiredConfig(config);
      const state = field(req.query.state, 256);
      const code = field(req.query.code, 8192);
      const current = await stateStore.read<ConsentDocument>(consentId(state));
      if (!current || current.document.used || Date.parse(current.document.expires_at) < Date.now()) {
        throw new PublicError("invalid_state", "OneDrive authorization state is invalid.", 400);
      }
      try {
        await stateStore.replace({ ...current.document, used: true }, current.etag);
      } catch (error) {
        if (error instanceof RuntimeStateConflictError) {
          throw new PublicError("invalid_state", "OneDrive authorization state was already used.", 400);
        }
        throw error;
      }
      const grant = await exchangeAuthorizationCode(oneDrive, code, current.document.verifier);
      const account = await readAuthorizedAccount(grant.accessToken);
      await verifyDrive(grant.accessToken);
      await tokenStore.saveAuthorizedToken(grant.refreshToken, account);
      res.status(200).type("text/plain").send(
        `Авторизация OneDrive сохранена для ${account.user_principal_name ?? account.display_name ?? "выбранного аккаунта"}. Окно можно закрыть.`,
      );
    } catch {
      res.status(400).type("text/plain").send(
        "Авторизация OneDrive не сохранена. Создайте новую одноразовую ссылку и повторите вход.",
      );
    }
  });
  return router;
}

async function verifyDrive(accessToken: string): Promise<void> {
  const response = await fetch("https://graph.microsoft.com/v1.0/me/drive?$select=id,driveType", {
    headers: { authorization: `Bearer ${accessToken}` },
    signal: AbortSignal.timeout(30_000),
  });
  if (!response.ok) throw new PublicError("onedrive_unavailable", "The selected account has no accessible OneDrive.", 403);
}

function requiredConfig(config: AppConfig): NonNullable<AppConfig["oneDriveExport"]> {
  if (!config.oneDriveExport) throw new PublicError("onedrive_disabled", "OneDrive export is disabled.", 404);
  return config.oneDriveExport;
}

function field(value: unknown, maxLength: number): string {
  if (typeof value !== "string" || !value || value.length > maxLength || !/^[A-Za-z0-9._~-]+$/.test(value)) {
    throw new PublicError("invalid_request", "The OneDrive authorization response is invalid.", 400);
  }
  return value;
}

function hash(value: string): string {
  return createHash("sha256").update(value).digest("base64url");
}

function consentId(state: string): string {
  return `onedrive-export-consent:${hash(state)}`;
}
