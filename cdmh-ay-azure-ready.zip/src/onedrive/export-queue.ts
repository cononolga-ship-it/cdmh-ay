import {
  RUNTIME_PARTITION_KEY,
  RuntimeStateConflictError,
  type RuntimeDocument,
  type RuntimeStateStore,
} from "../azure/runtime-state.js";

export type ReachExportReference = {
  report_id: string;
  csv_path: string;
  metadata_path: string;
};

export type OneDriveExportTask = {
  channel_key: string;
  snapshot_id: string;
  observed_at: string;
  snapshot_path: string;
  reach_reports: ReachExportReference[];
};

type QueueDocument = RuntimeDocument & {
  schema_version: 1;
  kind: "onedrive_export_queue";
  channel_key: string;
  pending: OneDriveExportTask[];
  updated_at: string;
};

export type ExportStatusDocument = RuntimeDocument & {
  schema_version: 1;
  kind: "onedrive_export_status";
  channel_key: string;
  snapshot_id: string;
  observed_at: string;
  status: "pending" | "completed";
  attempts: number;
  last_attempt_at?: string;
  last_error_code?: string;
  completed_at?: string;
  target_path?: string;
};

export class OneDriveExportQueue {
  constructor(private readonly state: RuntimeStateStore) {}

  async register(task: OneDriveExportTask): Promise<void> {
    const status = await this.state.read<ExportStatusDocument>(statusId(task.channel_key, task.snapshot_id));
    if (status?.document.status === "completed") return;
    if (!status) {
      const document: ExportStatusDocument = {
        id: statusId(task.channel_key, task.snapshot_id),
        partitionKey: RUNTIME_PARTITION_KEY,
        schema_version: 1,
        kind: "onedrive_export_status",
        channel_key: task.channel_key,
        snapshot_id: task.snapshot_id,
        observed_at: task.observed_at,
        status: "pending",
        attempts: 0,
      };
      try {
        await this.state.create(document);
      } catch (error) {
        if (!(error instanceof RuntimeStateConflictError) || error.statusCode !== 409) throw error;
      }
    }
    await this.updateQueue(task.channel_key, (pending) =>
      pending.some((item) => item.snapshot_id === task.snapshot_id) ? pending : [...pending, task],
    );
  }

  async listPending(channelKey: string): Promise<OneDriveExportTask[]> {
    const current = await this.state.read<QueueDocument>(queueId(channelKey));
    return [...(current?.document.pending ?? [])].sort((a, b) => a.observed_at.localeCompare(b.observed_at));
  }

  async markPending(task: OneDriveExportTask, errorCode: string): Promise<void> {
    await this.updateStatus(task, (current) => ({
      ...current,
      status: "pending",
      attempts: current.attempts + 1,
      last_attempt_at: new Date().toISOString(),
      last_error_code: safeCode(errorCode),
    }));
  }

  async markCompleted(task: OneDriveExportTask, targetPath: string): Promise<void> {
    await this.updateStatus(task, (current) => {
      const completed: ExportStatusDocument = {
        ...current,
        status: "completed",
        attempts: current.attempts + 1,
        last_attempt_at: new Date().toISOString(),
        completed_at: new Date().toISOString(),
        target_path: targetPath,
      };
      delete completed.last_error_code;
      return completed;
    });
    await this.updateQueue(task.channel_key, (pending) =>
      pending.filter((item) => item.snapshot_id !== task.snapshot_id),
    );
  }

  async readStatus(channelKey: string, snapshotId: string): Promise<ExportStatusDocument | null> {
    return (await this.state.read<ExportStatusDocument>(statusId(channelKey, snapshotId)))?.document ?? null;
  }

  private async updateStatus(
    task: OneDriveExportTask,
    update: (current: ExportStatusDocument) => ExportStatusDocument,
  ): Promise<void> {
    for (let attempt = 0; attempt < 8; attempt += 1) {
      const current = await this.state.read<ExportStatusDocument>(statusId(task.channel_key, task.snapshot_id));
      const base: ExportStatusDocument = current?.document ?? {
        id: statusId(task.channel_key, task.snapshot_id),
        partitionKey: RUNTIME_PARTITION_KEY,
        schema_version: 1,
        kind: "onedrive_export_status",
        channel_key: task.channel_key,
        snapshot_id: task.snapshot_id,
        observed_at: task.observed_at,
        status: "pending",
        attempts: 0,
      };
      try {
        if (current) await this.state.replace(update(base), current.etag);
        else await this.state.create(update(base));
        return;
      } catch (error) {
        if (!(error instanceof RuntimeStateConflictError)) throw error;
      }
    }
    throw new Error("OneDrive export status is busy.");
  }

  private async updateQueue(
    channelKey: string,
    update: (pending: OneDriveExportTask[]) => OneDriveExportTask[],
  ): Promise<void> {
    for (let attempt = 0; attempt < 8; attempt += 1) {
      const current = await this.state.read<QueueDocument>(queueId(channelKey));
      const document: QueueDocument = {
        id: queueId(channelKey),
        partitionKey: RUNTIME_PARTITION_KEY,
        schema_version: 1,
        kind: "onedrive_export_queue",
        channel_key: channelKey,
        pending: update(current?.document.pending ?? []),
        updated_at: new Date().toISOString(),
      };
      try {
        if (current) await this.state.replace(document, current.etag);
        else await this.state.create(document);
        return;
      } catch (error) {
        if (!(error instanceof RuntimeStateConflictError)) throw error;
      }
    }
    throw new Error("OneDrive export queue is busy.");
  }
}

function queueId(channelKey: string): string {
  return `onedrive-export-queue:${channelKey}`;
}

function statusId(channelKey: string, snapshotId: string): string {
  return `onedrive-export-status:${channelKey}:${snapshotId}`;
}

function safeCode(value: string): string {
  return /^[a-z][a-z0-9_]{1,63}$/.test(value) ? value : "onedrive_export_failed";
}
