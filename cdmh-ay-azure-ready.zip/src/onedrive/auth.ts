import type { AppConfig } from "../config.js";
import { PublicError } from "../errors.js";
import type { OneDriveAccount, OneDriveTokenStore } from "./token-store.js";

export const ONEDRIVE_SCOPES = ["offline_access", "Files.ReadWrite"] as const;

type TokenResponse = {
  access_token?: string;
  refresh_token?: string;
  expires_in?: number;
};

export class OneDriveTokenProvider {
  private cached: { value: string; expiresAt: number } | undefined;
  private refreshing: Promise<string> | undefined;

  constructor(
    private readonly config: NonNullable<AppConfig["oneDriveExport"]>,
    private readonly store: OneDriveTokenStore,
    private readonly fetchImpl: typeof fetch = fetch,
  ) {}

  async getAccessToken(): Promise<string> {
    if (this.cached && this.cached.expiresAt - Date.now() > 60_000) return this.cached.value;
    if (!this.refreshing) {
      this.refreshing = this.refresh().finally(() => {
        this.refreshing = undefined;
      });
    }
    return this.refreshing;
  }

  private async refresh(): Promise<string> {
    for (let attempt = 0; attempt < 3; attempt += 1) {
      const current = await this.store.readRequired();
      const response = await this.fetchImpl(tokenEndpoint(this.config.tenantId), {
        method: "POST",
        headers: { "content-type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
          client_id: this.config.clientId,
          client_secret: this.config.clientSecret,
          refresh_token: current.refreshToken,
          grant_type: "refresh_token",
          scope: ONEDRIVE_SCOPES.join(" "),
        }),
        signal: AbortSignal.timeout(30_000),
      });
      if (!response.ok) throw authError();
      const token = await response.json() as TokenResponse;
      if (!token.access_token) throw authError();
      try {
        await this.store.rotate(current, token.refresh_token ?? current.refreshToken);
      } catch (error) {
        if (attempt < 2 && isConditionalConflict(error)) continue;
        throw error;
      }
      const expiresIn = Number.isFinite(token.expires_in) ? Number(token.expires_in) : 3600;
      this.cached = { value: token.access_token, expiresAt: Date.now() + Math.max(300, expiresIn) * 1000 };
      return token.access_token;
    }
    throw authError();
  }
}

export async function exchangeAuthorizationCode(
  config: NonNullable<AppConfig["oneDriveExport"]>,
  code: string,
  codeVerifier: string,
  fetchImpl: typeof fetch = fetch,
): Promise<{ accessToken: string; refreshToken: string }> {
  const response = await fetchImpl(tokenEndpoint(config.tenantId), {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      client_id: config.clientId,
      client_secret: config.clientSecret,
      code,
      code_verifier: codeVerifier,
      redirect_uri: config.redirectUri,
      grant_type: "authorization_code",
      scope: ONEDRIVE_SCOPES.join(" "),
    }),
    signal: AbortSignal.timeout(30_000),
  });
  if (!response.ok) throw authError();
  const token = await response.json() as TokenResponse;
  if (!token.access_token || !token.refresh_token) throw authError();
  return { accessToken: token.access_token, refreshToken: token.refresh_token };
}

export function buildAuthorizationUrl(
  config: NonNullable<AppConfig["oneDriveExport"]>,
  state: string,
  codeChallenge: string,
): string {
  const url = new URL(`https://login.microsoftonline.com/${encodeURIComponent(config.tenantId)}/oauth2/v2.0/authorize`);
  url.search = new URLSearchParams({
    client_id: config.clientId,
    response_type: "code",
    redirect_uri: config.redirectUri,
    response_mode: "query",
    scope: ONEDRIVE_SCOPES.join(" "),
    state,
    code_challenge: codeChallenge,
    code_challenge_method: "S256",
    prompt: "select_account",
  }).toString();
  return url.toString();
}

export async function readAuthorizedAccount(
  accessToken: string,
  fetchImpl: typeof fetch = fetch,
): Promise<OneDriveAccount> {
  const response = await fetchImpl(
    "https://graph.microsoft.com/v1.0/me?$select=id,displayName,userPrincipalName",
    { headers: { authorization: `Bearer ${accessToken}` }, signal: AbortSignal.timeout(30_000) },
  );
  if (!response.ok) throw authError();
  const value = await response.json() as { id?: string; displayName?: string; userPrincipalName?: string };
  if (!value.id) throw authError();
  return {
    id: value.id,
    display_name: value.displayName ?? null,
    user_principal_name: value.userPrincipalName ?? null,
  };
}

function tokenEndpoint(tenantId: string): string {
  return `https://login.microsoftonline.com/${encodeURIComponent(tenantId)}/oauth2/v2.0/token`;
}

function authError(): PublicError {
  return new PublicError("onedrive_auth_failed", "OneDrive authorization is unavailable.", 502);
}

function isConditionalConflict(error: unknown): boolean {
  return Boolean(error && typeof error === "object" && "statusCode" in error && (error as { statusCode?: number }).statusCode === 412);
}
