import type { CollectionResult } from "../archive/collector.js";
import type { SnapshotStore } from "../archive/snapshot-store.js";
import { PublicError } from "../errors.js";
import type { OneDriveExportQueue, OneDriveExportTask } from "./export-queue.js";
import type { OneDriveSnapshotExporter } from "./exporter.js";

export type ExportPostStepResult = {
  status: "completed" | "pending";
  files?: number;
  alreadyExported?: boolean;
  pendingCount: number;
};

export async function runOneDriveExportPostStep(
  channelKey: string,
  collection: CollectionResult,
  store: SnapshotStore,
  services: { queue: OneDriveExportQueue; exporter: OneDriveSnapshotExporter },
): Promise<ExportPostStepResult> {
  const task: OneDriveExportTask = {
    channel_key: channelKey,
    snapshot_id: collection.snapshotId,
    observed_at: collection.observedAt,
    snapshot_path: collection.snapshotPath,
    reach_reports: collection.reachReports,
  };
  try {
    await services.queue.register(task);
  } catch {
    return { status: "pending", pendingCount: 1 };
  }

  let currentResult: ExportPostStepResult = { status: "pending", pendingCount: 1 };
  const pending = await services.queue.listPending(channelKey).catch(() => [task]);
  for (const item of pending) {
    try {
      const exported = await services.exporter.export(item, store);
      await services.queue.markCompleted(item, exported.targetPath);
      if (item.snapshot_id === task.snapshot_id) {
        currentResult = {
          status: "completed",
          files: exported.files,
          alreadyExported: exported.alreadyExported,
          pendingCount: 0,
        };
      }
    } catch (error) {
      await services.queue.markPending(item, errorCode(error)).catch(() => undefined);
    }
  }
  const remaining = await services.queue.listPending(channelKey).catch(() => [task]);
  return { ...currentResult, pendingCount: remaining.length };
}

function errorCode(error: unknown): string {
  if (error instanceof PublicError) return error.code;
  return "onedrive_export_failed";
}
