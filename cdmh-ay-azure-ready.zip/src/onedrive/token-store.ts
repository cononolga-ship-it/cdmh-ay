import {
  RUNTIME_PARTITION_KEY,
  RuntimeStateConflictError,
  type RuntimeDocument,
  type RuntimeStateStore,
  type VersionedDocument,
} from "../azure/runtime-state.js";
import { PublicError } from "../errors.js";
import { TokenCipher, type EncryptedTokenEnvelope } from "../security/token-crypto.js";

const TOKEN_DOCUMENT_ID = "onedrive-export-refresh-token-v1";

export type OneDriveAccount = {
  id: string;
  display_name: string | null;
  user_principal_name: string | null;
};

type TokenDocument = RuntimeDocument & {
  schema_version: 1;
  kind: "onedrive_export_token";
  encrypted_refresh_token: EncryptedTokenEnvelope;
  account: OneDriveAccount;
  updated_at: string;
};

export type StoredOneDriveToken = {
  refreshToken: string;
  account: OneDriveAccount;
  version: VersionedDocument<TokenDocument>;
};

export class OneDriveTokenStore {
  private readonly cipher: TokenCipher;

  constructor(
    private readonly state: RuntimeStateStore,
    encryptionKey: Uint8Array,
  ) {
    this.cipher = new TokenCipher(encryptionKey, "onedrive-export-refresh-token");
  }

  async readRequired(): Promise<StoredOneDriveToken> {
    const current = await this.state.read<TokenDocument>(TOKEN_DOCUMENT_ID);
    if (!current) {
      throw new PublicError(
        "onedrive_consent_required",
        "OneDrive export requires one-time Microsoft authorization.",
        503,
      );
    }
    return {
      refreshToken: this.cipher.decrypt(current.document.encrypted_refresh_token),
      account: current.document.account,
      version: current,
    };
  }

  async saveAuthorizedToken(refreshToken: string, account: OneDriveAccount): Promise<void> {
    for (let attempt = 0; attempt < 8; attempt += 1) {
      const current = await this.state.read<TokenDocument>(TOKEN_DOCUMENT_ID);
      const document: TokenDocument = {
        id: TOKEN_DOCUMENT_ID,
        partitionKey: RUNTIME_PARTITION_KEY,
        schema_version: 1,
        kind: "onedrive_export_token",
        encrypted_refresh_token: this.cipher.encrypt(refreshToken),
        account,
        updated_at: new Date().toISOString(),
      };
      try {
        if (current) await this.state.replace(document, current.etag);
        else await this.state.create(document);
        return;
      } catch (error) {
        if (!(error instanceof RuntimeStateConflictError)) throw error;
      }
    }
    throw new PublicError("onedrive_token_busy", "OneDrive authorization state is temporarily busy.", 503);
  }

  async rotate(current: StoredOneDriveToken, refreshToken: string): Promise<void> {
    const document: TokenDocument = {
      ...current.version.document,
      encrypted_refresh_token: this.cipher.encrypt(refreshToken),
      updated_at: new Date().toISOString(),
    };
    await this.state.replace(document, current.version.etag);
  }
}
