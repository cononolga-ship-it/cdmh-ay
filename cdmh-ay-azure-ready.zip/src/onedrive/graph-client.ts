import { PublicError } from "../errors.js";

const GRAPH_BASE = "https://graph.microsoft.com/v1.0";

export type OneDriveItem = {
  id: string;
  name: string;
  size?: number;
  folder?: { childCount?: number };
  file?: Record<string, unknown>;
};

export class OneDriveGraphClient {
  private readonly folderCache = new Map<string, OneDriveItem>();

  constructor(
    private readonly tokens: { getAccessToken(): Promise<string> },
    private readonly fetchImpl: typeof fetch = fetch,
  ) {}

  async ensureFolderPath(path: string): Promise<OneDriveItem> {
    const segments = splitPath(path);
    let parent = await this.root();
    let current = "";
    for (const segment of segments) {
      current = current ? `${current}/${segment}` : segment;
      const cached = this.folderCache.get(current);
      if (cached) {
        parent = cached;
        continue;
      }
      let child = await this.itemByPath(current);
      if (child && !child.folder) throw graphError("onedrive_path_conflict");
      if (!child) {
        const response = await this.request(`/me/drive/items/${encodeURIComponent(parent.id)}/children`, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({
            name: segment,
            folder: {},
            "@microsoft.graph.conflictBehavior": "fail",
          }),
        }, true);
        child = response?.ok ? await response.json() as OneDriveItem : await this.itemByPath(current);
      }
      if (!child?.folder) throw graphError("onedrive_folder_failed");
      this.folderCache.set(current, child);
      parent = child;
    }
    return parent;
  }

  async putFile(path: string, content: string | Uint8Array, contentType: string): Promise<OneDriveItem> {
    const { parentPath } = splitFilePath(path);
    await this.ensureFolderPath(parentPath);
    const query = new URLSearchParams({ "@microsoft.graph.conflictBehavior": "replace" });
    const response = await this.request(
      `/me/drive/root:/${encodeGraphPath(path)}:/content?${query.toString()}`,
      {
        method: "PUT",
        headers: { "content-type": contentType },
        body: typeof content === "string" ? content : Buffer.from(content),
      },
    );
    if (!response) throw graphError();
    return await response.json() as OneDriveItem;
  }

  async readFile(path: string): Promise<Uint8Array | null> {
    const response = await this.request(
      `/me/drive/root:/${encodeGraphPath(path)}:/content`,
      {},
      false,
      true,
    );
    if (!response) return null;
    return new Uint8Array(await response.arrayBuffer());
  }

  async listFolder(path: string): Promise<OneDriveItem[]> {
    const folder = await this.itemByPath(path);
    if (!folder?.folder) return [];
    const response = await this.request(
      `/me/drive/items/${encodeURIComponent(folder.id)}/children?$select=id,name,size,file,folder&$top=200`,
      {},
    );
    if (!response) throw graphError();
    const body = await response.json() as { value?: OneDriveItem[] };
    return body.value ?? [];
  }

  private async root(): Promise<OneDriveItem> {
    const response = await this.request("/me/drive/root?$select=id,name,folder", {});
    if (!response) throw graphError();
    const root = await response.json() as OneDriveItem;
    if (!root.folder) throw graphError();
    return root;
  }

  private async itemByPath(path: string): Promise<OneDriveItem | null> {
    const response = await this.request(
      `/me/drive/root:/${encodeGraphPath(path)}?$select=id,name,size,file,folder`,
      {},
      false,
      true,
    );
    return response ? await response.json() as OneDriveItem : null;
  }

  private async request(
    path: string,
    init: RequestInit,
    expectedConflict = false,
    expectedNotFound = false,
  ): Promise<Response | null> {
    const token = await this.tokens.getAccessToken();
    let response: Response;
    try {
      response = await this.fetchImpl(`${GRAPH_BASE}${path}`, {
        ...init,
        headers: { ...Object.fromEntries(new Headers(init.headers).entries()), authorization: `Bearer ${token}` },
        signal: AbortSignal.timeout(60_000),
      });
    } catch {
      throw graphError("onedrive_unavailable");
    }
    if (expectedNotFound && response.status === 404) return null;
    if (expectedConflict && response.status === 409) return null;
    if (!response.ok) throw graphError();
    return response;
  }
}

function splitPath(path: string): string[] {
  if (!path || path.startsWith("/") || path.endsWith("/")) throw graphError("onedrive_path_invalid");
  const segments = path.split("/");
  for (const segment of segments) validateSegment(segment);
  return segments;
}

function splitFilePath(path: string): { parentPath: string; name: string } {
  const segments = splitPath(path);
  const name = segments.pop();
  if (!name || !segments.length) throw graphError("onedrive_path_invalid");
  return { parentPath: segments.join("/"), name };
}

function validateSegment(value: string): void {
  if (!value || value === "." || value === ".." || /[\\:*?"<>|]/.test(value)) {
    throw graphError("onedrive_path_invalid");
  }
}

function encodeGraphPath(path: string): string {
  return splitPath(path).map(encodeURIComponent).join("/");
}

function graphError(code = "onedrive_graph_failed"): PublicError {
  return new PublicError(code, "OneDrive export is temporarily unavailable.", 502);
}
