import { createHash } from "node:crypto";
import type { SnapshotStore } from "../archive/snapshot-store.js";
import { PublicError } from "../errors.js";
import type { OneDriveExportTask } from "./export-queue.js";
import type { OneDriveGraphClient } from "./graph-client.js";

type ExportFile = {
  relative_path: string;
  content_type: string;
  bytes: number;
  sha256: string;
  content: Uint8Array;
};

export type OneDriveExportManifest = {
  schema_version: 1;
  snapshot_id: string;
  observed_at: string;
  channel: string;
  files: Array<Omit<ExportFile, "content">>;
};

export type OneDriveExportResult = {
  targetPath: string;
  files: number;
  alreadyExported: boolean;
};

export class OneDriveSnapshotExporter {
  constructor(
    private readonly graph: OneDriveGraphClient,
    private readonly rootPath: string,
  ) {}

  async export(task: OneDriveExportTask, store: SnapshotStore): Promise<OneDriveExportResult> {
    const targetPath = this.targetPath(task);
    const existingManifest = await this.readManifest(`${targetPath}/manifest.json`);
    if (existingManifest && await this.verifyManifest(targetPath, task, existingManifest)) {
      return { targetPath, files: existingManifest.files.length + 1, alreadyExported: true };
    }

    const files = await this.buildFiles(task, store);
    await this.graph.ensureFolderPath(targetPath);
    for (const file of files) {
      await this.graph.putFile(`${targetPath}/${file.relative_path}`, file.content, file.content_type);
    }
    const manifest: OneDriveExportManifest = {
      schema_version: 1,
      snapshot_id: task.snapshot_id,
      observed_at: task.observed_at,
      channel: task.channel_key,
      files: files.map(({ content: _content, ...file }) => file),
    };
    const serialized = `${JSON.stringify(manifest, null, 2)}\n`;
    await this.graph.putFile(`${targetPath}/manifest.json`, serialized, "application/json; charset=utf-8");
    if (!await this.verifyManifest(targetPath, task, manifest)) {
      throw new PublicError("onedrive_verification_failed", "OneDrive export verification failed.", 502);
    }
    return { targetPath, files: files.length + 1, alreadyExported: false };
  }

  private async buildFiles(task: OneDriveExportTask, store: SnapshotStore): Promise<ExportFile[]> {
    const snapshot = await store.exportSnapshot({ snapshotId: task.snapshot_id });
    if (!snapshot || snapshot.path !== task.snapshot_path || snapshot.snapshot.observed_at !== task.observed_at) {
      throw new PublicError("snapshot_not_found", "The queued snapshot is unavailable.", 404);
    }
    const snapshotText = await store.readArchivedText(task.snapshot_path);
    if (snapshotText === null) throw new PublicError("snapshot_not_found", "The queued snapshot is unavailable.", 404);
    const files = [file("snapshot.json", "application/json; charset=utf-8", snapshotText)];
    for (const report of task.reach_reports) {
      const [csv, metadata] = await Promise.all([
        store.readArchivedText(report.csv_path),
        store.readArchivedText(report.metadata_path),
      ]);
      if (csv === null || metadata === null) {
        throw new PublicError("reach_archive_incomplete", "A queued Reach report is incomplete.", 502);
      }
      const name = safeName(report.report_id);
      files.push(file(`reach/${name}.csv`, "text/csv; charset=utf-8", csv));
      files.push(file(`reach/${name}.metadata.json`, "application/json; charset=utf-8", metadata));
    }
    return files;
  }

  private targetPath(task: OneDriveExportTask): string {
    const date = task.observed_at.slice(0, 10);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) throw new PublicError("snapshot_invalid", "Snapshot timestamp is invalid.", 500);
    return `${this.rootPath}/${task.channel_key}/${date}/${task.snapshot_id}`;
  }

  private async readManifest(path: string): Promise<OneDriveExportManifest | null> {
    const content = await this.graph.readFile(path);
    if (!content) return null;
    try {
      return JSON.parse(Buffer.from(content).toString("utf8")) as OneDriveExportManifest;
    } catch {
      return null;
    }
  }

  private async verifyManifest(
    targetPath: string,
    task: OneDriveExportTask,
    manifest: OneDriveExportManifest,
  ): Promise<boolean> {
    if (
      manifest.schema_version !== 1 || manifest.snapshot_id !== task.snapshot_id ||
      manifest.observed_at !== task.observed_at || manifest.channel !== task.channel_key ||
      !Array.isArray(manifest.files)
    ) return false;
    for (const expected of manifest.files) {
      if (!safeRelativePath(expected.relative_path)) return false;
      const content = await this.graph.readFile(`${targetPath}/${expected.relative_path}`);
      if (!content || content.byteLength !== expected.bytes || sha256(content) !== expected.sha256) return false;
    }
    return true;
  }
}

function file(relativePath: string, contentType: string, value: string | Uint8Array): ExportFile {
  const content = typeof value === "string" ? new TextEncoder().encode(value) : value;
  return {
    relative_path: relativePath,
    content_type: contentType,
    bytes: content.byteLength,
    sha256: sha256(content),
    content,
  };
}

function sha256(content: Uint8Array): string {
  return createHash("sha256").update(content).digest("hex");
}

function safeName(value: string): string {
  const result = value.replace(/[^A-Za-z0-9._-]/g, "_");
  if (!result || result === "." || result === "..") throw new PublicError("report_id_invalid", "Reach report ID is invalid.", 500);
  return result;
}

function safeRelativePath(value: string): boolean {
  return Boolean(value && !value.startsWith("/") && !value.includes("..") && !/[\\:*?"<>|]/.test(value));
}
