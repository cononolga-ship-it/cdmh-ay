import { randomUUID } from "node:crypto";
import {
  RUNTIME_PARTITION_KEY,
  RuntimeStateConflictError,
  type RuntimeDocument,
  type RuntimeStateStore,
  type VersionedDocument,
} from "./runtime-state.js";

export const COLLECTOR_LEASE_DOCUMENT_ID = "collector-execution-lease";

export type LeaseDocument = RuntimeDocument & {
  schema_version: 1;
  owner_id: string;
  acquired_at: string;
  expires_at: string;
};

export type AcquiredLease = VersionedDocument<LeaseDocument>;

export class CollectorDistributedLease {
  constructor(
    private readonly store: RuntimeStateStore,
    private readonly ownerId: string = randomUUID(),
    private readonly leaseMs = 65 * 60_000,
    private readonly now: () => number = Date.now,
  ) {}

  async acquire(): Promise<AcquiredLease | null> {
    const timestamp = this.now();
    const document: LeaseDocument = {
      id: COLLECTOR_LEASE_DOCUMENT_ID,
      partitionKey: RUNTIME_PARTITION_KEY,
      schema_version: 1,
      owner_id: this.ownerId,
      acquired_at: new Date(timestamp).toISOString(),
      expires_at: new Date(timestamp + this.leaseMs).toISOString(),
    };
    const current = await this.store.read<LeaseDocument>(COLLECTOR_LEASE_DOCUMENT_ID);
    if (!current) {
      try {
        return await this.store.create(document);
      } catch (error) {
        if (error instanceof RuntimeStateConflictError && error.statusCode === 409) return null;
        throw error;
      }
    }
    if (Date.parse(current.document.expires_at) > timestamp) return null;
    try {
      return await this.store.replace(document, current.etag);
    } catch (error) {
      if (error instanceof RuntimeStateConflictError && error.statusCode === 412) return null;
      throw error;
    }
  }

  async release(lease: AcquiredLease): Promise<void> {
    if (lease.document.owner_id !== this.ownerId) return;
    const expired: LeaseDocument = { ...lease.document, expires_at: new Date(this.now() - 1).toISOString() };
    await this.store.replace(expired, lease.etag).catch(() => undefined);
  }

  async runExclusive<T>(operation: () => Promise<T>): Promise<{ executed: true; result: T } | { executed: false }> {
    const lease = await this.acquire();
    if (!lease) return { executed: false };
    try {
      return { executed: true, result: await operation() };
    } finally {
      await this.release(lease);
    }
  }
}
