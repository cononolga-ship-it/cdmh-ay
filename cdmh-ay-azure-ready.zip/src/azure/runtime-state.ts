import { CosmosClient, type Container, type ItemDefinition } from "@azure/cosmos";
import { ManagedIdentityCredential } from "@azure/identity";
import type { AppConfig } from "../config.js";

export const RUNTIME_PARTITION_KEY = "runtime";

export type RuntimeDocument = ItemDefinition & {
  id: string;
  partitionKey: typeof RUNTIME_PARTITION_KEY;
};

export type VersionedDocument<T extends RuntimeDocument> = {
  document: T;
  etag: string;
};

export class RuntimeStateConflictError extends Error {
  constructor(public readonly statusCode: 409 | 412) {
    super(`Cosmos conditional write failed (${statusCode}).`);
    this.name = "RuntimeStateConflictError";
  }
}

export interface RuntimeStateStore {
  read<T extends RuntimeDocument>(id: string): Promise<VersionedDocument<T> | null>;
  create<T extends RuntimeDocument>(document: T): Promise<VersionedDocument<T>>;
  replace<T extends RuntimeDocument>(document: T, etag: string): Promise<VersionedDocument<T>>;
}

export class CosmosRuntimeStateStore implements RuntimeStateStore {
  constructor(private readonly container: Container) {}

  async read<T extends RuntimeDocument>(id: string): Promise<VersionedDocument<T> | null> {
    try {
      const response = await this.container.item(id, RUNTIME_PARTITION_KEY).read<T>();
      if (!response.resource || !response.etag) return null;
      return { document: response.resource, etag: response.etag };
    } catch (error) {
      if (statusCode(error) === 404) return null;
      throw error;
    }
  }

  async create<T extends RuntimeDocument>(document: T): Promise<VersionedDocument<T>> {
    try {
      const response = await this.container.items.create<T>(document, {
        disableAutomaticIdGeneration: true,
      });
      if (!response.resource || !response.etag) throw new Error("Cosmos create returned no resource.");
      return { document: response.resource, etag: response.etag };
    } catch (error) {
      if (statusCode(error) === 409) throw new RuntimeStateConflictError(409);
      throw error;
    }
  }

  async replace<T extends RuntimeDocument>(document: T, etag: string): Promise<VersionedDocument<T>> {
    try {
      const response = await this.container.item(document.id, RUNTIME_PARTITION_KEY).replace<T>(
        document,
        { accessCondition: { type: "IfMatch", condition: etag } },
      );
      if (!response.resource || !response.etag) throw new Error("Cosmos replace returned no resource.");
      return { document: response.resource, etag: response.etag };
    } catch (error) {
      if (statusCode(error) === 412) throw new RuntimeStateConflictError(412);
      throw error;
    }
  }
}

export function createRuntimeStateStore(config: AppConfig): RuntimeStateStore {
  const credential = new ManagedIdentityCredential({ clientId: config.azureClientId });
  const client = new CosmosClient({
    endpoint: config.azureCosmosEndpoint,
    aadCredentials: credential,
  });
  return new CosmosRuntimeStateStore(
    client.database(config.azureCosmosDatabaseName).container(config.azureCosmosContainerName),
  );
}

function statusCode(error: unknown): number | undefined {
  if (!error || typeof error !== "object") return undefined;
  const value = (error as { code?: unknown; statusCode?: unknown }).code ??
    (error as { statusCode?: unknown }).statusCode;
  return typeof value === "number" ? value : Number(value);
}
