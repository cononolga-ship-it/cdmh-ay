import { PublicError } from "../errors.js";

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

export type DateRange = { startDate: string; endDate: string };

function parseDate(value: string): Date {
  if (!DATE_RE.test(value)) throw new PublicError("invalid_date", "Dates must use YYYY-MM-DD.");
  const date = new Date(`${value}T00:00:00.000Z`);
  if (Number.isNaN(date.valueOf()) || date.toISOString().slice(0, 10) !== value) {
    throw new PublicError("invalid_date", "The supplied date is not valid.");
  }
  return date;
}

export function validateDateRange(startDate: string, endDate: string, maxDays = 366): DateRange {
  const start = parseDate(startDate);
  const end = parseDate(endDate);
  const days = Math.floor((end.valueOf() - start.valueOf()) / 86_400_000) + 1;
  if (days < 1) throw new PublicError("invalid_date_range", "start_date must not be after end_date.");
  if (days > maxDays) {
    throw new PublicError("date_range_too_large", `The date range may contain at most ${maxDays} days.`);
  }
  return { startDate, endDate };
}

export function addUtcDays(value: string, days: number): string {
  const date = parseDate(value);
  date.setUTCDate(date.getUTCDate() + days);
  return date.toISOString().slice(0, 10);
}

export function lastCompleteYoutubeDays(days: number): DateRange {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "America/Los_Angeles",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(new Date());
  const value = Object.fromEntries(parts.map((part) => [part.type, part.value]));
  const today = `${value.year}-${value.month}-${value.day}`;
  const endDate = addUtcDays(today, -1);
  return { startDate: addUtcDays(endDate, -(days - 1)), endDate };
}
