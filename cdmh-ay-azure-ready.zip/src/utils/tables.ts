export type AnalyticsTable = {
  columnHeaders?: Array<{ name?: string | null }> | null;
  rows?: unknown[][] | null;
};

export function rowsToObjects(table: AnalyticsTable): Array<Record<string, unknown>> {
  const names = (table.columnHeaders ?? []).map((header) => header.name ?? "unknown");
  return (table.rows ?? []).map((row) =>
    Object.fromEntries(names.map((name, index) => [name, row[index] ?? null])),
  );
}
