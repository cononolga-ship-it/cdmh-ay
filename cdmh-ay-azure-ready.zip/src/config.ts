import { z } from "zod";

const ChannelSchema = z.object({
  key: z.string().regex(/^[a-z][a-z0-9_-]{1,31}$/),
  name: z.string().min(1).max(100),
  youtubeChannelId: z.string().regex(/^UC[A-Za-z0-9_-]{22}$/),
  archiveRoot: z.string().min(1).refine((value) => !value.startsWith("/") && !value.endsWith("/")),
  ownerGoogleEmail: z.string().email().transform((value) => value.toLowerCase()).optional(),
  reachJobId: z.string().min(1).optional(),
});

const EnvSchema = z.object({
  NODE_ENV: z.enum(["development", "test", "production"]).default("development"),
  PORT: optionalNumber(z.number().int().min(1).max(65535), 3000),
  PUBLIC_BASE_URL: z.string().url(),
  YOUTUBE_CHANNEL_ID: z.string().regex(/^UC[A-Za-z0-9_-]{22}$/),
  YOUTUBE_CHANNELS_JSON: optionalString(),
  DEFAULT_CHANNEL_KEY: z.string().regex(/^[a-z][a-z0-9_-]{1,31}$/).default("conon_d"),
  OWNER_GOOGLE_EMAIL: z.string().email(),
  GOOGLE_CLIENT_ID: z.string().min(1),
  GOOGLE_CLIENT_SECRET: z.string().min(1),
  GOOGLE_REFRESH_TOKEN: z.string().min(1),
  MICROSOFT_CLIENT_ID: z.string().min(1),
  MICROSOFT_CLIENT_SECRET: z.string().min(1),
  MICROSOFT_REFRESH_TOKEN: optionalString(),
  MICROSOFT_TENANT_ID: z.string().min(1),
  MICROSOFT_TOKEN_ENCRYPTION_KEY: z.string().min(1),
  AZURE_COSMOS_ENDPOINT: z.string().url().refine((value) => value.startsWith("https://")),
  AZURE_COSMOS_DATABASE_NAME: z.string().min(1),
  AZURE_COSMOS_CONTAINER_NAME: z.string().min(1),
  AZURE_CLIENT_ID: z.string().uuid(),
  MCP_TOKEN_SIGNING_SECRET: z.string().min(32),
  YT_REACH_JOB_ID: optionalString(),
  MCP_ACCESS_TOKEN_TTL_SECONDS: optionalNumber(z.number().int().min(300).max(3600), 900),
  MCP_REFRESH_TOKEN_TTL_SECONDS: optionalNumber(z.number().int().min(86400).max(31536000), 15_552_000),
  COLLECTION_LOOKBACK_DAYS: optionalNumber(z.number().int().min(1).max(90), 30),
  COLLECTOR_CONCURRENCY: optionalNumber(z.number().int().min(1).max(10), 4),
  COLLECT_CHANNEL: optionalString(),
});

function optionalNumber(schema: z.ZodNumber, defaultValue: number) {
  return z.preprocess(
    (value) => value === "" || value === undefined ? undefined : Number(value),
    schema.default(defaultValue),
  );
}

function optionalString() {
  return z.preprocess(
    (value) => value === "" || value === undefined ? undefined : value,
    z.string().min(1).optional(),
  );
}

export type ChannelConfig = z.infer<typeof ChannelSchema>;

export type AppConfig = {
  nodeEnv: "development" | "test" | "production";
  port: number;
  publicBaseUrl: string;
  mcpResourceUrl: string;
  googleRedirectUri: string;
  microsoftRedirectUri: string;
  channels: ChannelConfig[];
  defaultChannelKey: string;
  ownerGoogleEmail: string;
  googleClientId: string;
  googleClientSecret: string;
  googleBootstrapRefreshToken: string;
  microsoftClientId: string;
  microsoftClientSecret: string;
  microsoftBootstrapRefreshToken?: string;
  microsoftTenantId: string;
  microsoftTokenEncryptionKey: Uint8Array;
  azureCosmosEndpoint: string;
  azureCosmosDatabaseName: string;
  azureCosmosContainerName: string;
  azureClientId: string;
  signingSecret: Uint8Array;
  accessTokenTtlSeconds: number;
  refreshTokenTtlSeconds: number;
  collectionLookbackDays: number;
  collectorConcurrency: number;
  collectChannel?: string;
};

export function loadConfig(env: NodeJS.ProcessEnv = process.env): AppConfig {
  const parsed = EnvSchema.safeParse(env);
  if (!parsed.success) {
    const names = parsed.error.issues.map((issue) => issue.path.join(".")).join(", ");
    throw new Error(`Invalid or missing environment variables: ${names}`);
  }

  const values = parsed.data;
  const publicBaseUrl = values.PUBLIC_BASE_URL.replace(/\/$/, "");
  const channels = parseChannels(values);
  if (!channels.some((channel) => channel.key === values.DEFAULT_CHANNEL_KEY)) {
    throw new Error("Invalid or missing environment variables: DEFAULT_CHANNEL_KEY");
  }
  if (values.COLLECT_CHANNEL && !channels.some((channel) => channel.key === values.COLLECT_CHANNEL)) {
    throw new Error("Invalid or missing environment variables: COLLECT_CHANNEL");
  }

  return {
    nodeEnv: values.NODE_ENV,
    port: values.PORT,
    publicBaseUrl,
    mcpResourceUrl: `${publicBaseUrl}/mcp`,
    googleRedirectUri: `${publicBaseUrl}/oauth/google/callback`,
    microsoftRedirectUri: `${publicBaseUrl}/oauth/microsoft/callback`,
    channels,
    defaultChannelKey: values.DEFAULT_CHANNEL_KEY,
    ownerGoogleEmail: values.OWNER_GOOGLE_EMAIL.toLowerCase(),
    googleClientId: values.GOOGLE_CLIENT_ID,
    googleClientSecret: values.GOOGLE_CLIENT_SECRET,
    googleBootstrapRefreshToken: values.GOOGLE_REFRESH_TOKEN,
    microsoftClientId: values.MICROSOFT_CLIENT_ID,
    microsoftClientSecret: values.MICROSOFT_CLIENT_SECRET,
    microsoftTenantId: values.MICROSOFT_TENANT_ID,
    microsoftTokenEncryptionKey: decodeEncryptionKey(values.MICROSOFT_TOKEN_ENCRYPTION_KEY),
    azureCosmosEndpoint: values.AZURE_COSMOS_ENDPOINT,
    azureCosmosDatabaseName: values.AZURE_COSMOS_DATABASE_NAME,
    azureCosmosContainerName: values.AZURE_COSMOS_CONTAINER_NAME,
    azureClientId: values.AZURE_CLIENT_ID,
    ...(values.MICROSOFT_REFRESH_TOKEN ? { microsoftBootstrapRefreshToken: values.MICROSOFT_REFRESH_TOKEN } : {}),
    signingSecret: new TextEncoder().encode(values.MCP_TOKEN_SIGNING_SECRET),
    accessTokenTtlSeconds: values.MCP_ACCESS_TOKEN_TTL_SECONDS,
    refreshTokenTtlSeconds: values.MCP_REFRESH_TOKEN_TTL_SECONDS,
    collectionLookbackDays: values.COLLECTION_LOOKBACK_DAYS,
    collectorConcurrency: values.COLLECTOR_CONCURRENCY,
    ...(values.COLLECT_CHANNEL ? { collectChannel: values.COLLECT_CHANNEL } : {}),
  };
}

export function loadCollectorConfig(env: NodeJS.ProcessEnv = process.env): AppConfig {
  return loadConfig({
    ...env,
    PUBLIC_BASE_URL: env.PUBLIC_BASE_URL || "https://collector.invalid",
    OWNER_GOOGLE_EMAIL: env.OWNER_GOOGLE_EMAIL || "collector@invalid.example",
    MCP_TOKEN_SIGNING_SECRET: env.MCP_TOKEN_SIGNING_SECRET || "collector-unused-signing-secret-00000000",
  });
}

function parseChannels(values: z.infer<typeof EnvSchema>): ChannelConfig[] {
  if (!values.YOUTUBE_CHANNELS_JSON) {
    return [{
      key: values.DEFAULT_CHANNEL_KEY,
      name: "Conon & D Media House",
      youtubeChannelId: values.YOUTUBE_CHANNEL_ID,
      archiveRoot: "0_0COD/01_0 CDMH AY",
      ...(values.YT_REACH_JOB_ID ? { reachJobId: values.YT_REACH_JOB_ID } : {}),
    }];
  }
  let input: unknown;
  try {
    input = JSON.parse(values.YOUTUBE_CHANNELS_JSON);
  } catch {
    throw new Error("Invalid or missing environment variables: YOUTUBE_CHANNELS_JSON");
  }
  const parsed = z.array(ChannelSchema).min(1).max(20).safeParse(input);
  if (!parsed.success) throw new Error("Invalid or missing environment variables: YOUTUBE_CHANNELS_JSON");
  const keys = new Set(parsed.data.map((channel) => channel.key));
  const ids = new Set(parsed.data.map((channel) => channel.youtubeChannelId));
  const roots = new Set(parsed.data.map((channel) => channel.archiveRoot));
  if (keys.size !== parsed.data.length || ids.size !== parsed.data.length || roots.size !== parsed.data.length) {
    throw new Error("Invalid or missing environment variables: YOUTUBE_CHANNELS_JSON");
  }
  return parsed.data;
}

function decodeEncryptionKey(value: string): Uint8Array {
  const key = Buffer.from(value, "base64");
  if (key.byteLength !== 32) {
    throw new Error("Invalid or missing environment variables: MICROSOFT_TOKEN_ENCRYPTION_KEY");
  }
  return new Uint8Array(key);
}
