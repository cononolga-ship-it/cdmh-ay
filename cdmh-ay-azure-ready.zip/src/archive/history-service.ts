import { PublicError } from "../errors.js";
import type { SnapshotStore } from "./snapshot-store.js";
import { metricHistory, metricRevisions, snapshotDiff } from "./revisions.js";

export class ArchiveHistoryService {
  constructor(private readonly store: SnapshotStore) {}

  async metricHistory(videoId: string, metric: string, startDate: string, endDate: string) {
    const snapshots = await this.store.listSnapshots();
    return {
      videoId,
      metric,
      requestedPeriod: { startDate, endDate },
      observations: metricHistory(snapshots, videoId, metric, startDate, endDate),
    };
  }

  async metricRevisions(videoId: string, startDate: string, endDate: string) {
    const snapshots = await this.store.listSnapshots();
    return {
      videoId,
      requestedPeriod: { startDate, endDate },
      revisions: metricRevisions(snapshots, videoId, startDate, endDate),
    };
  }

  async snapshotDiff(videoId: string, observedAtA: string, observedAtB: string) {
    const [snapshotA, snapshotB] = await Promise.all([
      this.store.findSnapshot(observedAtA),
      this.store.findSnapshot(observedAtB),
    ]);
    if (!snapshotA || !snapshotB) {
      throw new PublicError("snapshot_not_found", "One or both requested snapshots were not found.", 404);
    }
    return {
      videoId,
      observedAtA,
      observedAtB,
      changes: snapshotDiff(snapshotA, snapshotB, videoId),
    };
  }
}
