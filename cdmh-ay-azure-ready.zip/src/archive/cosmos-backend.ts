import { createHash } from "node:crypto";
import { gzipSync, gunzipSync } from "node:zlib";
import {
  RUNTIME_PARTITION_KEY,
  RuntimeStateConflictError,
  type RuntimeDocument,
  type RuntimeStateStore,
} from "../azure/runtime-state.js";
import type { ArchiveBackend, StoredFile } from "./snapshot-store.js";

const CHUNK_BYTES = 512 * 1024;

type ArchiveFileDocument = RuntimeDocument & {
  schema_version: 1;
  kind: "archive_file";
  channel_key: string;
  path: string;
  content_type: string;
  encoding: "gzip-base64";
  chunks: number;
  original_bytes: number;
  compressed_bytes: number;
  updated_at: string;
};

type ArchiveChunkDocument = RuntimeDocument & {
  schema_version: 1;
  kind: "archive_chunk";
  channel_key: string;
  file_id: string;
  index: number;
  data: string;
};

type ArchiveManifestDocument = RuntimeDocument & {
  schema_version: 1;
  kind: "archive_manifest";
  channel_key: string;
  paths: string[];
  updated_at: string;
};

export class CosmosArchiveBackend implements ArchiveBackend {
  constructor(
    private readonly state: RuntimeStateStore,
    private readonly channelKey: string,
  ) {}

  async readText(path: string): Promise<string | null> {
    const file = await this.state.read<ArchiveFileDocument>(this.fileId(path));
    if (!file) return null;
    const compressed = await this.readChunks(file.document);
    return gunzipSync(compressed).toString("utf8");
  }

  async putImmutableFile(
    path: string,
    content: string | Uint8Array,
    contentType: string,
    onExisting: "error" | "skip" = "error",
  ): Promise<{ created: boolean }> {
    const id = this.fileId(path);
    if (await this.state.read<ArchiveFileDocument>(id)) {
      if (onExisting === "skip") {
        await this.addToManifest(path);
        return { created: false };
      }
      throw new Error(`Immutable archive item already exists: ${path}`);
    }
    await this.writeFile(path, content, contentType, true);
    return { created: true };
  }

  async upsertFile(path: string, content: string | Uint8Array, contentType: string): Promise<void> {
    await this.writeFile(path, content, contentType, false);
  }

  async listFiles(path: string): Promise<StoredFile[]> {
    const manifest = await this.state.read<ArchiveManifestDocument>(this.manifestId());
    const prefix = path.endsWith("/") ? path : `${path}/`;
    return (manifest?.document.paths ?? [])
      .filter((entry) => entry === path || entry.startsWith(prefix))
      .sort()
      .map((entry) => ({ path: entry, id: this.fileId(entry), name: entry.split("/").at(-1)! }));
  }

  private async writeFile(
    path: string,
    content: string | Uint8Array,
    contentType: string,
    createOnly: boolean,
  ): Promise<void> {
    const raw = typeof content === "string" ? Buffer.from(content, "utf8") : Buffer.from(content);
    const compressed = gzipSync(raw, { level: 9 });
    const id = this.fileId(path);
    const chunks = splitBuffer(compressed, CHUNK_BYTES);
    for (let index = 0; index < chunks.length; index += 1) {
      const chunk: ArchiveChunkDocument = {
        id: `${id}:${index}`,
        partitionKey: RUNTIME_PARTITION_KEY,
        schema_version: 1,
        kind: "archive_chunk",
        channel_key: this.channelKey,
        file_id: id,
        index,
        data: chunks[index]!.toString("base64"),
      };
      await this.upsertDocument(chunk);
    }
    const document: ArchiveFileDocument = {
      id,
      partitionKey: RUNTIME_PARTITION_KEY,
      schema_version: 1,
      kind: "archive_file",
      channel_key: this.channelKey,
      path,
      content_type: contentType,
      encoding: "gzip-base64",
      chunks: chunks.length,
      original_bytes: raw.byteLength,
      compressed_bytes: compressed.byteLength,
      updated_at: new Date().toISOString(),
    };
    if (createOnly) await this.state.create(document);
    else await this.upsertDocument(document);
    await this.addToManifest(path);
  }

  private async readChunks(file: ArchiveFileDocument): Promise<Buffer> {
    const chunks: Buffer[] = [];
    for (let index = 0; index < file.chunks; index += 1) {
      const current = await this.state.read<ArchiveChunkDocument>(`${file.id}:${index}`);
      if (!current || current.document.file_id !== file.id || current.document.index !== index) {
        throw new Error(`Archive item is incomplete: ${file.path}`);
      }
      chunks.push(Buffer.from(current.document.data, "base64"));
    }
    const result = Buffer.concat(chunks);
    if (result.byteLength !== file.compressed_bytes) throw new Error(`Archive item is corrupt: ${file.path}`);
    return result;
  }

  private async upsertDocument<T extends RuntimeDocument>(document: T): Promise<void> {
    for (let attempt = 0; attempt < 8; attempt += 1) {
      const current = await this.state.read<T>(document.id);
      try {
        if (current) await this.state.replace(document, current.etag);
        else await this.state.create(document);
        return;
      } catch (error) {
        if (!(error instanceof RuntimeStateConflictError)) throw error;
      }
    }
    throw new Error(`Cosmos archive item is busy: ${document.id}`);
  }

  private async addToManifest(path: string): Promise<void> {
    const id = this.manifestId();
    for (let attempt = 0; attempt < 8; attempt += 1) {
      const current = await this.state.read<ArchiveManifestDocument>(id);
      if (current?.document.paths.includes(path)) return;
      const document: ArchiveManifestDocument = {
        id,
        partitionKey: RUNTIME_PARTITION_KEY,
        schema_version: 1,
        kind: "archive_manifest",
        channel_key: this.channelKey,
        paths: [...(current?.document.paths ?? []), path].sort(),
        updated_at: new Date().toISOString(),
      };
      try {
        if (current) await this.state.replace(document, current.etag);
        else await this.state.create(document);
        return;
      } catch (error) {
        if (!(error instanceof RuntimeStateConflictError)) throw error;
      }
    }
    throw new Error(`Cosmos archive manifest is busy: ${this.channelKey}`);
  }

  private fileId(path: string): string {
    return `archive:${this.channelKey}:file:${createHash("sha256").update(path).digest("hex")}`;
  }

  private manifestId(): string {
    return `archive:${this.channelKey}:manifest`;
  }
}

function splitBuffer(value: Buffer, size: number): Buffer[] {
  if (!value.length) return [Buffer.alloc(0)];
  const chunks: Buffer[] = [];
  for (let offset = 0; offset < value.length; offset += size) chunks.push(value.subarray(offset, offset + size));
  return chunks;
}
