import type { YoutubeAnalyticsService } from "../google/youtube-analytics.js";
import type { YoutubeDataService } from "../google/youtube-data.js";
import type { ReachReportBundle, YoutubeReportingService } from "../google/youtube-reporting.js";
import { lastCompleteYoutubeDays } from "../utils/dates.js";
import type { ArchiveRecord, JsonValue } from "./types.js";
import { mergeLatest, sanitizeArchiveValue, type SnapshotStore } from "./snapshot-store.js";

type CollectorServices = {
  data: YoutubeDataService;
  analytics: YoutubeAnalyticsService;
  reporting: YoutubeReportingService;
  store: SnapshotStore;
};

type CollectorConfig = {
  youtubeChannelId: string;
  collectionLookbackDays: number;
  collectorConcurrency: number;
};

export class HistoricalCollector {
  private running: Promise<CollectionResult> | undefined;

  constructor(
    private readonly config: CollectorConfig,
    private readonly services: CollectorServices,
  ) {}

  collect(): Promise<CollectionResult> {
    if (!this.running) {
      this.running = this.collectOnce().finally(() => {
        this.running = undefined;
      });
    }
    return this.running;
  }

  private async collectOnce(): Promise<CollectionResult> {
    await this.services.data.assertAuthorizedChannel();
    const observedAt = new Date().toISOString();
    const period = lastCompleteYoutubeDays(this.config.collectionLookbackDays);
    const videos = await this.services.data.listAllVideos();

    const analyticsRows = await parallelMap(
      videos,
      this.config.collectorConcurrency,
      async (video) => ({
        video,
        result: await this.services.analytics.videoDailyMetrics(
          video.videoId,
          period.startDate,
          period.endDate,
        ),
      }),
    );
    const reachBundles = await this.services.reporting.getReportBundles(period.startDate, period.endDate);

    let rawReportsCreated = 0;
    for (const bundle of reachBundles) {
      const saved = await this.services.store.saveRawReachReport(bundle.metadata, bundle.rawCsv, observedAt);
      if (saved.created) rawReportsCreated += 1;
    }

    const records: ArchiveRecord[] = videos.map((video) => ({
      observed_at: observedAt,
      metric_date: period.endDate,
      video_id: video.videoId,
      channel_id: video.channelId,
      source: "youtube_data",
      metrics: {
        title: video.title,
        published_at: video.publishedAt,
        url: video.url,
      },
    }));

    for (const { video, result } of analyticsRows) {
      for (const row of result.rows) {
        if (typeof row.day !== "string") continue;
        const { day, ...metrics } = row;
        records.push({
          observed_at: observedAt,
          metric_date: day,
          video_id: video.videoId,
          channel_id: video.channelId,
          source: "youtube_analytics",
          metrics: sanitizeArchiveValue(metrics) as Record<string, JsonValue>,
        });
      }
    }

    records.push(...reportingRecords(reachBundles, observedAt, new Set(videos.map((video) => video.videoId))));

    const snapshot = this.services.store.createSnapshot({
      observed_at: observedAt,
      channel_id: this.config.youtubeChannelId,
      collection_window: { start_date: period.startDate, end_date: period.endDate },
      records,
    });
    const snapshotPath = await this.services.store.saveSnapshot(snapshot);
    const previous = await this.services.store.readLatest();
    await this.services.store.saveLatest(
      mergeLatest(previous, observedAt, this.config.youtubeChannelId, records, {
        startDate: period.startDate,
        endDate: period.endDate,
        videoIds: new Set(videos.map((video) => video.videoId)),
      }),
    );
    await this.services.store.saveVideos({
      schema_version: 1,
      updated_at: observedAt,
      channel_id: this.config.youtubeChannelId,
      videos: videos.map((video) => ({
        video_id: video.videoId,
        channel_id: video.channelId,
        title: video.title,
        published_at: video.publishedAt,
        url: video.url,
      })),
    });

    return {
      observedAt,
      period,
      videos: videos.length,
      records: records.length,
      rawReportsCreated,
      snapshotPath,
    };
  }
}

export type CollectionResult = {
  observedAt: string;
  period: { startDate: string; endDate: string };
  videos: number;
  records: number;
  rawReportsCreated: number;
  snapshotPath: string;
};

function reportingRecords(
  bundles: ReachReportBundle[],
  observedAt: string,
  videoIds: Set<string>,
): ArchiveRecord[] {
  const current = new Map<string, ArchiveRecord>();
  for (const bundle of bundles) {
    for (const row of bundle.rows) {
      if (!videoIds.has(row.videoId)) continue;
      const record: ArchiveRecord = {
        observed_at: observedAt,
        metric_date: row.date,
        video_id: row.videoId,
        channel_id: row.channelId,
        source: "youtube_reporting",
        metrics: {
          video_thumbnail_impressions: row.thumbnailImpressions,
          video_thumbnail_impressions_ctr: row.thumbnailImpressionsCtr,
        },
        report: bundle.metadata,
      };
      current.set(`${row.videoId}\u0000${row.date}`, record);
    }
  }
  return [...current.values()];
}

async function parallelMap<T, R>(
  values: T[],
  concurrency: number,
  operation: (value: T) => Promise<R>,
): Promise<R[]> {
  const results = new Array<R>(values.length);
  let cursor = 0;
  const workers = Array.from({ length: Math.min(concurrency, Math.max(1, values.length)) }, async () => {
    while (cursor < values.length) {
      const index = cursor++;
      results[index] = await operation(values[index]!);
    }
  });
  await Promise.all(workers);
  return results;
}
