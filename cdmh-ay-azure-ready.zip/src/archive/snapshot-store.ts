import { randomUUID } from "node:crypto";
import { PublicError } from "../errors.js";
import type {
  ArchiveRecord,
  ArchiveSnapshot,
  JsonValue,
  LatestIndex,
  ReachReportMetadata,
  VideoIndex,
} from "./types.js";

const SECRET_KEY = /(secret|token|authorization|password|private.?key|api.?key|cookie)/i;

export type StoredFile = { path: string; id: string; name: string };

export type SnapshotExport = {
  path: string;
  snapshot: ArchiveSnapshot;
};

export type ReachReportExport = {
  csvPath: string;
  metadataPath: string;
  csv: string;
  metadata: ReachReportMetadata;
};

export interface ArchiveBackend {
  readText(path: string): Promise<string | null>;
  putImmutableFile(
    path: string,
    content: string | Uint8Array,
    contentType: string,
    onExisting?: "error" | "skip",
  ): Promise<{ created: boolean }>;
  upsertFile(path: string, content: string | Uint8Array, contentType: string): Promise<void>;
  listFiles(path: string): Promise<StoredFile[]>;
}

export class SnapshotStore {
  constructor(private readonly backend: ArchiveBackend) {}

  createSnapshot(input: Omit<ArchiveSnapshot, "schema_version" | "snapshot_id">): ArchiveSnapshot {
    assertIsoTimestamp(input.observed_at);
    return {
      schema_version: 1,
      snapshot_id: randomUUID(),
      ...input,
      records: input.records.map((record) => sanitizeRecord(record)),
    };
  }

  async saveSnapshot(snapshot: ArchiveSnapshot): Promise<string> {
    assertIsoTimestamp(snapshot.observed_at);
    const date = snapshot.observed_at.slice(0, 10);
    const [year, month, day] = date.split("-");
    if (!year || !month || !day) throw new PublicError("invalid_snapshot", "The snapshot timestamp is invalid.");
    const timestamp = snapshot.observed_at.replace(/[:.]/g, "-");
    const path = `snapshots/${year}/${month}/${day}/${timestamp}--${snapshot.snapshot_id}.json`;
    const serialized = serializeArchiveValue(snapshot);
    await this.backend.putImmutableFile(path, serialized, "application/json; charset=utf-8", "error");
    return path;
  }

  async saveRawReachReport(
    metadata: ReachReportMetadata,
    csv: Uint8Array,
    observedAt: string,
  ): Promise<{ csvPath: string; metadataPath: string; created: boolean }> {
    const base = reachReportBase(metadata, observedAt);
    const csvResult = await this.backend.putImmutableFile(
      `${base}.csv`,
      csv,
      "text/csv; charset=utf-8",
      "skip",
    );
    await this.backend.putImmutableFile(
      `${base}.metadata.json`,
      serializeArchiveValue(metadata),
      "application/json; charset=utf-8",
      "skip",
    );
    return { csvPath: `${base}.csv`, metadataPath: `${base}.metadata.json`, created: csvResult.created };
  }

  async readLatest(): Promise<LatestIndex | null> {
    return this.readJson<LatestIndex>("index/latest.json");
  }

  async saveLatest(index: LatestIndex): Promise<void> {
    await this.backend.upsertFile(
      "index/latest.json",
      serializeArchiveValue(index),
      "application/json; charset=utf-8",
    );
  }

  async saveVideos(index: VideoIndex): Promise<void> {
    await this.backend.upsertFile(
      "index/videos.json",
      serializeArchiveValue(index),
      "application/json; charset=utf-8",
    );
  }

  async listSnapshots(): Promise<ArchiveSnapshot[]> {
    return (await this.listSnapshotExports()).map((entry) => entry.snapshot);
  }

  async findSnapshot(observedAt: string): Promise<ArchiveSnapshot | null> {
    assertIsoTimestamp(observedAt);
    return (await this.listSnapshotExports()).find((entry) => entry.snapshot.observed_at === observedAt)?.snapshot ?? null;
  }

  async latestSnapshot(): Promise<SnapshotExport | null> {
    return (await this.listSnapshotExports()).at(-1) ?? null;
  }

  async exportSnapshot(selector: { snapshotId?: string; observedAt?: string }): Promise<SnapshotExport | null> {
    if (!!selector.snapshotId === !!selector.observedAt) {
      throw new PublicError(
        "invalid_snapshot_selector",
        "Provide exactly one of snapshot_id or observed_at.",
      );
    }
    if (selector.observedAt) assertIsoTimestamp(selector.observedAt);
    return (await this.listSnapshotExports()).find(({ snapshot }) =>
      selector.snapshotId
        ? snapshot.snapshot_id === selector.snapshotId
        : snapshot.observed_at === selector.observedAt
    ) ?? null;
  }

  async exportReachReport(snapshot: ArchiveSnapshot, reportId: string): Promise<ReachReportExport | null> {
    const metadata = snapshot.records
      .map((record) => record.report)
      .find((report): report is ReachReportMetadata => report?.report_id === reportId);
    if (!metadata) return null;
    const base = reachReportBase(metadata, snapshot.observed_at);
    const [csv, storedMetadata] = await Promise.all([
      this.backend.readText(`${base}.csv`),
      this.readJson<ReachReportMetadata>(`${base}.metadata.json`),
    ]);
    if (csv === null || storedMetadata === null) {
      throw new PublicError("archive_incomplete", "The archived Reach report is incomplete.", 502);
    }
    return {
      csvPath: `${base}.csv`,
      metadataPath: `${base}.metadata.json`,
      csv,
      metadata: storedMetadata,
    };
  }

  async readArchivedText(path: string): Promise<string | null> {
    return this.backend.readText(path);
  }

  private async listSnapshotExports(): Promise<SnapshotExport[]> {
    const files = (await this.backend.listFiles("snapshots"))
      .filter(isSnapshotFile)
      .sort((a, b) => a.path.localeCompare(b.path));
    const snapshots: SnapshotExport[] = [];
    for (const file of files) {
      const snapshot = await this.readJson<ArchiveSnapshot>(file.path);
      if (snapshot?.schema_version === 1 && Array.isArray(snapshot.records)) {
        snapshots.push({ path: file.path, snapshot });
      }
    }
    return snapshots;
  }

  private async readJson<T>(path: string): Promise<T | null> {
    const text = await this.backend.readText(path);
    if (text === null) return null;
    try {
      return JSON.parse(text) as T;
    } catch {
      throw new PublicError("archive_invalid_json", "The runtime archive contains invalid JSON.", 502);
    }
  }
}

export function mergeLatest(
  previous: LatestIndex | null,
  observedAt: string,
  channelId: string,
  incoming: ArchiveRecord[],
  replacedWindow?: { startDate: string; endDate: string; videoIds: Set<string> },
): LatestIndex {
  const records = new Map<string, ArchiveRecord>();
  for (const record of previous?.records ?? []) {
    const replace = replacedWindow &&
      record.source !== "youtube_data" &&
      replacedWindow.videoIds.has(record.video_id) &&
      record.metric_date >= replacedWindow.startDate &&
      record.metric_date <= replacedWindow.endDate;
    if (!replace) records.set(latestKey(record), record);
  }
  for (const record of incoming) records.set(latestKey(record), sanitizeRecord(record));
  return {
    schema_version: 1,
    updated_at: observedAt,
    channel_id: channelId,
    records: [...records.values()].sort(compareRecords),
  };
}

export function serializeArchiveValue(value: unknown): string {
  return `${JSON.stringify(sanitizeArchiveValue(value), null, 2)}\n`;
}

export function sanitizeArchiveValue(value: unknown): JsonValue {
  if (value === null || typeof value === "string" || typeof value === "boolean") return value;
  if (typeof value === "number") return Number.isFinite(value) ? value : null;
  if (Array.isArray(value)) return value.map(sanitizeArchiveValue);
  if (typeof value === "object") {
    const sanitized: Record<string, JsonValue> = {};
    for (const [key, child] of Object.entries(value as Record<string, unknown>)) {
      if (SECRET_KEY.test(key) || child === undefined) continue;
      sanitized[key] = sanitizeArchiveValue(child);
    }
    return sanitized;
  }
  return String(value);
}

function sanitizeRecord(record: ArchiveRecord): ArchiveRecord {
  return sanitizeArchiveValue({
    observed_at: record.observed_at,
    metric_date: record.metric_date,
    video_id: record.video_id,
    channel_id: record.channel_id,
    source: record.source,
    metrics: record.metrics,
    ...(record.report ? { report: record.report } : {}),
  }) as ArchiveRecord;
}

function latestKey(record: ArchiveRecord): string {
  return record.source === "youtube_data"
    ? `${record.source}\u0000${record.video_id}`
    : `${record.source}\u0000${record.video_id}\u0000${record.metric_date}`;
}

function compareRecords(a: ArchiveRecord, b: ArchiveRecord): number {
  return a.video_id.localeCompare(b.video_id) ||
    a.metric_date.localeCompare(b.metric_date) ||
    a.source.localeCompare(b.source);
}

function safeFileName(value: string): string {
  const result = value.replace(/[^A-Za-z0-9._-]/g, "_");
  if (!result || result === "." || result === "..") {
    throw new PublicError("invalid_report_id", "The Reach report ID is invalid.");
  }
  return result;
}

function reachReportBase(metadata: ReachReportMetadata, observedAt: string): string {
  const date = (metadata.start_time ?? metadata.create_time ?? observedAt).slice(0, 10);
  const [year, month] = date.split("-");
  if (!year || !month) throw new PublicError("invalid_report", "The Reach report timestamp is invalid.");
  return `reach-reports/${year}/${month}/${safeFileName(metadata.report_id)}`;
}

function isSnapshotFile(file: StoredFile): boolean {
  return file.path.startsWith("snapshots/") && file.name.endsWith(".json");
}

function assertIsoTimestamp(value: string): void {
  const parsed = new Date(value);
  if (!/^\d{4}-\d{2}-\d{2}T/.test(value) || Number.isNaN(parsed.valueOf())) {
    throw new PublicError("invalid_observed_at", "observed_at must be an ISO 8601 timestamp.");
  }
}
