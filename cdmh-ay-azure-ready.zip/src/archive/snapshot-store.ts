import { randomUUID } from "node:crypto";
import { PublicError } from "../errors.js";
import type { GraphClient, StoredFile } from "../microsoft/graph-client.js";
import type {
  ArchiveRecord,
  ArchiveSnapshot,
  JsonValue,
  LatestIndex,
  ReachReportMetadata,
  VideoIndex,
} from "./types.js";

const SECRET_KEY = /(secret|token|authorization|password|private.?key|api.?key|cookie)/i;

export type ArchiveBackend = Pick<
  GraphClient,
  "readText" | "putImmutableFile" | "upsertFile" | "listFiles"
>;

export class SnapshotStore {
  constructor(private readonly backend: ArchiveBackend) {}

  createSnapshot(input: Omit<ArchiveSnapshot, "schema_version" | "snapshot_id">): ArchiveSnapshot {
    assertIsoTimestamp(input.observed_at);
    return {
      schema_version: 1,
      snapshot_id: randomUUID(),
      ...input,
      records: input.records.map((record) => sanitizeRecord(record)),
    };
  }

  async saveSnapshot(snapshot: ArchiveSnapshot): Promise<string> {
    assertIsoTimestamp(snapshot.observed_at);
    const date = snapshot.observed_at.slice(0, 10);
    const [year, month, day] = date.split("-");
    if (!year || !month || !day) throw new PublicError("invalid_snapshot", "The snapshot timestamp is invalid.");
    const timestamp = snapshot.observed_at.replace(/[:.]/g, "-");
    const path = `snapshots/${year}/${month}/${day}/${timestamp}--${snapshot.snapshot_id}.json`;
    const serialized = serializeArchiveValue(snapshot);
    await this.backend.putImmutableFile(path, serialized, "application/json; charset=utf-8", "error");
    return path;
  }

  async saveRawReachReport(
    metadata: ReachReportMetadata,
    csv: Uint8Array,
    observedAt: string,
  ): Promise<{ csvPath: string; metadataPath: string; created: boolean }> {
    const date = (metadata.start_time ?? metadata.create_time ?? observedAt).slice(0, 10);
    const [year, month] = date.split("-");
    if (!year || !month) throw new PublicError("invalid_report", "The Reach report timestamp is invalid.");
    const reportId = safeFileName(metadata.report_id);
    const base = `reach-reports/${year}/${month}/${reportId}`;
    const csvResult = await this.backend.putImmutableFile(
      `${base}.csv`,
      csv,
      "text/csv; charset=utf-8",
      "skip",
    );
    await this.backend.putImmutableFile(
      `${base}.metadata.json`,
      serializeArchiveValue(metadata),
      "application/json; charset=utf-8",
      "skip",
    );
    return { csvPath: `${base}.csv`, metadataPath: `${base}.metadata.json`, created: csvResult.created };
  }

  async readLatest(): Promise<LatestIndex | null> {
    return this.readJson<LatestIndex>("index/latest.json");
  }

  async saveLatest(index: LatestIndex): Promise<void> {
    await this.backend.upsertFile(
      "index/latest.json",
      serializeArchiveValue(index),
      "application/json; charset=utf-8",
    );
  }

  async saveVideos(index: VideoIndex): Promise<void> {
    await this.backend.upsertFile(
      "index/videos.json",
      serializeArchiveValue(index),
      "application/json; charset=utf-8",
    );
  }

  async listSnapshots(): Promise<ArchiveSnapshot[]> {
    const files = await this.backend.listFiles("snapshots");
    const snapshots: ArchiveSnapshot[] = [];
    for (const file of files.filter(isSnapshotFile).sort((a, b) => a.path.localeCompare(b.path))) {
      const snapshot = await this.readJson<ArchiveSnapshot>(file.path);
      if (snapshot?.schema_version === 1 && Array.isArray(snapshot.records)) snapshots.push(snapshot);
    }
    return snapshots;
  }

  async findSnapshot(observedAt: string): Promise<ArchiveSnapshot | null> {
    assertIsoTimestamp(observedAt);
    const snapshots = await this.listSnapshots();
    return snapshots.find((snapshot) => snapshot.observed_at === observedAt) ?? null;
  }

  private async readJson<T>(path: string): Promise<T | null> {
    const text = await this.backend.readText(path);
    if (text === null) return null;
    try {
      return JSON.parse(text) as T;
    } catch {
      throw new PublicError("archive_invalid_json", "The OneDrive archive contains invalid JSON.", 502);
    }
  }
}

export function mergeLatest(
  previous: LatestIndex | null,
  observedAt: string,
  channelId: string,
  incoming: ArchiveRecord[],
  replacedWindow?: { startDate: string; endDate: string; videoIds: Set<string> },
): LatestIndex {
  const records = new Map<string, ArchiveRecord>();
  for (const record of previous?.records ?? []) {
    const replace = replacedWindow &&
      record.source !== "youtube_data" &&
      replacedWindow.videoIds.has(record.video_id) &&
      record.metric_date >= replacedWindow.startDate &&
      record.metric_date <= replacedWindow.endDate;
    if (!replace) records.set(latestKey(record), record);
  }
  for (const record of incoming) records.set(latestKey(record), sanitizeRecord(record));
  return {
    schema_version: 1,
    updated_at: observedAt,
    channel_id: channelId,
    records: [...records.values()].sort(compareRecords),
  };
}

export function serializeArchiveValue(value: unknown): string {
  return `${JSON.stringify(sanitizeArchiveValue(value), null, 2)}\n`;
}

export function sanitizeArchiveValue(value: unknown): JsonValue {
  if (value === null || typeof value === "string" || typeof value === "boolean") return value;
  if (typeof value === "number") return Number.isFinite(value) ? value : null;
  if (Array.isArray(value)) return value.map(sanitizeArchiveValue);
  if (typeof value === "object") {
    const sanitized: Record<string, JsonValue> = {};
    for (const [key, child] of Object.entries(value as Record<string, unknown>)) {
      if (SECRET_KEY.test(key) || child === undefined) continue;
      sanitized[key] = sanitizeArchiveValue(child);
    }
    return sanitized;
  }
  return String(value);
}

function sanitizeRecord(record: ArchiveRecord): ArchiveRecord {
  return sanitizeArchiveValue({
    observed_at: record.observed_at,
    metric_date: record.metric_date,
    video_id: record.video_id,
    channel_id: record.channel_id,
    source: record.source,
    metrics: record.metrics,
    ...(record.report ? { report: record.report } : {}),
  }) as ArchiveRecord;
}

function latestKey(record: ArchiveRecord): string {
  return record.source === "youtube_data"
    ? `${record.source}\u0000${record.video_id}`
    : `${record.source}\u0000${record.video_id}\u0000${record.metric_date}`;
}

function compareRecords(a: ArchiveRecord, b: ArchiveRecord): number {
  return a.video_id.localeCompare(b.video_id) ||
    a.metric_date.localeCompare(b.metric_date) ||
    a.source.localeCompare(b.source);
}

function safeFileName(value: string): string {
  const result = value.replace(/[^A-Za-z0-9._-]/g, "_");
  if (!result || result === "." || result === "..") {
    throw new PublicError("invalid_report_id", "The Reach report ID is invalid.");
  }
  return result;
}

function isSnapshotFile(file: StoredFile): boolean {
  return file.path.startsWith("snapshots/") && file.name.endsWith(".json");
}

function assertIsoTimestamp(value: string): void {
  const parsed = new Date(value);
  if (!/^\d{4}-\d{2}-\d{2}T/.test(value) || Number.isNaN(parsed.valueOf())) {
    throw new PublicError("invalid_observed_at", "observed_at must be an ISO 8601 timestamp.");
  }
}
