import { PublicError } from "../errors.js";
import type { ArchiveRecord, ArchiveSnapshot, JsonValue } from "./types.js";

export function metricHistory(
  snapshots: ArchiveSnapshot[],
  videoId: string,
  metric: string,
  startDate: string,
  endDate: string,
) {
  if (!/^[A-Za-z][A-Za-z0-9_]*$/.test(metric)) {
    throw new PublicError("invalid_metric", "The metric name is invalid.");
  }
  return snapshots.flatMap((snapshot) => snapshot.records.flatMap((record) => {
    if (
      record.video_id !== videoId ||
      record.metric_date < startDate ||
      record.metric_date > endDate ||
      !(metric in record.metrics)
    ) return [];
    return [{
      metric_date: record.metric_date,
      observed_at: record.observed_at,
      source: record.source,
      value: record.metrics[metric] ?? null,
    }];
  })).sort((a, b) =>
    a.metric_date.localeCompare(b.metric_date) || a.observed_at.localeCompare(b.observed_at),
  );
}

export function metricRevisions(
  snapshots: ArchiveSnapshot[],
  videoId: string,
  startDate: string,
  endDate: string,
) {
  const groups = new Map<string, ArchiveRecord[]>();
  for (const snapshot of snapshots) {
    for (const record of snapshot.records) {
      if (
        record.video_id !== videoId ||
        record.metric_date < startDate ||
        record.metric_date > endDate ||
        record.source === "youtube_data"
      ) continue;
      const key = `${record.source}\u0000${record.metric_date}`;
      const group = groups.get(key) ?? [];
      group.push(record);
      groups.set(key, group);
    }
  }

  return [...groups.values()].flatMap((records) => {
    records.sort((a, b) => a.observed_at.localeCompare(b.observed_at));
    const metricNames = new Set(records.flatMap((record) => Object.keys(record.metrics)));
    const changedMetrics = [...metricNames].filter((name) => {
      const values = records.map((record) => stableValue(record.metrics[name]));
      return new Set(values).size > 1;
    });
    if (!changedMetrics.length) return [];
    return [{
      metric_date: records[0]!.metric_date,
      source: records[0]!.source,
      changed_metrics: changedMetrics.sort(),
      observations: records.map((record) => ({
        observed_at: record.observed_at,
        metrics: Object.fromEntries(changedMetrics.map((name) => [name, record.metrics[name] ?? null])),
      })),
    }];
  }).sort((a, b) =>
    a.metric_date.localeCompare(b.metric_date) || a.source.localeCompare(b.source),
  );
}

export function snapshotDiff(
  snapshotA: ArchiveSnapshot,
  snapshotB: ArchiveSnapshot,
  videoId: string,
) {
  const before = stateForVideo(snapshotA, videoId);
  const after = stateForVideo(snapshotB, videoId);
  const keys = [...new Set([...before.keys(), ...after.keys()])].sort();

  const differences: Array<Record<string, unknown>> = [];
  for (const key of keys) {
    const a = before.get(key);
    const b = after.get(key);
    if (!a && b) {
      differences.push({ source: b.source, metric_date: b.metric_date, status: "added", metrics: b.metrics });
      continue;
    }
    if (a && !b) {
      differences.push({ source: a.source, metric_date: a.metric_date, status: "removed", metrics: a.metrics });
      continue;
    }
    if (!a || !b) continue;
    const metricNames = [...new Set([...Object.keys(a.metrics), ...Object.keys(b.metrics)])].sort();
    const changes = metricNames.flatMap((metric) => {
      const valueA = a.metrics[metric] ?? null;
      const valueB = b.metrics[metric] ?? null;
      if (stableValue(valueA) === stableValue(valueB)) return [];
      return [{
        metric,
        before: valueA,
        after: valueB,
        ...(typeof valueA === "number" && typeof valueB === "number"
          ? { delta: valueB - valueA }
          : {}),
      }];
    });
    if (changes.length) {
      differences.push({ source: a.source, metric_date: a.metric_date, status: "changed", changes });
    }
  }
  return differences;
}

function stateForVideo(snapshot: ArchiveSnapshot, videoId: string): Map<string, ArchiveRecord> {
  const state = new Map<string, ArchiveRecord>();
  for (const record of snapshot.records) {
    if (record.video_id === videoId) {
      state.set(`${record.source}\u0000${record.metric_date}`, record);
    }
  }
  return state;
}

function stableValue(value: JsonValue | undefined): string {
  if (value && typeof value === "object" && !Array.isArray(value)) {
    return JSON.stringify(Object.fromEntries(Object.entries(value).sort(([a], [b]) => a.localeCompare(b))));
  }
  return JSON.stringify(value);
}
