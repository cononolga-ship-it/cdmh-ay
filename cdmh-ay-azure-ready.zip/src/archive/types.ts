export type ArchiveSource = "youtube_data" | "youtube_analytics" | "youtube_reporting";
export type JsonValue = string | number | boolean | null | JsonValue[] | { [key: string]: JsonValue };

export type ReachReportMetadata = {
  report_id: string;
  job_id: string;
  create_time: string | null;
  start_time: string | null;
  end_time: string | null;
  covered_period: { start_date: string; end_date: string } | null;
};

export type ArchiveRecord = {
  observed_at: string;
  metric_date: string;
  video_id: string;
  channel_id: string;
  source: ArchiveSource;
  metrics: Record<string, JsonValue>;
  report?: ReachReportMetadata;
};

export type ArchiveSnapshot = {
  schema_version: 1;
  snapshot_id: string;
  observed_at: string;
  channel_id: string;
  collection_window: { start_date: string; end_date: string };
  records: ArchiveRecord[];
};

export type LatestIndex = {
  schema_version: 1;
  updated_at: string;
  channel_id: string;
  records: ArchiveRecord[];
};

export type VideoIndex = {
  schema_version: 1;
  updated_at: string;
  channel_id: string;
  videos: Array<{
    video_id: string;
    channel_id: string;
    title: string | null;
    published_at: string | null;
    url: string;
  }>;
};
