export class PublicError extends Error {
  constructor(
    public readonly code: string,
    public readonly publicMessage: string,
    public readonly status = 400,
  ) {
    super(publicMessage);
    this.name = "PublicError";
  }
}

export function toSafeError(error: unknown): PublicError {
  if (error instanceof PublicError) return error;
  return new PublicError("upstream_error", "The requested data could not be retrieved.", 502);
}
